"""Dispute persistence."""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.domain.entities.dispute import Dispute
from app.domain.repositories.base import SQLAlchemyRepository


class DisputeRepository(Protocol):
    async def get_by_id(self, dispute_id: UUID) -> Dispute | None: ...
    async def list_for_escrow(self, escrow_id: UUID) -> list[Dispute]: ...
    def add(self, dispute: Dispute) -> None: ...


class SQLAlchemyDisputeRepository(SQLAlchemyRepository[Dispute]):
    model = Dispute

    async def get_by_id(self, dispute_id: UUID) -> Dispute | None:
        result = await self._session.execute(
            select(Dispute)
            .where(Dispute.id == dispute_id)
            .options(selectinload(Dispute.evidence))
        )
        return result.scalar_one_or_none()

    async def list_for_escrow(self, escrow_id: UUID) -> list[Dispute]:
        result = await self._session.execute(
            select(Dispute)
            .where(Dispute.escrow_id == escrow_id)
            .order_by(Dispute.created_at.desc())
        )
        return list(result.scalars().all())
