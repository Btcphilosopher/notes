"""Generic repository base.

Concrete repositories inherit the CRUD plumbing from here and add only
the queries that are actually specific to that entity — that's what keeps
each repository file small (per the "no monolithic files" principle)
instead of every one of them re-implementing get_by_id/add/delete.

Deliberately, nothing here calls `session.commit()`. Repositories only
stage changes; committing (and rolling back the whole operation together
if anything fails) is the Unit of Work's job, introduced in Phase 4 once
there are multi-repository use cases to coordinate.
"""
from typing import Generic, TypeVar
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.database.base import Base

ModelT = TypeVar("ModelT", bound=Base)


class SQLAlchemyRepository(Generic[ModelT]):
    """Base class for SQLAlchemy-backed repositories.

    Subclasses set the `model` class attribute to the entity they manage.
    """

    model: type[ModelT]

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_id(self, entity_id: UUID) -> ModelT | None:
        return await self._session.get(self.model, entity_id)

    def add(self, entity: ModelT) -> None:
        """Stage `entity` for insertion. The caller's Unit of Work commits it."""
        self._session.add(entity)

    async def delete(self, entity: ModelT) -> None:
        """Stage `entity` for deletion.

        Rarely used directly — most entities in this system are append-only
        or soft-deleted (status flag) rather than hard-deleted, in keeping
        with the auditability requirement.
        """
        await self._session.delete(entity)
