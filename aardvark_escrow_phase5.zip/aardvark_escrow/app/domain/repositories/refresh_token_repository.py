"""RefreshToken persistence."""
from typing import Protocol
from uuid import UUID

from sqlalchemy import select

from app.domain.entities.refresh_token import RefreshToken
from app.domain.repositories.base import SQLAlchemyRepository


class RefreshTokenRepository(Protocol):
    async def get_by_hashed_token(self, hashed_token: str) -> RefreshToken | None: ...
    async def list_active_for_user(self, user_id: UUID) -> list[RefreshToken]: ...
    def add(self, refresh_token: RefreshToken) -> None: ...


class SQLAlchemyRefreshTokenRepository(SQLAlchemyRepository[RefreshToken]):
    model = RefreshToken

    async def get_by_hashed_token(self, hashed_token: str) -> RefreshToken | None:
        result = await self._session.execute(
            select(RefreshToken).where(RefreshToken.hashed_token == hashed_token)
        )
        return result.scalar_one_or_none()

    async def list_active_for_user(self, user_id: UUID) -> list[RefreshToken]:
        result = await self._session.execute(
            select(RefreshToken).where(
                RefreshToken.user_id == user_id,
                RefreshToken.revoked_at.is_(None),
            )
        )
        return list(result.scalars().all())
