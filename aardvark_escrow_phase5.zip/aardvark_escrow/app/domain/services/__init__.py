"""Domain services.

Business logic that doesn't belong to a single entity lives here.
`AuthService` (Phase 3); `UserService` and `WalletService` (Phase 4);
`EscrowStateMachine` and `EscrowService` (Phase 5) for the escrow
lifecycle's non-financial half. All of them depend only on repository
interfaces via `app.database.unit_of_work.UnitOfWork`, never on FastAPI
directly. The Phase 6 transaction engine combines `EscrowStateMachine`
with `WalletService` for the fund/approve/release/refund operations that
actually move money.
"""
