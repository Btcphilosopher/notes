"""Escrow state machine.

The single, sole code path allowed to change `Escrow.status`. Every
transition is checked against `_LEGAL_TRANSITIONS` before being applied;
an illegal one raises `InvalidStateTransitionError` rather than silently
no-opping or leaving the escrow in a corrupted state.

This class is pure domain logic: given an `Escrow` entity, it mutates its
status/timestamp fields and returns an `EscrowEvent` describing what
happened — but it never touches a database session, a repository, or a
wallet. Persisting the mutated escrow and the returned event, and any
money movement a transition implies, are the caller's job:
`EscrowService` (this phase) for the transitions that touch no money;
the Phase 6 transaction engine for fund/release/refund, which combine
this class with `WalletService` under one `UnitOfWork`.

Transition graph (beyond the two example paths in the spec, both
expansions below are deliberate and documented at the point they widen
the spec's minimal diagram):

    CREATED           -> AWAITING_PAYMENT, CANCELLED
    AWAITING_PAYMENT  -> FUNDED, CANCELLED
    FUNDED            -> IN_PROGRESS, DISPUTED
    IN_PROGRESS       -> AWAITING_APPROVAL, DISPUTED
    AWAITING_APPROVAL -> RELEASED, DISPUTED
    DISPUTED          -> RELEASED, REFUNDED
    REFUNDED          -> CLOSED
    RELEASED          -> (terminal)
    CANCELLED         -> (terminal)
    CLOSED            -> (terminal)

Two decisions worth calling out:

- A dispute can be raised from FUNDED, IN_PROGRESS, *or*
  AWAITING_APPROVAL — the spec's diagram only shows FUNDED -> DISPUTED,
  but realistically a disagreement can surface at any point before funds
  are released, not only in the instant right after funding.
- DISPUTED can resolve to RELEASED, not only REFUNDED — the `Dispute`
  entity's `DisputeResolution` enum (Phase 2) already includes
  `RELEASE_TO_PAYEE` alongside `REFUND_TO_PAYER`, so the state graph
  needs to support both outcomes a dispute can actually have.
"""
from datetime import UTC, datetime
from uuid import UUID

from app.core.exceptions import InvalidStateTransitionError
from app.domain.entities.enums import EscrowStatus
from app.domain.entities.escrow import Escrow, EscrowEvent

_LEGAL_TRANSITIONS: dict[EscrowStatus, frozenset[EscrowStatus]] = {
    EscrowStatus.CREATED: frozenset({EscrowStatus.AWAITING_PAYMENT, EscrowStatus.CANCELLED}),
    EscrowStatus.AWAITING_PAYMENT: frozenset({EscrowStatus.FUNDED, EscrowStatus.CANCELLED}),
    EscrowStatus.FUNDED: frozenset({EscrowStatus.IN_PROGRESS, EscrowStatus.DISPUTED}),
    EscrowStatus.IN_PROGRESS: frozenset(
        {EscrowStatus.AWAITING_APPROVAL, EscrowStatus.DISPUTED}
    ),
    EscrowStatus.AWAITING_APPROVAL: frozenset(
        {EscrowStatus.RELEASED, EscrowStatus.DISPUTED}
    ),
    EscrowStatus.DISPUTED: frozenset({EscrowStatus.RELEASED, EscrowStatus.REFUNDED}),
    EscrowStatus.REFUNDED: frozenset({EscrowStatus.CLOSED}),
    EscrowStatus.RELEASED: frozenset(),
    EscrowStatus.CANCELLED: frozenset(),
    EscrowStatus.CLOSED: frozenset(),
}

# Milestone timestamp columns (Phase 2) set automatically when a
# transition lands on the corresponding status.
_TIMESTAMP_FIELD_BY_STATUS: dict[EscrowStatus, str] = {
    EscrowStatus.FUNDED: "funded_at",
    EscrowStatus.RELEASED: "released_at",
    EscrowStatus.REFUNDED: "refunded_at",
    EscrowStatus.CANCELLED: "cancelled_at",
}


class EscrowStateMachine:
    @staticmethod
    def can_transition(from_status: EscrowStatus, to_status: EscrowStatus) -> bool:
        return to_status in _LEGAL_TRANSITIONS.get(from_status, frozenset())

    @classmethod
    def transition(
        cls,
        escrow: Escrow,
        to_status: EscrowStatus,
        *,
        actor_id: UUID | None = None,
        reason: str | None = None,
    ) -> EscrowEvent:
        """Move `escrow` to `to_status`, mutating it in place.

        Returns the `EscrowEvent` describing the transition — the caller
        is responsible for persisting it (and the escrow) inside its own
        transaction. Does not handle the very first CREATED state itself:
        that's set directly at construction (there's no "from" status to
        transition out of), with its own initial `EscrowEvent` built by
        the caller — see `EscrowService.create_escrow`.
        """
        from_status = escrow.status
        if not cls.can_transition(from_status, to_status):
            raise InvalidStateTransitionError("Escrow", from_status.value, to_status.value)

        escrow.status = to_status

        timestamp_field = _TIMESTAMP_FIELD_BY_STATUS.get(to_status)
        if timestamp_field is not None:
            setattr(escrow, timestamp_field, datetime.now(UTC))

        return EscrowEvent(
            escrow_id=escrow.id,
            from_status=from_status,
            to_status=to_status,
            actor_id=actor_id,
            reason=reason,
        )
