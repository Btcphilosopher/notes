"""Escrow service — creation, reading, and cancellation.

`fund`/`approve`/`release`/`refund` are deliberately NOT here. They move
money, and land in Phase 6's transaction engine, which combines
`EscrowStateMachine` (this phase) with `WalletService` (Phase 4) under a
single `UnitOfWork` locking a wallet and the escrow together. What's
here is the part of the lifecycle that touches no money and so needs no
financial locking: create, read, list, cancel.
"""
from decimal import Decimal
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import DomainError, NotFoundError
from app.database.unit_of_work import UnitOfWork
from app.domain.entities.audit import AuditAction, AuditLog
from app.domain.entities.enums import EscrowStatus
from app.domain.entities.escrow import Escrow, EscrowEvent
from app.domain.services.escrow_state_machine import EscrowStateMachine


class EscrowService:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def create_escrow(
        self,
        *,
        payer_id: UUID,
        payee_email: str,
        amount: Decimal,
        currency: str,
        description: str,
        terms: str | None = None,
        external_reference: str | None = None,
    ) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            payee = await uow.users.get_by_email(payee_email.strip().lower())
            if payee is None:
                raise NotFoundError("No user found with that payee email")
            if payee.id == payer_id:
                raise DomainError("An escrow cannot have the same payer and payee")
            if not payee.is_active:
                raise DomainError("The specified payee's account is not active")

            escrow = Escrow(
                payer_id=payer_id,
                payee_id=payee.id,
                amount=amount,
                currency=currency,
                description=description,
                terms=terms,
                external_reference=external_reference,
                status=EscrowStatus.CREATED,
            )
            uow.escrows.add(escrow)
            await uow.session.flush()

            uow.session.add(
                EscrowEvent(
                    escrow_id=escrow.id,
                    from_status=None,
                    to_status=EscrowStatus.CREATED,
                    actor_id=payer_id,
                )
            )
            # Immediately advance to AWAITING_PAYMENT — see
            # EscrowStateMachine's module docstring for why creation and
            # this first transition happen together rather than needing
            # a separate "activate" endpoint the spec doesn't list.
            event = EscrowStateMachine.transition(
                escrow, EscrowStatus.AWAITING_PAYMENT, actor_id=payer_id
            )
            uow.session.add(event)

            uow.audit_log.add(
                AuditLog(
                    actor_id=payer_id,
                    action=AuditAction.ESCROW_CREATED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )

            await uow.commit()
            return escrow

    async def get_escrow(self, escrow_id: UUID, *, user_id: UUID) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_by_id(escrow_id)
            if escrow is None or user_id not in (escrow.payer_id, escrow.payee_id):
                # Same error either way: a party who isn't payer or payee
                # shouldn't be able to tell "doesn't exist" apart from
                # "exists but isn't yours" by the response they get.
                raise NotFoundError("Escrow not found")
            return escrow

    async def list_escrows(
        self, user_id: UUID, *, limit: int = 50, offset: int = 0
    ) -> list[Escrow]:
        async with UnitOfWork(self._session) as uow:
            return await uow.escrows.list_for_user(user_id, limit=limit, offset=offset)

    async def cancel_escrow(
        self, escrow_id: UUID, *, user_id: UUID, reason: str | None = None
    ) -> Escrow:
        async with UnitOfWork(self._session) as uow:
            escrow = await uow.escrows.get_for_update(escrow_id)
            if escrow is None or user_id not in (escrow.payer_id, escrow.payee_id):
                raise NotFoundError("Escrow not found")

            event = EscrowStateMachine.transition(
                escrow, EscrowStatus.CANCELLED, actor_id=user_id, reason=reason
            )
            uow.session.add(event)
            uow.audit_log.add(
                AuditLog(
                    actor_id=user_id,
                    action=AuditAction.ESCROW_CANCELLED,
                    resource_type="escrow",
                    resource_id=escrow.id,
                )
            )
            await uow.commit()
            return escrow
