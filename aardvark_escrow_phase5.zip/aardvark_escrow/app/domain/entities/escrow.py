"""Escrow, EscrowTransaction, and EscrowEvent entities.

`Escrow` is the aggregate root of this domain. Its `status` field must
only ever be changed by `EscrowStateMachine` (Phase 5) — never assigned
directly — so that every transition is validated against the legal-moves
table and paired with an `EscrowEvent` audit row in the same commit.

`EscrowTransaction` records money movements belonging to this escrow
specifically (deposit, release, refund, fee) and links to the
`WalletTransaction` row(s) it produced. `EscrowEvent` records status
transitions. Both are append-only.
"""
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin
from app.domain.entities.enums import (
    EscrowStatus,
    EscrowTransactionStatus,
    EscrowTransactionType,
)

if TYPE_CHECKING:
    from app.domain.entities.dispute import Dispute
    from app.domain.entities.user import User


class Escrow(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "escrows"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_escrows_amount_positive"),
        CheckConstraint("fee_amount >= 0", name="ck_escrows_fee_amount_non_negative"),
        CheckConstraint("payer_id != payee_id", name="ck_escrows_payer_ne_payee"),
        Index("ix_escrows_payer_id_status", "payer_id", "status"),
        Index("ix_escrows_payee_id_status", "payee_id", "status"),
    )

    payer_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    payee_id: Mapped[UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )

    status: Mapped[EscrowStatus] = mapped_column(
        Enum(EscrowStatus, name="escrow_status"),
        nullable=False,
        default=EscrowStatus.CREATED,
        index=True,
    )

    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)
    fee_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00")
    )
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="GBP")

    description: Mapped[str] = mapped_column(Text, nullable=False)
    terms: Mapped[str | None] = mapped_column(Text, nullable=True)
    external_reference: Mapped[str | None] = mapped_column(
        String(255), index=True, nullable=True
    )

    funded_at: Mapped["datetime | None"] = mapped_column(DateTime(timezone=True), nullable=True)
    released_at: Mapped["datetime | None"] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    refunded_at: Mapped["datetime | None"] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    cancelled_at: Mapped["datetime | None"] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    expires_at: Mapped["datetime | None"] = mapped_column(DateTime(timezone=True), nullable=True)

    payer: Mapped["User"] = relationship(foreign_keys=[payer_id])
    payee: Mapped["User"] = relationship(foreign_keys=[payee_id])

    transactions: Mapped[list["EscrowTransaction"]] = relationship(
        back_populates="escrow", order_by="EscrowTransaction.created_at"
    )
    events: Mapped[list["EscrowEvent"]] = relationship(
        back_populates="escrow", order_by="EscrowEvent.created_at"
    )
    disputes: Mapped[list["Dispute"]] = relationship(back_populates="escrow")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return f"<Escrow id={self.id} status={self.status.value} amount={self.amount}>"


class EscrowTransaction(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    """A money movement belonging to one escrow (deposit/release/refund/fee)."""

    __tablename__ = "escrow_transactions"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_escrow_transactions_amount_positive"),
        Index("ix_escrow_transactions_escrow_id_created_at", "escrow_id", "created_at"),
    )

    escrow_id: Mapped[UUID] = mapped_column(
        ForeignKey("escrows.id", ondelete="RESTRICT"), nullable=False
    )
    type: Mapped[EscrowTransactionType] = mapped_column(
        Enum(EscrowTransactionType, name="escrow_transaction_type"), nullable=False
    )
    status: Mapped[EscrowTransactionStatus] = mapped_column(
        Enum(EscrowTransactionStatus, name="escrow_transaction_status"),
        nullable=False,
        default=EscrowTransactionStatus.COMPLETED,
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)

    wallet_transaction_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("wallet_transactions.id", ondelete="RESTRICT"), nullable=True
    )
    idempotency_key: Mapped[str | None] = mapped_column(
        String(255), unique=True, nullable=True
    )

    escrow: Mapped["Escrow"] = relationship(back_populates="transactions")

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return (
            f"<EscrowTransaction id={self.id} escrow_id={self.escrow_id} "
            f"type={self.type.value} amount={self.amount}>"
        )


class EscrowEvent(Base, UUIDPrimaryKeyMixin, CreatedAtMixin):
    """An immutable record of one escrow state transition.

    `from_status` is null for the initial CREATED event. `actor_id` is
    null for system-triggered transitions (e.g. the expired-escrow
    detection worker in Phase 8).
    """

    __tablename__ = "escrow_events"
    __table_args__ = (
        Index("ix_escrow_events_escrow_id_created_at", "escrow_id", "created_at"),
    )

    escrow_id: Mapped[UUID] = mapped_column(
        ForeignKey("escrows.id", ondelete="RESTRICT"), nullable=False
    )
    from_status: Mapped[EscrowStatus | None] = mapped_column(
        Enum(EscrowStatus, name="escrow_status"), nullable=True
    )
    to_status: Mapped[EscrowStatus] = mapped_column(
        Enum(EscrowStatus, name="escrow_status"), nullable=False
    )
    actor_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    escrow: Mapped["Escrow"] = relationship(back_populates="events")
    actor: Mapped["User | None"] = relationship(foreign_keys=[actor_id])

    def __repr__(self) -> str:  # pragma: no cover - debugging aid only
        return (
            f"<EscrowEvent id={self.id} escrow_id={self.escrow_id} "
            f"{self.from_status}->{self.to_status.value}>"
        )
