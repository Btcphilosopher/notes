"""Enums shared across domain entities.

Kept in one module (rather than scattered per-entity) because several of
these are referenced from more than one entity file, and because seeing
the full vocabulary of statuses in one place makes the state machines
easier to reason about.
"""
import enum


class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"


class UserStatus(str, enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DELETED = "deleted"


class WalletTransactionType(str, enum.Enum):
    """Direction/purpose of a single wallet ledger entry.

    Every entry also carries a signed `amount` (positive = credit,
    negative = debit), so `balance` is always reconstructible by summing
    a wallet's transactions — the ledger is the source of truth, the
    `Wallet.balance` column is a maintained cache of that sum.
    """

    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    ESCROW_HOLD = "escrow_hold"
    ESCROW_RELEASE = "escrow_release"
    ESCROW_REFUND = "escrow_refund"
    FEE = "fee"
    ADJUSTMENT = "adjustment"


class EscrowStatus(str, enum.Enum):
    """The escrow lifecycle. See docs/architecture.md for the full diagram.

    EscrowStateMachine (Phase 5) is the only code path permitted to change
    this value on a persisted Escrow.
    """

    CREATED = "created"
    AWAITING_PAYMENT = "awaiting_payment"
    FUNDED = "funded"
    IN_PROGRESS = "in_progress"
    AWAITING_APPROVAL = "awaiting_approval"
    RELEASED = "released"
    DISPUTED = "disputed"
    REFUNDED = "refunded"
    CANCELLED = "cancelled"
    CLOSED = "closed"


class EscrowTransactionType(str, enum.Enum):
    DEPOSIT = "deposit"
    RELEASE = "release"
    REFUND = "refund"
    FEE = "fee"
    ADJUSTMENT = "adjustment"


class EscrowTransactionStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"


class DisputeStatus(str, enum.Enum):
    OPEN = "open"
    UNDER_REVIEW = "under_review"
    RESOLVED = "resolved"
    CLOSED = "closed"


class DisputeResolution(str, enum.Enum):
    RELEASE_TO_PAYEE = "release_to_payee"
    REFUND_TO_PAYER = "refund_to_payer"
    SPLIT = "split"


class NotificationType(str, enum.Enum):
    ESCROW_CREATED = "escrow_created"
    ESCROW_FUNDED = "escrow_funded"
    ESCROW_RELEASED = "escrow_released"
    ESCROW_REFUNDED = "escrow_refunded"
    ESCROW_CANCELLED = "escrow_cancelled"
    DISPUTE_OPENED = "dispute_opened"
    DISPUTE_RESOLVED = "dispute_resolved"
    SYSTEM = "system"


class NotificationStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    READ = "read"


class APIKeyStatus(str, enum.Enum):
    ACTIVE = "active"
    REVOKED = "revoked"
