"""Redis-backed rate limiting.

A fixed-window counter keyed by (bucket, client IP). Applied as a
dependency on specific endpoints — login and registration are the
classic brute-force/enumeration targets — rather than as blanket
middleware, so each endpoint can set a limit appropriate to its own risk
instead of sharing one number for the whole API.

Disabled under `ENVIRONMENT=test`: the test suite calls these endpoints
many times in quick succession from a single synthetic client address,
which would otherwise trip the limiter and produce flaky, unrelated test
failures. The limiter's own logic is covered directly in
tests/test_rate_limit.py instead, bypassing this gate.
"""
from collections.abc import Awaitable, Callable

from fastapi import Request

from app.core.config import settings
from app.core.exceptions import RateLimitExceededError
from app.core.redis import get_redis


def rate_limit(
    bucket: str, *, limit: int, window_seconds: int
) -> Callable[[Request], Awaitable[None]]:
    """Dependency factory: `Depends(rate_limit("auth-login", limit=10, window_seconds=60))`."""

    async def _check(request: Request) -> None:
        if settings.ENVIRONMENT == "test":
            return

        client_ip = request.client.host if request.client else "unknown"
        key = f"ratelimit:{bucket}:{client_ip}"

        redis = get_redis()
        current = await redis.incr(key)
        if current == 1:
            await redis.expire(key, window_seconds)

        if current > limit:
            raise RateLimitExceededError(
                f"Too many requests to this endpoint — try again in under "
                f"{window_seconds} seconds"
            )

    return _check
