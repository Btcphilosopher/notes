"""FastAPI authentication/authorization dependencies.

`get_current_user` is the single dependency every protected endpoint
depends on. It accepts either an `X-API-Key` header (server-to-server
integration — a marketplace's backend calling this API directly) or an
`Authorization: Bearer <jwt>` header (an interactive user session) —
whichever is present — so the same protected route serves both kinds of
caller without duplicating endpoints. `require_role` layers RBAC on top.
"""
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime

from fastapi import Depends
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import AuthenticationError, AuthorizationError
from app.database.session import get_db
from app.domain.entities.api_key import APIKey
from app.domain.entities.enums import APIKeyStatus, UserRole
from app.domain.entities.user import User
from app.domain.repositories.api_key_repository import SQLAlchemyAPIKeyRepository
from app.domain.repositories.user_repository import SQLAlchemyUserRepository
from app.security.api_keys import hash_api_key
from app.security.jwt import decode_access_token

_bearer_scheme = HTTPBearer(auto_error=False)
_api_key_scheme = APIKeyHeader(name="X-API-Key", auto_error=False)


async def _authenticate_via_api_key(raw_key: str, db: AsyncSession) -> User | None:
    api_keys = SQLAlchemyAPIKeyRepository(db)
    key_row: APIKey | None = await api_keys.get_by_hashed_key(hash_api_key(raw_key))

    if key_row is None or key_row.status != APIKeyStatus.ACTIVE:
        return None
    if key_row.expires_at is not None and key_row.expires_at < datetime.now(UTC):
        return None

    key_row.last_used_at = datetime.now(UTC)
    await db.commit()

    user = await SQLAlchemyUserRepository(db).get_by_id(key_row.user_id)
    return user if user is not None and user.is_active else None


async def _authenticate_via_bearer_token(token: str, db: AsyncSession) -> User | None:
    payload = decode_access_token(token)
    user = await SQLAlchemyUserRepository(db).get_by_id(payload.user_id)
    return user if user is not None and user.is_active else None


async def get_current_user(
    api_key: str | None = Depends(_api_key_scheme),
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    user: User | None = None

    if api_key is not None:
        user = await _authenticate_via_api_key(api_key, db)
    elif credentials is not None:
        user = await _authenticate_via_bearer_token(credentials.credentials, db)

    if user is None:
        raise AuthenticationError("Valid credentials are required for this endpoint")
    return user


def require_role(*allowed_roles: UserRole) -> Callable[..., Awaitable[User]]:
    """Dependency factory for RBAC: `Depends(require_role(UserRole.ADMIN))`."""

    async def _check(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed_roles:
            raise AuthorizationError("Insufficient permissions for this action")
        return current_user

    return _check
