"""Authentication and cryptographic primitives.

- `password.py` — Argon2 password hashing (Passlib).
- `jwt.py` — access token issuance/verification (PyJWT).
- `refresh_tokens.py` — opaque, hashable, individually-revocable refresh
  tokens.
- `api_keys.py` — the same hash-only-storage pattern for API keys.
- `dependencies.py` — `get_current_user` / `require_role`, the FastAPI
  dependencies protected endpoints use.

Idempotency-key + replay-protection helpers for financial endpoints land
in Phase 6, alongside the transaction engine that actually needs them.
"""
