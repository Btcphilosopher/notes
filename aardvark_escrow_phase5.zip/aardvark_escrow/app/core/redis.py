"""Async Redis client.

A single connection pool is created per process (via `lru_cache`) and
reused everywhere a Redis-backed feature needs it: rate limiting today,
Celery result caching and idempotency-key storage from Phase 6/8 onward.
"""
from functools import lru_cache
from typing import cast

import redis.asyncio as aioredis

from app.core.config import settings


@lru_cache
def get_redis() -> aioredis.Redis:
    # redis-py's `from_url` leaves its **kwargs unannotated, which makes
    # mypy --strict treat the call itself as untyped regardless of our
    # own annotations — a library gap, not something fixable here.
    return cast(
        aioredis.Redis,
        aioredis.from_url(settings.REDIS_URL, decode_responses=True),  # type: ignore[no-untyped-call]
    )
