"""User-facing schemas.

`UserPublic` deliberately omits `hashed_password` — it's not that the
field is excluded at serialization time, it's that the schema never
declares the field in the first place, so there's no way for it to leak
through this response model regardless of what future fields get added
to the `User` entity.
"""
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

from app.domain.entities.enums import UserRole, UserStatus
from app.schemas.base import ORMModel
from app.schemas.validators import validate_optional_password_strength


class UserPublic(ORMModel):
    id: UUID
    email: str
    full_name: str
    role: UserRole
    status: UserStatus
    is_verified: bool
    created_at: datetime


class UpdateUserRequest(BaseModel):
    full_name: str | None = Field(default=None, min_length=1, max_length=255)
    email: EmailStr | None = None
    current_password: str | None = Field(default=None, min_length=1, max_length=128)
    new_password: str | None = Field(default=None, min_length=10, max_length=128)

    _validate_new_password = field_validator("new_password")(
        validate_optional_password_strength
    )

    @model_validator(mode="after")
    def _check_request_shape(self) -> "UpdateUserRequest":
        if self.new_password is not None and self.current_password is None:
            raise ValueError("current_password is required to set a new password")
        if not any([self.full_name, self.email, self.new_password]):
            raise ValueError("At least one field must be provided")
        return self
