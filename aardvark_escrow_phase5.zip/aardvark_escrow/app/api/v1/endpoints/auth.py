"""Authentication endpoints: register, login, refresh, logout.

`register` and `login` both return the same `TokenResponse` shape (tokens
+ the authenticated user) so a client can go straight from either call
into an authenticated session without a second round trip.
"""
from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.domain.services.auth_service import AuthResult, AuthService
from app.middleware.rate_limit import rate_limit
from app.schemas.auth import (
    LoginRequest,
    LogoutRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
)
from app.schemas.user import UserPublic

router = APIRouter(prefix="/auth", tags=["auth"])


def _client_context(request: Request) -> tuple[str | None, str | None]:
    ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    return ip, user_agent


def _to_token_response(result: AuthResult) -> TokenResponse:
    return TokenResponse(
        access_token=result.access_token,
        refresh_token=result.refresh_token,
        expires_in=result.expires_in,
        user=UserPublic.model_validate(result.user),
    )


@router.post(
    "/register",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
)
async def register(
    body: RegisterRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _rate_limit: None = Depends(rate_limit("auth-register", limit=5, window_seconds=60)),
) -> TokenResponse:
    ip, user_agent = _client_context(request)
    result = await AuthService(db).register(
        email=body.email,
        password=body.password,
        full_name=body.full_name,
        ip_address=ip,
        user_agent=user_agent,
    )
    return _to_token_response(result)


@router.post("/login", response_model=TokenResponse)
async def login(
    body: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _rate_limit: None = Depends(rate_limit("auth-login", limit=10, window_seconds=60)),
) -> TokenResponse:
    ip, user_agent = _client_context(request)
    result = await AuthService(db).login(
        email=body.email,
        password=body.password,
        ip_address=ip,
        user_agent=user_agent,
    )
    return _to_token_response(result)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    body: RefreshRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _rate_limit: None = Depends(rate_limit("auth-refresh", limit=20, window_seconds=60)),
) -> TokenResponse:
    ip, user_agent = _client_context(request)
    result = await AuthService(db).refresh(
        raw_refresh_token=body.refresh_token,
        ip_address=ip,
        user_agent=user_agent,
    )
    return _to_token_response(result)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(body: LogoutRequest, db: AsyncSession = Depends(get_db)) -> None:
    await AuthService(db).logout(raw_refresh_token=body.refresh_token)
