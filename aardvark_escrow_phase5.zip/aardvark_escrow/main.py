"""Local development entrypoint.

Production containers invoke uvicorn directly against `app.main:app` (see
docker/api.Dockerfile); this file is a convenience for `python main.py`
during local, non-containerised development.
"""
import uvicorn

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
