"""Smoke tests for the health/liveness probes.

These exist from Phase 1 onward so CI has something green to run at every
stage of the build — an empty test suite hides breakage.
"""
import pytest


@pytest.mark.asyncio
async def test_health(client) -> None:
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@pytest.mark.asyncio
async def test_liveness(client) -> None:
    response = await client.get("/api/v1/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "alive"}


@pytest.mark.asyncio
async def test_readiness_checks_database_connectivity(client) -> None:
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ready"}
