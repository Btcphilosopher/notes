"""Integration tests for the wallet endpoints and WalletService.

Run against a real Postgres — the whole point of these tests is proving
the row-locking and ledger discipline actually holds, which a mock
session can't meaningfully verify.
"""
import asyncio
import uuid

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import DomainError, InsufficientFundsError
from app.domain.entities.enums import WalletTransactionType
from app.domain.entities.user import User
from app.domain.entities.wallet import WalletTransaction
from app.domain.services.wallet_service import WalletService


async def _register_and_get_token(client: AsyncClient, email: str) -> str:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": "correct-horse-42", "full_name": "Wallet Tester"},
    )
    return str(response.json()["access_token"])


def _auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def test_get_wallet_lazily_provisions_a_zero_balance_wallet(
    client: AsyncClient,
) -> None:
    token = await _register_and_get_token(client, "wallet1@example.com")
    response = await client.get("/api/v1/wallet", headers=_auth_headers(token))

    assert response.status_code == 200
    body = response.json()
    assert body["balance"] == "0.00"
    assert body["held_balance"] == "0.00"
    assert body["available_balance"] == "0.00"
    assert body["currency"] == "GBP"


async def test_get_wallet_is_idempotent_and_returns_the_same_wallet(
    client: AsyncClient,
) -> None:
    token = await _register_and_get_token(client, "wallet2@example.com")
    first = await client.get("/api/v1/wallet", headers=_auth_headers(token))
    second = await client.get("/api/v1/wallet", headers=_auth_headers(token))

    assert first.json()["id"] == second.json()["id"]


async def test_deposit_increases_balance(client: AsyncClient) -> None:
    token = await _register_and_get_token(client, "wallet3@example.com")
    response = await client.post(
        "/api/v1/wallet/deposit",
        headers=_auth_headers(token),
        json={"amount": "150.00", "description": "Top-up"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["balance"] == "150.00"
    assert body["available_balance"] == "150.00"


async def test_withdraw_decreases_balance(client: AsyncClient) -> None:
    token = await _register_and_get_token(client, "wallet4@example.com")
    await client.post(
        "/api/v1/wallet/deposit",
        headers=_auth_headers(token),
        json={"amount": "100.00"},
    )
    response = await client.post(
        "/api/v1/wallet/withdraw",
        headers=_auth_headers(token),
        json={"amount": "40.00"},
    )

    assert response.status_code == 200
    assert response.json()["balance"] == "60.00"


async def test_withdraw_more_than_balance_is_rejected(client: AsyncClient) -> None:
    token = await _register_and_get_token(client, "wallet5@example.com")
    response = await client.post(
        "/api/v1/wallet/withdraw",
        headers=_auth_headers(token),
        json={"amount": "10.00"},
    )

    assert response.status_code == 422
    assert "Insufficient" in response.json()["detail"]


async def test_deposit_rejects_zero_and_negative_amounts(client: AsyncClient) -> None:
    token = await _register_and_get_token(client, "wallet6@example.com")

    zero_response = await client.post(
        "/api/v1/wallet/deposit", headers=_auth_headers(token), json={"amount": "0"}
    )
    assert zero_response.status_code == 422

    negative_response = await client.post(
        "/api/v1/wallet/deposit", headers=_auth_headers(token), json={"amount": "-5.00"}
    )
    assert negative_response.status_code == 422


async def test_deposit_creates_a_ledger_entry(
    client: AsyncClient, db_session: AsyncSession
) -> None:
    token = await _register_and_get_token(client, "wallet7@example.com")
    wallet_response = await client.get("/api/v1/wallet", headers=_auth_headers(token))
    wallet_id = uuid.UUID(wallet_response.json()["id"])

    await client.post(
        "/api/v1/wallet/deposit",
        headers=_auth_headers(token),
        json={"amount": "75.50", "description": "Test deposit"},
    )

    result = await db_session.execute(
        select(WalletTransaction).where(WalletTransaction.wallet_id == wallet_id)
    )
    transactions = result.scalars().all()
    assert len(transactions) == 1
    assert transactions[0].type == WalletTransactionType.DEPOSIT
    assert transactions[0].amount == 75.50
    assert transactions[0].description == "Test deposit"


async def test_deposit_with_idempotency_key_is_not_double_applied(
    client: AsyncClient,
) -> None:
    token = await _register_and_get_token(client, "wallet8@example.com")
    key = str(uuid.uuid4())

    first = await client.post(
        "/api/v1/wallet/deposit",
        headers=_auth_headers(token),
        json={"amount": "20.00", "idempotency_key": key},
    )
    second = await client.post(
        "/api/v1/wallet/deposit",
        headers=_auth_headers(token),
        json={"amount": "20.00", "idempotency_key": key},
    )

    assert first.status_code == 200
    assert second.status_code == 200
    # The replay must return the original state, not apply a second +20.
    assert first.json()["balance"] == second.json()["balance"] == "20.00"


async def test_concurrent_deposits_are_serialised_correctly(client: AsyncClient) -> None:
    """Ten concurrent £10 deposits must land on exactly £100 — not less,
    which is what would happen if the row lock in WalletService.deposit
    didn't actually serialise the read-modify-write of `balance`.
    """
    token = await _register_and_get_token(client, "wallet9@example.com")

    async def _deposit() -> None:
        await client.post(
            "/api/v1/wallet/deposit",
            headers=_auth_headers(token),
            json={"amount": "10.00"},
        )

    await asyncio.gather(*(_deposit() for _ in range(10)))

    final = await client.get("/api/v1/wallet", headers=_auth_headers(token))
    assert final.json()["balance"] == "100.00"


async def test_wallet_service_rejects_non_positive_amounts_directly(
    db_session: AsyncSession,
) -> None:
    user = User(email="direct-service-1@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.commit()

    service = WalletService(db_session)
    wallet = await service.get_or_create_wallet(user.id)

    with pytest.raises(DomainError):
        await service.deposit(wallet.user_id, amount=0, description="x")

    with pytest.raises(DomainError):
        await service.withdraw(wallet.user_id, amount=-1, description="x")


async def test_wallet_service_raises_insufficient_funds(db_session: AsyncSession) -> None:
    user = User(email="direct-service-2@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.commit()

    service = WalletService(db_session)
    await service.get_or_create_wallet(user.id)

    with pytest.raises(InsufficientFundsError):
        await service.withdraw(user.id, amount=5, description="x")


async def test_concurrent_first_wallet_creation_resolves_to_one_wallet(
    db_session: AsyncSession,
) -> None:
    """Many concurrent *first-ever* calls for the same user's wallet must
    all resolve to the same single row rather than erroring — this is the
    unique-constraint race in `get_or_create_wallet`, distinct from the
    row-lock race in `deposit`/`withdraw` covered above.

    Uses genuinely separate sessions (like separate HTTP requests would
    get from `get_db`), since a single shared AsyncSession can't process
    concurrent statements at all.
    """
    from app.database.session import AsyncSessionLocal

    user = User(email="wallet-race@example.com", hashed_password="x", full_name="X")
    db_session.add(user)
    await db_session.commit()
    user_id = user.id

    async def _get_or_create() -> uuid.UUID:
        async with AsyncSessionLocal() as session:
            wallet = await WalletService(session).get_or_create_wallet(user_id)
            return wallet.id

    wallet_ids = await asyncio.gather(*(_get_or_create() for _ in range(8)))
    assert len(set(wallet_ids)) == 1
