"""Integration tests for the escrow endpoints (create, list, get, cancel).

fund/approve/release/refund aren't tested here — they don't exist yet,
see app.domain.services.escrow_service's docstring for why.
"""
from httpx import AsyncClient

PASSWORD = "correct-horse-42"


async def _register(client: AsyncClient, email: str, full_name: str = "Test User") -> str:
    response = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": PASSWORD, "full_name": full_name},
    )
    return str(response.json()["access_token"])


def _headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


async def _create_escrow(
    client: AsyncClient, payer_token: str, payee_email: str, amount: str = "500.00"
):
    return await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={
            "payee_email": payee_email,
            "amount": amount,
            "description": "Freelance logo design milestone 1",
        },
    )


async def test_create_escrow_lands_on_awaiting_payment(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer1@example.com", "Payer")
    await _register(client, "payee1@example.com", "Payee")

    response = await _create_escrow(client, payer_token, "payee1@example.com")

    assert response.status_code == 201
    body = response.json()
    assert body["status"] == "awaiting_payment"
    assert body["amount"] == "500.00"
    assert body["currency"] == "GBP"
    assert body["funded_at"] is None


async def test_create_escrow_with_unknown_payee_is_rejected(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer2@example.com", "Payer")

    response = await _create_escrow(client, payer_token, "nobody@example.com")

    assert response.status_code == 404


async def test_create_escrow_with_self_as_payee_is_rejected(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer3@example.com", "Payer")

    response = await _create_escrow(client, payer_token, "payer3@example.com")

    assert response.status_code == 422


async def test_create_escrow_rejects_non_positive_amount(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer4@example.com", "Payer")
    await _register(client, "payee4@example.com", "Payee")

    response = await client.post(
        "/api/v1/escrows",
        headers=_headers(payer_token),
        json={"payee_email": "payee4@example.com", "amount": "0.00", "description": "x"},
    )

    assert response.status_code == 422


async def test_create_escrow_requires_authentication(client: AsyncClient) -> None:
    response = await client.post(
        "/api/v1/escrows",
        json={"payee_email": "nobody@example.com", "amount": "10.00", "description": "x"},
    )
    assert response.status_code == 401


async def test_list_escrows_only_shows_the_current_users_escrows(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer5@example.com", "Payer")
    payee_token = await _register(client, "payee5@example.com", "Payee")
    outsider_token = await _register(client, "outsider5@example.com", "Outsider")

    await _create_escrow(client, payer_token, "payee5@example.com")

    payer_list = await client.get("/api/v1/escrows", headers=_headers(payer_token))
    payee_list = await client.get("/api/v1/escrows", headers=_headers(payee_token))
    outsider_list = await client.get("/api/v1/escrows", headers=_headers(outsider_token))

    assert len(payer_list.json()) == 1
    assert len(payee_list.json()) == 1
    assert len(outsider_list.json()) == 0


async def test_get_escrow_by_id_succeeds_for_payer_and_payee(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer6@example.com", "Payer")
    payee_token = await _register(client, "payee6@example.com", "Payee")

    create_response = await _create_escrow(client, payer_token, "payee6@example.com")
    escrow_id = create_response.json()["id"]

    payer_get = await client.get(f"/api/v1/escrows/{escrow_id}", headers=_headers(payer_token))
    payee_get = await client.get(f"/api/v1/escrows/{escrow_id}", headers=_headers(payee_token))

    assert payer_get.status_code == 200
    assert payee_get.status_code == 200
    assert payer_get.json()["id"] == escrow_id


async def test_get_escrow_by_id_hides_it_from_unrelated_users(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer7@example.com", "Payer")
    await _register(client, "payee7@example.com", "Payee")
    outsider_token = await _register(client, "outsider7@example.com", "Outsider")

    create_response = await _create_escrow(client, payer_token, "payee7@example.com")
    escrow_id = create_response.json()["id"]

    response = await client.get(
        f"/api/v1/escrows/{escrow_id}", headers=_headers(outsider_token)
    )
    assert response.status_code == 404


async def test_get_nonexistent_escrow_returns_404(client: AsyncClient) -> None:
    token = await _register(client, "payer8@example.com", "Payer")
    response = await client.get(
        "/api/v1/escrows/00000000-0000-0000-0000-000000000000", headers=_headers(token)
    )
    assert response.status_code == 404


async def test_cancel_escrow_transitions_to_cancelled(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer9@example.com", "Payer")
    await _register(client, "payee9@example.com", "Payee")

    create_response = await _create_escrow(client, payer_token, "payee9@example.com")
    escrow_id = create_response.json()["id"]

    cancel_response = await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel",
        headers=_headers(payer_token),
        json={"reason": "Changed my mind"},
    )

    assert cancel_response.status_code == 200
    body = cancel_response.json()
    assert body["status"] == "cancelled"
    assert body["cancelled_at"] is not None


async def test_payee_can_also_cancel_before_funding(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer10@example.com", "Payer")
    payee_token = await _register(client, "payee10@example.com", "Payee")

    create_response = await _create_escrow(client, payer_token, "payee10@example.com")
    escrow_id = create_response.json()["id"]

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(payee_token), json={}
    )
    assert response.status_code == 200
    assert response.json()["status"] == "cancelled"


async def test_cancelling_an_already_cancelled_escrow_is_rejected(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer11@example.com", "Payer")
    await _register(client, "payee11@example.com", "Payee")

    create_response = await _create_escrow(client, payer_token, "payee11@example.com")
    escrow_id = create_response.json()["id"]

    await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(payer_token), json={}
    )
    second_cancel = await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(payer_token), json={}
    )

    assert second_cancel.status_code == 422


async def test_unrelated_user_cannot_cancel_someone_elses_escrow(client: AsyncClient) -> None:
    payer_token = await _register(client, "payer12@example.com", "Payer")
    await _register(client, "payee12@example.com", "Payee")
    outsider_token = await _register(client, "outsider12@example.com", "Outsider")

    create_response = await _create_escrow(client, payer_token, "payee12@example.com")
    escrow_id = create_response.json()["id"]

    response = await client.post(
        f"/api/v1/escrows/{escrow_id}/cancel", headers=_headers(outsider_token), json={}
    )
    assert response.status_code == 404
