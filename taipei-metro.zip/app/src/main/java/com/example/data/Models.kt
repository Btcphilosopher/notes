package com.example.data

import androidx.compose.ui.graphics.Color

// Station model representing a Taipei MRT station
data class Station(
    val id: String,          // e.g., "BL12"
    val code: String,        // e.g., "BL12" or "R10"
    val nameZh: String,      // e.g., "台北車站"
    val nameEn: String,      // e.g., "Taipei Main Station"
    val nameNan: String,     // e.g., "台北車站" (Hokkien: Tâi-pak-tsām)
    val lines: List<String>, // List of line IDs, e.g., listOf("BL", "R")
    val latitude: Double,
    val longitude: Double,
    val x: Float,            // Schematic x coordinate (0.0f to 1.0f)
    val y: Float,            // Schematic y coordinate (0.0f to 1.0f)
    val exits: List<StationExit> = emptyList()
) {
    fun name(lang: String): String = when (lang) {
        "en" -> nameEn
        "nan-TW" -> nameNan
        else -> nameZh
    }
}

// StationExit model representing exits at a station
data class StationExit(
    val id: String,          // e.g., "1"
    val nameZh: String,      // e.g., "出口 1"
    val nameEn: String,      // e.g., "Exit 1"
    val nameNan: String,     // e.g., "出口 1"
    val landmarksZh: List<String>,
    val landmarksEn: List<String>,
    val landmarksNan: List<String>,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val directionsZh: String = "",
    val directionsEn: String = "",
    val directionsNan: String = ""
) {
    fun name(lang: String): String = when (lang) {
        "en" -> nameEn
        "nan-TW" -> nameNan
        else -> nameZh
    }
}

// Line model representing an MRT Line (e.g. Bannan, Tamsui-Xinyi)
data class Line(
    val id: String,          // e.g., "BL"
    val code: String,        // e.g., "BL"
    val nameZh: String,      // e.g., "板南線"
    val nameEn: String,      // e.g., "Bannan Line"
    val nameNan: String,     // e.g., "板南線"
    val hexColor: String,    // e.g., "#0070BC"
    val stations: List<String> // List of station IDs in sequence
) {
    val color: Color get() = Color(android.graphics.Color.parseColor(hexColor))
    
    fun name(lang: String): String = when (lang) {
        "en" -> nameEn
        "nan-TW" -> nameNan
        else -> nameZh
    }
}

// Route model
data class Route(
    val id: String,
    val lineId: String,
    val directionZh: String,
    val directionEn: String,
    val directionNan: String
) {
    fun direction(lang: String): String = when (lang) {
        "en" -> directionEn
        "nan-TW" -> directionNan
        else -> directionZh
    }
}

// Departure model representing dynamic arrivals
data class Departure(
    val id: String,
    val lineId: String,
    val destinationZh: String,
    val destinationEn: String,
    val destinationNan: String,
    val minutesAway: Int
) {
    fun destination(lang: String): String = when (lang) {
        "en" -> destinationEn
        "nan-TW" -> destinationNan
        else -> destinationZh
    }
}

// Disruption model representing delays
data class Disruption(
    val id: String,
    val lineId: String,
    val titleZh: String,
    val titleEn: String,
    val titleNan: String,
    val descZh: String,
    val descEn: String,
    val descNan: String,
    val affectedStations: List<String>,
    val alternativeRouteZh: String,
    val alternativeRouteEn: String,
    val alternativeRouteNan: String,
    val estRecoveryZh: String,
    val estRecoveryEn: String,
    val estRecoveryNan: String
) {
    fun title(lang: String): String = when (lang) {
        "en" -> titleEn
        "nan-TW" -> titleNan
        else -> titleZh
    }
    fun desc(lang: String): String = when (lang) {
        "en" -> descEn
        "nan-TW" -> descNan
        else -> descZh
    }
    fun alternativeRoute(lang: String): String = when (lang) {
        "en" -> alternativeRouteEn
        "nan-TW" -> alternativeRouteNan
        else -> alternativeRouteZh
    }
    fun estRecovery(lang: String): String = when (lang) {
        "en" -> estRecoveryEn
        "nan-TW" -> estRecoveryNan
        else -> estRecoveryZh
    }
}

// Journey representation
data class Journey(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val durationMinutes: Int,
    val legs: List<JourneyLeg>,
    val walkDistanceMeters: Int,
    val transfersCount: Int,
    val type: JourneyType // FASTEST, FEWEST_TRANSFERS, LEAST_WALKING, ACCESSIBLE
)

enum class JourneyType {
    FASTEST, FEWEST_TRANSFERS, LEAST_WALKING, ACCESSIBLE
}

// JourneyLeg representing an intermediate section of a journey
data class JourneyLeg(
    val id: String,
    val lineId: String?, // Null means walking transfer
    val fromStationId: String,
    val toStationId: String,
    val durationMinutes: Int,
    val stopCount: Int,
    val descriptionZh: String,
    val descriptionEn: String,
    val descriptionNan: String,
    val platformInfo: String? = null
) {
    fun description(lang: String): String = when (lang) {
        "en" -> descriptionEn
        "nan-TW" -> descriptionNan
        else -> descriptionZh
    }
}

// Transfer model representing transfer details between lines
data class Transfer(
    val stationId: String,
    val fromLineId: String,
    val toLineId: String,
    val walkingTimeMinutes: Int,
    val guideInstructionsZh: String,
    val guideInstructionsEn: String,
    val guideInstructionsNan: String
) {
    fun guideInstructions(lang: String): String = when (lang) {
        "en" -> guideInstructionsEn
        "nan-TW" -> guideInstructionsNan
        else -> guideInstructionsZh
    }
}

// Ticket structures
enum class TicketType {
    SINGLE, DAY_PASS, MULTI_DAY, OTHER
}

data class Ticket(
    val id: String,
    val type: TicketType,
    val nameZh: String,
    val nameEn: String,
    val nameNan: String,
    val priceTwd: Double,
    val passengerCount: Int = 1,
    val validityDescZh: String = "限當日有效",
    val validityDescEn: String = "Valid today only",
    val validityDescNan: String = "限今日有效",
    val ticketId: String = "", // e.g., "TPM-2849-0192"
    val isDemo: Boolean = true
) {
    fun name(lang: String): String = when (lang) {
        "en" -> nameEn
        "nan-TW" -> nameNan
        else -> nameZh
    }
    fun validity(lang: String): String = when (lang) {
        "en" -> validityDescEn
        "nan-TW" -> validityDescNan
        else -> validityDescZh
    }
}

// Favourites Representation
data class Favourite(
    val id: String,
    val type: FavouriteType,
    val targetId: String, // Station ID or Route composite ID
    val nameZh: String,
    val nameEn: String,
    val nameNan: String
) {
    fun name(lang: String): String = when (lang) {
        "en" -> nameEn
        "nan-TW" -> nameNan
        else -> nameZh
    }
}

enum class FavouriteType {
    STATION, ROUTE, DESTINATION
}
