package com.example.data

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object LocalizationManager {
    private val cache = mutableMapOf<String, Map<String, String>>()
    
    private val fallbackZh = mapOf(
        "app_name" to "台北捷運",
        "nav_home" to "首頁",
        "nav_routes" to "路線",
        "nav_map" to "地圖",
        "nav_tickets" to "車票",
        "nav_more" to "更多",
        "where_to" to "要去哪裡？",
        "from" to "起點",
        "to" to "目的地",
        "plan_route" to "規劃路線",
        "choose_station" to "選擇車站",
        "favourites" to "我的最愛",
        "quick_destinations" to "常用地點",
        "home_favorite" to "家",
        "work_favorite" to "公司",
        "next_train" to "下一班列車",
        "minutes_unit" to "分鐘",
        "view_exits" to "查看出口",
        "departures" to "查看班次",
        "live_departures" to "即時到站",
        "line_explorer" to "路線探索",
        "accessible_facilities" to "無障礙設施",
        "elevator" to "電梯",
        "escalator" to "手扶梯",
        "buy_ticket" to "購買車票",
        "my_tickets" to "我的車票",
        "single_journey" to "單程票",
        "day_pass" to "一日票",
        "multi_day_pass" to "多日票",
        "other_passes" to "其他票種",
        "demo_fare" to "測試票價",
        "payment_processing" to "付款中...",
        "payment_success" to "付款完成",
        "ticket_generating" to "車票生成...",
        "ticket_ready" to "車票準備完成",
        "show_ticket" to "顯示車票",
        "digital_ticket" to "虛擬車票",
        "passenger" to "乘客人數",
        "valid" to "有效期限",
        "ticket_id" to "車票編號",
        "today" to "今天",
        "normal_status" to "🟢 所有路線正常",
        "disruption_status" to "🟠 板南線列車延誤",
        "estimated_recovery" to "估計恢復時間",
        "affected_stations" to "受影響車站",
        "description" to "說明",
        "alternative_route" to "替代路線",
        "language" to "語言",
        "dark_mode" to "深色模式",
        "settings" to "設定",
        "search_placeholder" to "搜尋車站、代碼、拼音...",
        "recent_searches" to "最近搜尋",
        "no_results" to "找不到相符車站"
    )
    
    private val fallbackEn = mapOf(
        "app_name" to "Taipei Metro",
        "nav_home" to "Home",
        "nav_routes" to "Routes",
        "nav_map" to "Map",
        "nav_tickets" to "Tickets",
        "nav_more" to "More",
        "where_to" to "Where are you going?",
        "from" to "From",
        "to" to "To",
        "plan_route" to "PLAN ROUTE",
        "choose_station" to "Choose station",
        "favourites" to "Favourites",
        "quick_destinations" to "Quick Destinations",
        "home_favorite" to "Home",
        "work_favorite" to "Work",
        "next_train" to "Next Train",
        "minutes_unit" to "min",
        "view_exits" to "VIEW EXITS",
        "departures" to "DEPARTURES",
        "live_departures" to "LIVE DEPARTURES",
        "line_explorer" to "Line Explorer",
        "accessible_facilities" to "Accessibility",
        "elevator" to "Elevator",
        "escalator" to "Escalator",
        "buy_ticket" to "BUY TICKET",
        "my_tickets" to "MY TICKETS",
        "single_journey" to "Single Journey",
        "day_pass" to "Day Pass",
        "multi_day_pass" to "Multi-Day Pass",
        "other_passes" to "Other Passes",
        "demo_fare" to "DEMO FARE",
        "payment_processing" to "Processing...",
        "payment_success" to "Paid Successfully",
        "ticket_generating" to "Generating Ticket...",
        "ticket_ready" to "Ticket Ready",
        "show_ticket" to "SHOW TICKET",
        "digital_ticket" to "DIGITAL TICKET",
        "passenger" to "Passenger",
        "valid" to "Valid",
        "ticket_id" to "Ticket ID",
        "today" to "Today",
        "normal_status" to "🟢 All lines operating normally",
        "disruption_status" to "🟠 Line delays",
        "estimated_recovery" to "Est. Recovery",
        "affected_stations" to "Affected Stations",
        "description" to "Description",
        "alternative_route" to "Alternative Route",
        "language" to "Language",
        "dark_mode" to "Dark Mode",
        "settings" to "Settings",
        "search_placeholder" to "Search station, code, name...",
        "recent_searches" to "Recent Searches",
        "no_results" to "No stations found"
    )
    
    private val fallbackNan = mapOf(
        "app_name" to "台北捷運",
        "nav_home" to "首頁",
        "nav_routes" to "路線",
        "nav_map" to "地圖",
        "nav_tickets" to "車票",
        "nav_more" to "閣有",
        "where_to" to "欲去佗位？",
        "from" to "起點",
        "to" to "目的地",
        "plan_route" to "規劃路線",
        "choose_station" to "選捷運站",
        "favourites" to "我的最愛",
        "quick_destinations" to "捷去的地",
        "home_favorite" to "阮兜",
        "work_favorite" to "公司",
        "next_train" to "下一班車",
        "minutes_unit" to "分鐘",
        "view_exits" to "看出口",
        "departures" to "看車次",
        "live_departures" to "即時到站",
        "line_explorer" to "路線搜尋",
        "accessible_facilities" to "無障礙設施",
        "elevator" to "電梯",
        "escalator" to "電扶梯",
        "buy_ticket" to "買車票",
        "my_tickets" to "我的車票",
        "single_journey" to "單程票",
        "day_pass" to "一日票",
        "multi_day_pass" to "多日票",
        "other_passes" to "其他票種",
        "demo_fare" to "測試票價",
        "payment_processing" to "付款中...",
        "payment_success" to "付款完成",
        "ticket_generating" to "車票生成...",
        "ticket_ready" to "車票準備好勢",
        "show_ticket" to "顯出車票",
        "digital_ticket" to "虛擬車票",
        "passenger" to "乘客人數",
        "valid" to "有效期限",
        "ticket_id" to "車票編號",
        "today" to "今仔日",
        "normal_status" to "🟢 所有路線正常",
        "disruption_status" to "🟠 路線列車延延誤",
        "estimated_recovery" to "估計恢復時間",
        "affected_stations" to "受影響車站",
        "description" to "說明",
        "alternative_route" to "替代路線",
        "language" to "語言",
        "dark_mode" to "暗頭模式",
        "settings" to "設定",
        "search_placeholder" to "搜揣車站、代碼、名字...",
        "recent_searches" to "最近搜尋",
        "no_results" to "揣無相符的捷運站"
    )

    fun getString(key: String, lang: String, context: Context? = null): String {
        val dict = getDictionary(lang, context)
        return dict[key] ?: fallbackZh[key] ?: key
    }

    private fun getDictionary(lang: String, context: Context?): Map<String, String> {
        val cached = cache[lang]
        if (cached != null) return cached

        if (context == null) {
            return getDefaultFallback(lang)
        }

        try {
            val fileName = "localization/$lang.json"
            val inputStream = context.assets.open(fileName)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val jsonString = reader.use { it.readText() }
            val jsonObject = JSONObject(jsonString)
            
            val map = mutableMapOf<String, String>()
            jsonObject.keys().forEach { key ->
                map[key] = jsonObject.getString(key)
            }
            cache[lang] = map
            return map
        } catch (e: Exception) {
            return getDefaultFallback(lang)
        }
    }

    private fun getDefaultFallback(lang: String): Map<String, String> = when (lang) {
        "en" -> fallbackEn
        "nan-TW" -> fallbackNan
        else -> fallbackZh
    }
}
