package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.MutedText
import com.example.ui.theme.TaipeiMetroTheme
import com.example.ui.theme.TaiwanRed

class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge-to-edge content support
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()

            TaipeiMetroTheme(darkTheme = isDarkMode) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Render five-tab navigation ONLY on standard application screens
                        if (currentScreen != Screen.Splash && currentScreen != Screen.LanguageSelection) {
                            AppNavigationBar(
                                currentScreen = currentScreen,
                                onNavigate = { screen -> viewModel.navigateTo(screen) },
                                viewModel = viewModel
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "screen_transition"
                        ) { screen ->
                            when (screen) {
                                is Screen.Splash -> SplashScreen(viewModel)
                                is Screen.LanguageSelection -> LanguageSelectionScreen(viewModel)
                                is Screen.Home -> HomeScreen(viewModel)
                                is Screen.StationSearch -> StationSearchScreen(viewModel, screen.isSelectingFrom)
                                is Screen.JourneyResults -> JourneyResultsScreen(viewModel)
                                is Screen.JourneyDetail -> JourneyDetailScreen(viewModel)
                                is Screen.Map -> MRTMapScreen(viewModel)
                                is Screen.StationDetail -> {
                                    val s = com.example.data.TransitService.getStationById(screen.stationId)
                                    if (s != null) {
                                        StationBottomSheetContent(
                                            station = s,
                                            viewModel = viewModel,
                                            onDismiss = { viewModel.navigateBack() }
                                        )
                                    }
                                }
                                is Screen.StationExits -> StationExitsScreen(viewModel, screen.stationId)
                                is Screen.LiveDepartures -> LiveDeparturesScreen(viewModel, screen.stationId)
                                is Screen.LineExplorer -> LineExplorerScreen(viewModel)
                                is Screen.DisruptionDetail -> DisruptionDetailScreen(viewModel, screen.disruptionId)
                                is Screen.BuyTicket -> BuyTicketScreen(viewModel)
                                is Screen.TicketSelection -> TicketSelectionScreen(viewModel, screen.ticketType)
                                is Screen.PaymentDemo -> PaymentDemoScreen(
                                    viewModel, 
                                    screen.ticketType, 
                                    screen.price, 
                                    screen.nameZh, 
                                    screen.nameEn, 
                                    screen.nameNan
                                )
                                is Screen.TicketConfirmation -> TicketConfirmationScreen(viewModel, screen.ticketId)
                                is Screen.MyTickets -> MyTicketsScreen(viewModel)
                                is Screen.DigitalTicket -> DigitalTicketScreen(viewModel, screen.ticketId)
                                is Screen.FavouriteJourneys -> FavouriteJourneysScreen(viewModel)
                                is Screen.Settings -> SettingsScreen(viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Section 4: 5-Section Bottom Navigation Bar ---
@Composable
fun AppNavigationBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    viewModel: AppViewModel
) {
    NavigationBar(
        modifier = Modifier.testTag("app_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        // Tab 1: Home
        val isHomeActive = currentScreen is Screen.Home || currentScreen is Screen.StationSearch || currentScreen is Screen.JourneyResults || currentScreen is Screen.JourneyDetail
        NavigationBarItem(
            selected = isHomeActive,
            onClick = { onNavigate(Screen.Home) },
            icon = { Icon(imageVector = if (isHomeActive) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
            label = { Text(text = viewModel.getString("nav_home"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        )

        // Tab 2: Routes (Line Explorer)
        val isRoutesActive = currentScreen is Screen.LineExplorer
        NavigationBarItem(
            selected = isRoutesActive,
            onClick = { onNavigate(Screen.LineExplorer) },
            icon = { Icon(imageVector = if (isRoutesActive) Icons.Filled.TrendingUp else Icons.Outlined.TrendingUp, contentDescription = "Routes") },
            label = { Text(text = viewModel.getString("nav_routes"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        )

        // Tab 3: Map
        val isMapActive = currentScreen is Screen.Map
        NavigationBarItem(
            selected = isMapActive,
            onClick = { onNavigate(Screen.Map) },
            icon = { Icon(imageVector = if (isMapActive) Icons.Filled.Map else Icons.Outlined.Map, contentDescription = "Map") },
            label = { Text(text = viewModel.getString("nav_map"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        )

        // Tab 4: Tickets
        val isTicketsActive = currentScreen is Screen.BuyTicket || currentScreen is Screen.TicketSelection || currentScreen is Screen.MyTickets || currentScreen is Screen.DigitalTicket
        NavigationBarItem(
            selected = isTicketsActive,
            onClick = { onNavigate(Screen.BuyTicket) },
            icon = { Icon(imageVector = if (isTicketsActive) Icons.Filled.ConfirmationNumber else Icons.Outlined.ConfirmationNumber, contentDescription = "Tickets") },
            label = { Text(text = viewModel.getString("nav_tickets"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        )

        // Tab 5: Settings / More
        val isSettingsActive = currentScreen is Screen.Settings
        NavigationBarItem(
            selected = isSettingsActive,
            onClick = { onNavigate(Screen.Settings) },
            icon = { Icon(imageVector = if (isSettingsActive) Icons.Filled.Settings else Icons.Outlined.Settings, contentDescription = "More") },
            label = { Text(text = viewModel.getString("nav_more"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        )
    }
}

// --- Screen 19 Supplement: Favourite Journeys List ---
@Composable
fun FavouriteJourneysScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val favs by viewModel.favouriteJourneys.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = viewModel.getString("favourites"),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (favs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "尚無最愛路線 No Favourites Saved", color = MutedText)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(favs) { pair ->
                    val fromId = pair.first
                    val toId = pair.second
                    val from = com.example.data.TransitService.getStationById(fromId)
                    val to = com.example.data.TransitService.getStationById(toId)
                    if (from != null && to != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setFromStation(from)
                                    viewModel.setToStation(to)
                                    viewModel.navigateTo(Screen.JourneyResults)
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Star, contentDescription = "Favourite", tint = com.example.ui.theme.TaiwanRed)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = "${from.name(lang)} → ${to.name(lang)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "Tap to search routes immediately",
                                        fontSize = 12.sp,
                                        color = MutedText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
