package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color.White,
    secondary = TaiwanRed,
    tertiary = CoolGrey,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = NearBlack,
    onSecondary = Color.White,
    onTertiary = NearBlack,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFE5E5EA)
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    secondary = TaiwanRed,
    tertiary = Charcoal,
    background = LightBackground,
    surface = LightSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = NearBlack,
    onSurface = NearBlack,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Charcoal
)

@Composable
fun TaipeiMetroTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TaipeiMetroTheme(darkTheme = darkTheme, content = content)
}
