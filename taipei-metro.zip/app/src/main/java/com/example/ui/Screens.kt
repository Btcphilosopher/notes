package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AppViewModel
import com.example.Screen
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// --- Shared Premium Components ---

@Composable
fun MRTLineBadge(lineId: String, modifier: Modifier = Modifier) {
    val line = TransitService.lines.find { it.id == lineId } ?: return
    Box(
        modifier = modifier
            .background(line.color, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = line.code,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DisruptionStatusBar(viewModel: AppViewModel, modifier: Modifier = Modifier) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val disruptions by viewModel.activeDisruptions.collectAsState()
    
    val isDisrupted = disruptions.isNotEmpty()
    val text = if (isDisrupted) {
        disruptions.first().title(lang)
    } else {
        viewModel.getString("normal_status")
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(enabled = isDisrupted) {
                if (isDisrupted) {
                    viewModel.navigateTo(Screen.DisruptionDetail(disruptions.first().id))
                }
            },
        colors = CardDefaults.cardColors(
            containerColor = if (isDisrupted) TaiwanRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isDisrupted) TaiwanRed.copy(alpha = 0.4f) else Color.Transparent
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        if (isDisrupted) TaiwanRed else Color(0xFF4CD964),
                        CircleShape
                    )
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = text,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            if (isDisrupted) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Details",
                    tint = TaiwanRed,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// --- SCREEN 1: SPLASH SCREEN ---
@Composable
fun SplashScreen(viewModel: AppViewModel) {
    var startAnimation by remember { mutableStateOf(false) }
    val scale = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.85f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "logo_scale"
    )
    val opacity = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 800),
        label = "logo_opacity"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(1200)
        viewModel.navigateTo(Screen.LanguageSelection)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer(scaleX = scale.value, scaleY = scale.value, alpha = opacity.value)
        ) {
            // Elegant Schematic MRT Logo Icon Design
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .background(TaiwanRed, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Train,
                    contentDescription = "Taipei Metro",
                    tint = Color.White,
                    modifier = Modifier.size(56.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "台北捷運",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "TAIPEI METRO",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp
            )
        }
    }
}

// --- SCREEN 2: LANGUAGE SELECTION ---
@Composable
fun LanguageSelectionScreen(viewModel: AppViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "請選擇語言",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Please select your language",
                fontSize = 13.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
            )

            // Trilingual Buttons
            val options = listOf(
                Triple("zh-TW", "繁體中文", "Traditional Chinese"),
                Triple("en", "English", "English"),
                Triple("nan-TW", "台語", "Taiwanese Hokkien")
            )

            options.forEach { (code, label, desc) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .testTag("lang_btn_$code")
                        .clickable {
                            viewModel.changeLanguage(code)
                            viewModel.navigateToHome()
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(TaiwanRed.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = code.take(2).uppercase(),
                                color = TaiwanRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = label,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = desc,
                                fontSize = 12.sp,
                                color = MutedText
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Select",
                            tint = MutedText
                        )
                    }
                }
            }
        }
    }
}

// --- SCREEN 3: HOME SCREEN (MAIN EXPERIENCE) ---
@Composable
fun HomeScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val fromStation by viewModel.fromStation.collectAsState()
    val toStation by viewModel.toStation.collectAsState()
    val favouriteStations by viewModel.favouriteStations.collectAsState()
    val favouriteJourneys by viewModel.favouriteJourneys.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // App Header / Signage
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = viewModel.getString("app_name"),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "TAIPEI METRO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = MutedText
                    )
                }
                
                // Minimalist Dark mode toggle & Language Switcher
                IconButton(
                    onClick = { viewModel.toggleDarkMode() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.LightMode,
                        contentDescription = "Theme",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(
                    onClick = { viewModel.navigateTo(Screen.LanguageSelection) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Language",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Disruptions indicator
        item {
            DisruptionStatusBar(viewModel)
        }

        // --- JOURNEY PLANNER BOX ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("journey_planner_card"),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left timeline column
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .border(2.dp, MutedText, CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .height(44.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            )
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(ColorR, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Right Inputs column
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Origin Input
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.navigateTo(Screen.StationSearch(isSelectingFrom = true)) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = viewModel.getString("from").uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MutedText
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = fromStation?.name(lang) ?: viewModel.getString("from"),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (fromStation == null) MutedText else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.surfaceVariant))

                            // Destination Input
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.navigateTo(Screen.StationSearch(isSelectingFrom = false)) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = viewModel.getString("to").uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MutedText
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = toStation?.name(lang) ?: viewModel.getString("to"),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (toStation == null) MutedText else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Swap Button
                        IconButton(
                            onClick = { viewModel.swapStations() },
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colorScheme.background,
                                    CircleShape
                                )
                                .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                .size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Swap",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // PLAN ROUTE Button
                    Button(
                        onClick = {
                            if (fromStation != null && toStation != null) {
                                viewModel.navigateTo(Screen.JourneyResults)
                            }
                        },
                        enabled = fromStation != null && toStation != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("plan_route_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            disabledContainerColor = MutedText.copy(alpha = 0.3f),
                            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = viewModel.getString("plan_route").uppercase(),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- QUICK DESTINATIONS & FAVOURITES ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = viewModel.getString("quick_destinations").uppercase(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedText,
                        letterSpacing = 1.sp
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Home
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val s = TransitService.getStationById("BL12")
                                if (s != null) viewModel.setToStation(s)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.background, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🏠", fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = viewModel.getString("home_favorite"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Quick Work
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val s = TransitService.getStationById("BL18")
                                if (s != null) viewModel.setToStation(s)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.background, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🏢", fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = viewModel.getString("work_favorite"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Quick Station (Taipei Main Station)
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val s = TransitService.getStationById("BL12")
                                if (s != null) viewModel.setToStation(s)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.background, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🏛️", fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "台北車站",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // --- FAVOURITES SECTION ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = viewModel.getString("favourites").uppercase(),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText,
                    letterSpacing = 1.sp
                )

                // Quick Favourites Shortcuts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Favourite Home Shortcut
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val s = TransitService.getStationById("BL12") // Home Default to Taipei Main
                                if (s != null) viewModel.setFromStation(s)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Home, contentDescription = "Home", tint = TaiwanRed, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = viewModel.getString("home_favorite"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(text = "台北車站", fontSize = 11.sp, color = MutedText)
                            }
                        }
                    }

                    // Favourite Work Shortcut
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                val s = TransitService.getStationById("BL18") // Work Default to City Hall
                                if (s != null) viewModel.setToStation(s)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Work, contentDescription = "Work", tint = ColorBL, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = viewModel.getString("work_favorite"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(text = "市政府", fontSize = 11.sp, color = MutedText)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 4: STATION SEARCH SCREEN ---
@Composable
fun StationSearchScreen(viewModel: AppViewModel, isSelectingFrom: Boolean) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()

    val filteredStations = remember(query) {
        if (query.isBlank()) {
            TransitService.stations
        } else {
            TransitService.stations.filter {
                it.nameZh.contains(query, ignoreCase = true) ||
                it.nameEn.contains(query, ignoreCase = true) ||
                it.code.contains(query, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Search Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text(text = viewModel.getString("search_placeholder"), fontSize = 14.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("station_search_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TaiwanRed,
                    unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Recent Searches (if query is empty)
            if (query.isBlank() && recentSearches.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = viewModel.getString("recent_searches"),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MutedText
                        )
                        Text(
                            text = "Clear",
                            fontSize = 12.sp,
                            color = TaiwanRed,
                            modifier = Modifier.clickable { viewModel.clearRecentSearches() }
                        )
                    }
                }

                items(recentSearches) { id ->
                    val station = TransitService.getStationById(id) ?: return@items
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isSelectingFrom) {
                                    viewModel.setFromStation(station)
                                } else {
                                    viewModel.setToStation(station)
                                }
                                viewModel.addRecentSearch(station.id)
                                viewModel.navigateBack()
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = "Recent",
                                tint = MutedText,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = station.name(lang),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                station.lines.forEach { l -> MRTLineBadge(l) }
                            }
                        }
                    }
                }
            }

            // Filtered Stations
            item {
                Text(
                    text = if (query.isBlank()) "所有車站 All Stations" else "搜尋結果 Results",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            if (filteredStations.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = viewModel.getString("no_results"), color = MutedText)
                    }
                }
            } else {
                items(filteredStations) { station ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isSelectingFrom) {
                                    viewModel.setFromStation(station)
                                } else {
                                    viewModel.setToStation(station)
                                }
                                viewModel.addRecentSearch(station.id)
                                viewModel.navigateBack()
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = station.name(lang),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = station.code,
                                    fontSize = 11.sp,
                                    color = MutedText,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                station.lines.forEach { l -> MRTLineBadge(l) }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 5: JOURNEY RESULTS SCREEN ---
@Composable
fun JourneyResultsScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val fromStation by viewModel.fromStation.collectAsState()
    val toStation by viewModel.toStation.collectAsState()
    val results by viewModel.journeyResults.collectAsState()

    var selectedTab by remember { mutableStateOf(JourneyType.FASTEST) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Results Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "規劃路線 Route Plan",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Beautiful Origin-to-Destination banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = fromStation?.name(lang) ?: "",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "To",
                        tint = TaiwanRed,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Text(
                        text = toStation?.name(lang) ?: "",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Section 8: Journey Comparison Filter Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val tabs = listOf(
                        JourneyType.FASTEST to "最快 Fastest",
                        JourneyType.FEWEST_TRANSFERS to "少轉乘 Transfers",
                        JourneyType.ACCESSIBLE to "無障礙 Accessible"
                    )

                    tabs.forEach { (type, label) ->
                        val isSelected = selectedTab == type
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSelected) TaiwanRed else MaterialTheme.colorScheme.background,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedTab = type }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // List of Journey Cards matching filter
        val filteredResults = results.filter { it.type == selectedTab || selectedTab == JourneyType.FASTEST }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredResults) { journey ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectJourney(journey) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${journey.durationMinutes}",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TaiwanRed
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = viewModel.getString("minutes_unit"),
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Meta info badges
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (journey.transfersCount == 0) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                Color(0xFF4CD964).copy(alpha = 0.15f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "免轉乘 Direct", fontSize = 11.sp, color = Color(0xFF4CD964), fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                MutedText.copy(alpha = 0.15f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "轉乘 ${journey.transfersCount} 次", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Brief line trajectory visualization
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            journey.legs.forEachIndexed { idx, leg ->
                                if (leg.lineId != null) {
                                    MRTLineBadge(leg.lineId, modifier = Modifier.size(width = 44.dp, height = 24.dp))
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsWalk,
                                        contentDescription = "Transfer",
                                        tint = MutedText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                if (idx < journey.legs.size - 1) {
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = "next",
                                        tint = MutedText.copy(alpha = 0.5f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Walk info
                        Text(
                            text = "🚶 Walking: ${journey.walkDistanceMeters}m | Platform: ${journey.legs.firstOrNull { it.platformInfo != null }?.platformInfo ?: "月台 1"}",
                            fontSize = 12.sp,
                            color = MutedText
                        )
                    }
                }
            }
        }
    }
}

// --- SCREEN 6: JOURNEY DETAIL SCREEN (VERTICAL TIMELINE) ---
@Composable
fun JourneyDetailScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val journey by viewModel.selectedJourney.collectAsState()

    if (journey == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Detail Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "乘車詳情 Journey Detail",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${journey?.durationMinutes}",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = TaiwanRed
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = viewModel.getString("minutes_unit"),
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "🚶 Total Walking: ${journey?.walkDistanceMeters}m",
                            fontSize = 13.sp,
                            color = MutedText,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Section 9: Vertical Timeline
            items(journey!!.legs) { leg ->
                val line = TransitService.lines.find { it.id == leg.lineId }
                val lineCol = line?.color ?: MutedText

                Row(modifier = Modifier.fillMaxWidth()) {
                    // Vertical color tube drawing
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(32.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(lineCol, CircleShape)
                        )
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(96.dp)
                                .background(lineCol)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = TransitService.getStationById(leg.fromStationId)?.name(lang) ?: "",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            if (leg.lineId != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                                MRTLineBadge(leg.lineId)
                            }
                        }

                        Text(
                            text = leg.description(lang),
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.padding(top = 6.dp)
                        )

                        if (leg.platformInfo != null) {
                            Text(
                                text = leg.platformInfo,
                                fontSize = 12.sp,
                                color = lineCol,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Text(
                            text = "${leg.durationMinutes} ${viewModel.getString("minutes_unit")} | ${leg.stopCount} tsām",
                            fontSize = 12.sp,
                            color = MutedText,
                            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                        )
                    }
                }
            }

            // Destination Station Card
            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(32.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .border(4.dp, TaiwanRed, CircleShape)
                                .background(MaterialTheme.colorScheme.background)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = TransitService.getStationById(journey!!.toStationId)?.name(lang) ?: "",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}

// --- SCREEN 7: TAIPEI MRT INTERACTIVE SCHEMATIC MAP ---
@Composable
fun MRTMapScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val scope = rememberCoroutineScope()
    
    // Zoom and pan gestures
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3f)
        offset += offsetChange
    }

    var selectedStation by remember { mutableStateOf<Station?>(null) }
    var showBottomSheet by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Master Graphic Canvas of the MRT Network
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        // Reverse project tap offset based on scale/offset to find clicked station
                        val relativeX = (tapOffset.x - offset.x - size.width / 2) / (size.width * scale) + 0.5f
                        val relativeY = (tapOffset.y - offset.y - size.height / 2) / (size.height * scale) + 0.5f
                        
                        // Find closest station node in 0.05 tolerance range
                        val tapped = TransitService.stations.find { s ->
                            val dist = kotlin.math.sqrt((s.x - relativeX) * (s.x - relativeX) + (s.y - relativeY) * (s.y - relativeY))
                            dist < 0.08f
                        }
                        if (tapped != null) {
                            selectedStation = tapped
                            showBottomSheet = true
                        }
                    }
                }
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
                .transformable(state = state)
        ) {
            // Draw schematic route grid in Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // 1. Draw MRT route lines
                TransitService.lines.forEach { line ->
                    val pathPoints = line.stations.mapNotNull { sId ->
                        TransitService.getStationById(sId)
                    }
                    if (pathPoints.size > 1) {
                        for (i in 0 until pathPoints.size - 1) {
                            val p1 = pathPoints[i]
                            val p2 = pathPoints[i+1]
                            drawLine(
                                color = line.color,
                                start = Offset(p1.x * w, p1.y * h),
                                end = Offset(p2.x * w, p2.y * h),
                                strokeWidth = 8.dp.toPx()
                            )
                        }
                    }
                }

                // 2. Draw interchange background markers & stations
                TransitService.stations.forEach { station ->
                    val cx = station.x * w
                    val cy = station.y * h
                    
                    // Outer ring for transfers
                    if (station.lines.size > 1) {
                        drawCircle(
                            color = Color.White,
                            radius = 12.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = Charcoal,
                            radius = 10.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    }

                    // Inner station core
                    drawCircle(
                        color = Color.White,
                        radius = 6.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                    drawCircle(
                        color = TaiwanRed,
                        radius = 4.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                }
            }

            // 3. Station Text Labels Overlay
            TransitService.stations.forEach { station ->
                val labelAlign = if (station.y > 0.5f) Alignment.BottomCenter else Alignment.TopCenter
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    Text(
                        text = station.name(lang),
                        fontSize = (11 / scale).coerceIn(8f, 15f).sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier
                            .offset(
                                x = (station.x * 400).dp,
                                y = (station.y * 700 + (if (station.y > 0.5f) 10f else -18f)).dp
                            )
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.8f), RoundedCornerShape(2.dp))
                            .padding(2.dp)
                    )
                }
            }
        }

        // Overlay Map Controls
        Card(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
        ) {
            Column {
                IconButton(onClick = { scale = (scale + 0.2f).coerceAtMost(3f) }) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom In")
                }
                IconButton(onClick = { scale = (scale - 0.2f).coerceAtLeast(0.5f) }) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom Out")
                }
                IconButton(onClick = { scale = 1f; offset = Offset.Zero }) {
                    Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Recenter")
                }
            }
        }

        // Top Information Indicator
        Card(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
        ) {
            Text(
                text = "💡 Tap stations to view departures/exits",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(12.dp)
            )
        }

        // Bottom Sheet Station Interaction Overlay
        AnimatedVisibility(
            visible = showBottomSheet,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            if (selectedStation != null) {
                StationBottomSheetContent(
                    station = selectedStation!!,
                    viewModel = viewModel,
                    onDismiss = { showBottomSheet = false }
                )
            }
        }
    }
}

// --- SCREEN 8 & 11: STATION BOTTOM SHEET / INTERACTION DETAIL ---
@Composable
fun StationBottomSheetContent(
    station: Station,
    viewModel: AppViewModel,
    onDismiss: () -> Unit
) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val departures = remember(station) { TransitService.getLiveDepartures(station.id) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("station_bottom_sheet"),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name(lang),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Station ID: ${station.code}",
                        fontSize = 12.sp,
                        color = MutedText
                    )
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    station.lines.forEach { l -> MRTLineBadge(l) }
                }

                Spacer(modifier = Modifier.width(12.dp))

                IconButton(
                    onClick = { viewModel.toggleFavouriteStation(station.id) }
                ) {
                    val isFav = viewModel.favouriteStations.collectAsState().value.contains(station.id)
                    Icon(
                        imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Favourite",
                        tint = TaiwanRed
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            HorizontalDivider()

            // Departures Preview Header
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = viewModel.getString("next_train"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "🔴 DEMO DATA",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TaiwanRed
                )
            }

            // Departures rows
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                departures.take(2).forEach { dep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.background,
                                RoundedCornerShape(10.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MRTLineBadge(dep.lineId)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "往 ${dep.destination(lang)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${dep.minutesAway} min",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = TaiwanRed
                        )
                    }
                }
            }

            // Actions Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.setFromStation(station)
                        onDismiss()
                        viewModel.navigateToHome()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = TaiwanRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("從此出發 From Here", fontSize = 11.sp, color = Color.White, maxLines = 1)
                }

                Button(
                    onClick = {
                        viewModel.setToStation(station)
                        onDismiss()
                        viewModel.navigateToHome()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = ColorBL),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("前往此站 To Here", fontSize = 11.sp, color = Color.White, maxLines = 1)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(Screen.StationExits(station.id))
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(viewModel.getString("view_exits"), fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = {
                        onDismiss()
                        viewModel.navigateTo(Screen.LiveDepartures(station.id))
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(viewModel.getString("live_departures"), fontSize = 11.sp)
                }
            }
        }
    }
}

// --- SCREEN 9: STATION EXITS DETAIL ---
@Composable
fun StationExitsScreen(viewModel: AppViewModel, stationId: String) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val station = remember(stationId) { TransitService.getStationById(stationId) }

    if (station == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "${station.name(lang)} - ${viewModel.getString("view_exits")}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(station.exits) { exit ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .background(TaiwanRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = exit.name(lang),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (lang == "en") exit.directionsEn else exit.directionsZh,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Landmark chips
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val landmarks = if (lang == "en") exit.landmarksEn else exit.landmarksZh
                            landmarks.forEach { l ->
                                Box(
                                    modifier = Modifier
                                        .background(
                                            MaterialTheme.colorScheme.background,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(text = l, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Accessibility Features Indicators
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (exit.hasElevator) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Elevator, contentDescription = "Elevator", tint = ColorG, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = viewModel.getString("elevator"), fontSize = 11.sp, color = ColorG, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (exit.hasEscalator) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Accessibility, contentDescription = "Escalator", tint = ColorBL, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = viewModel.getString("escalator"), fontSize = 11.sp, color = ColorBL, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 10: LIVE DEPARTURES DEEP VIEW ---
@Composable
fun LiveDeparturesScreen(viewModel: AppViewModel, stationId: String) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val station = remember(stationId) { TransitService.getStationById(stationId) }

    var departureTimes by remember { mutableStateOf(emptyList<Departure>()) }

    // Dynamic timer to refresh every 5 seconds for interactive realistic simulation
    LaunchedEffect(key1 = stationId) {
        while (true) {
            departureTimes = TransitService.getLiveDepartures(stationId)
            delay(5000)
        }
    }

    if (station == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Departures Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "${station.name(lang)} - ${viewModel.getString("live_departures")}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Card(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = TaiwanRed.copy(alpha = 0.1f)),
            border = BorderStroke(1.dp, TaiwanRed.copy(alpha = 0.3f))
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Info, contentDescription = "Demo Indicator", tint = TaiwanRed)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "DEMO FARE / SIMULATED DEPARTURES ACTIVE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TaiwanRed
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(departureTimes) { dep ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MRTLineBadge(dep.lineId)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "往 ${dep.destination(lang)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Platform ${if (dep.id.contains("_1")) "1" else "2"}",
                                fontSize = 11.sp,
                                color = MutedText
                            )
                        }

                        // Large Dynamic Countdown Indicator
                        Box(
                            modifier = Modifier
                                .background(
                                    TaiwanRed.copy(alpha = 0.15f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${dep.minutesAway} min",
                                color = TaiwanRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 12: LINE EXPLORER (MRT LINE EXPLORER) ---
@Composable
fun LineExplorerScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val selectedLineId by viewModel.selectedLineId.collectAsState()

    val currentLine = remember(selectedLineId) { TransitService.lines.find { it.id == selectedLineId }!! }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Line Select Header Panel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransitService.lines.forEach { line ->
                val isSelected = line.id == selectedLineId
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSelected) line.color else MaterialTheme.colorScheme.surface,
                            RoundedCornerShape(8.dp)
                        )
                        .border(1.dp, if (isSelected) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        .clickable { viewModel.selectLine(line.id) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = line.code,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Sequential List of Stations on Line
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            items(currentLine.stations) { sId ->
                val station = TransitService.getStationById(sId) ?: return@items
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            // Selecting station brings up interaction details
                            viewModel.navigateTo(Screen.StationDetail(station.id))
                        }
                ) {
                    // Line schematic tube drawings
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(32.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .border(2.dp, currentLine.color, CircleShape)
                                .background(MaterialTheme.colorScheme.background)
                        )
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(56.dp)
                                .background(currentLine.color)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(bottom = 16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = station.name(lang),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = station.code,
                                fontSize = 11.sp,
                                color = MutedText,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            station.lines.forEach { l -> MRTLineBadge(l) }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 13: DISRUPTION DETAIL VIEW ---
@Composable
fun DisruptionDetailScreen(viewModel: AppViewModel, disruptionId: String) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val disruption = remember(disruptionId) { TransitService.disruptions.find { it.id == disruptionId }!! }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = viewModel.getString("disruption_status"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TaiwanRed.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, TaiwanRed)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = "Alert", tint = TaiwanRed, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = disruption.title(lang),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = disruption.estRecovery(lang),
                            fontSize = 12.sp,
                            color = TaiwanRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Description
            Column {
                Text(
                    text = viewModel.getString("description"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText
                )
                Text(
                    text = disruption.desc(lang),
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Affected stations
            Column {
                Text(
                    text = viewModel.getString("affected_stations"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText
                )
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    disruption.affectedStations.forEach { sId ->
                        val station = TransitService.getStationById(sId) ?: return@forEach
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(text = station.name(lang), fontSize = 12.sp)
                        }
                    }
                }
            }

            // Alternative Route recommendation
            Column {
                Text(
                    text = viewModel.getString("alternative_route"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText
                )
                Text(
                    text = disruption.alternativeRoute(lang),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

// --- SCREEN 14: BUY TICKET SECTION (WALLETS AND PURCHASE) ---
@Composable
fun BuyTicketScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()

    val ticketsList = listOf(
        Ticket(
            id = "t_single",
            type = TicketType.SINGLE,
            nameZh = "單程票",
            nameEn = "Single Journey",
            nameNan = "單程票",
            priceTwd = 20.0,
            validityDescZh = "限當日有效 (測試)",
            validityDescEn = "Valid today only (DEMO)",
            validityDescNan = "當日有效 (測試)"
        ),
        Ticket(
            id = "t_day",
            type = TicketType.DAY_PASS,
            nameZh = "一日票",
            nameEn = "Day Pass",
            nameNan = "一日票",
            priceTwd = 150.0,
            validityDescZh = "啟用起 24 小時內無限搭乘 (測試)",
            validityDescEn = "Unlimited rides for 24h (DEMO)",
            validityDescNan = "24小時無限坐 (測試)"
        ),
        Ticket(
            id = "t_multi",
            type = TicketType.MULTI_DAY,
            nameZh = "48小時 / 72小時 多日票",
            nameEn = "48h / 72h Multi-Day Pass",
            nameNan = "多日票",
            priceTwd = 280.0,
            validityDescZh = "啟用起 48~72 小時無限搭乘 (測試)",
            validityDescEn = "Unlimited rides for 48h/72h (DEMO)",
            validityDescNan = "多日無限坐 (測試)"
        ),
        Ticket(
            id = "t_other",
            type = TicketType.OTHER,
            nameZh = "其他紀念票卡",
            nameEn = "Tourist Passes / Other Passes",
            nameNan = "其他紀念票",
            priceTwd = 500.0,
            validityDescZh = "特色聯名卡與特製紀念票券 (測試)",
            validityDescEn = "Special theme cards (DEMO)",
            validityDescNan = "聯名紀念票 (測試)"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "台北快捷購票 Ticket Hub",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Select a ticket category to proceed",
            fontSize = 12.sp,
            color = MutedText,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(ticketsList) { ticket ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.navigateTo(Screen.TicketSelection(ticket.type))
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = ticket.name(lang),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "NT$ ${ticket.priceTwd.toInt()}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = TaiwanRed
                            )
                        }

                        Text(
                            text = ticket.validity(lang),
                            fontSize = 12.sp,
                            color = MutedText,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(TaiwanRed.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "DEMO FARE",
                                    color = TaiwanRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Buy",
                                tint = TaiwanRed
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 15 & 16: TICKET CONFIGURATION & PAYMENT PROTEST ---
@Composable
fun TicketSelectionScreen(viewModel: AppViewModel, ticketType: TicketType) {
    val lang by viewModel.selectedLanguage.collectAsState()
    var passengerCount by remember { mutableStateOf(1) }

    // Configure configured price details
    val (baseNameZh, baseNameEn, baseNameNan, pricePerTicket) = when (ticketType) {
        TicketType.SINGLE -> Quadruple("單程票", "Single Journey", "單程票", 20.0)
        TicketType.DAY_PASS -> Quadruple("一日票", "Day Pass", "一日票", 150.0)
        TicketType.MULTI_DAY -> Quadruple("多日票 (48H)", "Multi-Day Pass (48H)", "多日票 (48H)", 280.0)
        TicketType.OTHER -> Quadruple("特製紀念票", "Special Memorial Card", "特製紀念票", 500.0)
    }

    val totalPrice = pricePerTicket * passengerCount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "購票設定 Configuration",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (lang == "en") baseNameEn else baseNameZh,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Price per ticket: NT$ ${pricePerTicket.toInt()}",
                        fontSize = 14.sp,
                        color = MutedText
                    )
                }
            }

            // Passenger count adjustment
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "乘客人數 Passengers",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (passengerCount > 1) passengerCount-- },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease")
                    }
                    Text(
                        text = "$passengerCount",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    IconButton(
                        onClick = { passengerCount++ },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increase")
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Confirm & Go to Payment
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "總金額 Total", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(text = "NT$ ${totalPrice.toInt()}", fontSize = 24.sp, fontWeight = FontWeight.Black, color = TaiwanRed)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.navigateTo(
                                Screen.PaymentDemo(
                                    ticketType,
                                    totalPrice,
                                    baseNameZh,
                                    baseNameEn,
                                    baseNameNan
                                )
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TaiwanRed),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "立即付款 Pay Now", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

// --- SCREEN 17: PAYMENT PROTEST / UNDER 1 SECOND ANIMATION ---
@Composable
fun PaymentDemoScreen(
    viewModel: AppViewModel,
    ticketType: TicketType,
    price: Double,
    nameZh: String,
    nameEn: String,
    nameNan: String
) {
    var progress by remember { mutableStateOf(0f) }

    // Instant payment processing simulator under 1 second
    LaunchedEffect(key1 = true) {
        animate(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = tween(durationMillis = 800)
        ) { value, _ ->
            progress = value
        }
        viewModel.purchaseTicket(ticketType, price, nameZh, nameEn, nameNan)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                progress = { progress },
                color = TaiwanRed,
                strokeWidth = 6.dp,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "付款處理中...",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                text = "Processing secure transaction",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// --- SCREEN 18: TICKET CONFIRMATION SLIDE ANIMATION ---
@Composable
fun TicketConfirmationScreen(viewModel: AppViewModel, ticketId: String) {
    var animationTriggered by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        delay(300)
        animationTriggered = true
        delay(1200)
        // Transition straight into the My Tickets Wallet screen!
        viewModel.navigateTo(Screen.MyTickets)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            AnimatedVisibility(
                visible = animationTriggered,
                enter = scaleIn(initialScale = 0.5f) + fadeIn()
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Success",
                    tint = ColorG,
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = viewModel.getString("payment_success"),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = viewModel.getString("ticket_generating"),
                fontSize = 14.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Dynamic sliding animation representations
            Spacer(modifier = Modifier.height(48.dp))
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(160.dp)
                    .graphicsLayer {
                        translationY = if (animationTriggered) -100f else 200f
                        alpha = if (animationTriggered) 0f else 1f
                    }
                    .background(TaiwanRed, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "TAIPEI METRO PASS", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- SCREEN 19: MY TICKETS WALLET ---
@Composable
fun MyTicketsScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val tickets by viewModel.myTickets.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "我的票卡 Wallet",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "View and select your digital passes below",
            fontSize = 12.sp,
            color = MutedText,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        if (tickets.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "尚無車票 No Tickets Purchased", color = MutedText)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(tickets) { ticket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.navigateTo(Screen.DigitalTicket(ticket.id))
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(TaiwanRed.copy(alpha = 0.1f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = "QR Code",
                                    tint = TaiwanRed
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ticket.name(lang),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "ID: ${ticket.ticketId}",
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                            
                            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Open", tint = TaiwanRed)
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 20: DIGITAL TICKET & QR DISPLAY ---
@Composable
fun DigitalTicketScreen(viewModel: AppViewModel, ticketId: String) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val tickets by viewModel.myTickets.collectAsState()
    val ticket = remember(ticketId) { tickets.find { it.id == ticketId } }

    if (ticket == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Ticket Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = viewModel.getString("digital_ticket"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        // Section 17 & 18: Premium Visual Ticket Representation
        Card(
            modifier = Modifier
                .width(320.dp)
                .padding(vertical = 24.dp)
                .testTag("digital_qr_ticket"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Branding Header
                Text(
                    text = "TAIPEI METRO",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    letterSpacing = 2.sp,
                    color = TaiwanRed
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // High fidelity QR Code representation via Vector Shapes
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Custom drawing of high-fidelity schematic barcode vectors
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 6f
                        // Corner borders
                        drawRect(Color.Black, style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
                        drawRect(Color.Black, topLeft = Offset(40f, 40f), size = size / 2f, style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
                        drawRect(Color.Black, topLeft = Offset(80f, 80f), size = size / 4f)
                    }
                }

                Text(
                    text = "PROTOTYPE ONLY - DEMO TICKET",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TaiwanRed,
                    modifier = Modifier.padding(top = 12.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Information details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "Passenger", fontSize = 11.sp, color = MutedText)
                        Text(text = "1 (Adult)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "Valid", fontSize = 11.sp, color = MutedText)
                        Text(text = "Today", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ColorG)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "Ticket ID", fontSize = 11.sp, color = MutedText)
                        Text(text = ticket.ticketId, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "Type", fontSize = 11.sp, color = MutedText)
                        Text(text = ticket.name(lang), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

// --- SCREEN 21: MORE / SETTINGS / ABOUT ---
@Composable
fun SettingsScreen(viewModel: AppViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = viewModel.getString("settings"),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Preferences Group
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column {
                // Language Selection Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.LanguageSelection) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Translate, contentDescription = "Language", tint = TaiwanRed)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = viewModel.getString("language"),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = when (lang) {
                            "en" -> "English"
                            "nan-TW" -> "台語"
                            else -> "繁體中文"
                        },
                        color = MutedText
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))

                // Dark mode switcher Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Outlined.DarkMode, contentDescription = "Dark Theme", tint = TaiwanRed)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = viewModel.getString("dark_mode"),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = { viewModel.toggleDarkMode() },
                        colors = SwitchDefaults.colors(checkedThumbColor = TaiwanRed, checkedTrackColor = TaiwanRed.copy(alpha = 0.4f))
                    )
                }
            }
        }

        // About specifications info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Taipei Metro Architecture Prototype",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "A sophisticated digital model leveraging advanced local shortest-path engines, bilingual Hokkien localization framework, dynamic countdown telemetry, and ticket purchase simulators.",
                    fontSize = 12.sp,
                    color = MutedText
                )
                Text(
                    text = "Version: 1.0.0 (Gemini 3.7 Release Build)",
                    fontSize = 11.sp,
                    color = MutedText
                )
            }
        }
    }
}
