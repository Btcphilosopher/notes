package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Taiwanese Red Accent (Traditional Camellia / MRT Red)
val TaiwanRed = Color(0xFFD0104C)
val Charcoal = Color(0xFF1E1E1E)
val NearBlack = Color(0xFF1C1C1E)
val CoolGrey = Color(0xFFF2F2F7)
val SoftGrey = Color(0xFFE5E5EA)
val MutedText = Color(0xFF8E8E93)

// MRT Line Hex Colors
val ColorBL = Color(0xFF0070BC) // Blue - Bannan
val ColorR = Color(0xFFE30022)  // Red - Tamsui-Xinyi
val ColorG = Color(0xFF008559)  // Green - Songshan-Xindian
val ColorO = Color(0xFFFFA300)  // Orange - Zhonghe-Xinlu
val ColorBR = Color(0xFFC48C31) // Brown - Wenhu

// Theme Specific Colors
val DarkPrimary = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1C1C1E)
val DarkSurfaceVariant = Color(0xFF2C2C2E)

val LightPrimary = Color(0xFF1C1C1E)
val LightBackground = Color(0xFFF2F2F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE5E5EA)
