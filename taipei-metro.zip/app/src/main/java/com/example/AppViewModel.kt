package com.example

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.random.Random

sealed class Screen {
    object Splash : Screen()
    object LanguageSelection : Screen()
    object Home : Screen()
    data class StationSearch(val isSelectingFrom: Boolean) : Screen()
    object JourneyResults : Screen()
    object JourneyDetail : Screen()
    object Map : Screen()
    data class StationDetail(val stationId: String) : Screen()
    data class StationExits(val stationId: String) : Screen()
    data class LiveDepartures(val stationId: String) : Screen()
    object LineExplorer : Screen()
    data class DisruptionDetail(val disruptionId: String) : Screen()
    object BuyTicket : Screen()
    data class TicketSelection(val ticketType: TicketType) : Screen()
    data class PaymentDemo(
        val ticketType: TicketType, 
        val price: Double, 
        val nameZh: String, 
        val nameEn: String, 
        val nameNan: String
    ) : Screen()
    data class TicketConfirmation(val ticketId: String) : Screen()
    object MyTickets : Screen()
    data class DigitalTicket(val ticketId: String) : Screen()
    object FavouriteJourneys : Screen()
    object Settings : Screen()
}

class AppViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sharedPrefs = application.getSharedPreferences("taipei_metro_prefs", Context.MODE_PRIVATE)

    // --- Core States ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(sharedPrefs.getString("lang", "zh-TW") ?: "zh-TW")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _isDarkMode = MutableStateFlow(sharedPrefs.getBoolean("dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // --- Navigation Stack ---
    private val screenStack = mutableListOf<Screen>()

    // --- Journey Planner States ---
    private val _fromStation = MutableStateFlow<Station?>(null)
    val fromStation: StateFlow<Station?> = _fromStation.asStateFlow()

    private val _toStation = MutableStateFlow<Station?>(null)
    val toStation: StateFlow<Station?> = _toStation.asStateFlow()

    private val _journeyResults = MutableStateFlow<List<Journey>>(emptyList())
    val journeyResults: StateFlow<List<Journey>> = _journeyResults.asStateFlow()

    private val _selectedJourney = MutableStateFlow<Journey?>(null)
    val selectedJourney: StateFlow<Journey?> = _selectedJourney.asStateFlow()

    // --- Search State ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _recentSearches = MutableStateFlow<List<String>>(
        sharedPrefs.getStringSet("recent_searches", emptySet())?.toList() ?: emptyList()
    )
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    // --- Line Explorer State ---
    private val _selectedLineId = MutableStateFlow("BL")
    val selectedLineId: StateFlow<String> = _selectedLineId.asStateFlow()

    // --- Disruptions ---
    private val _activeDisruptions = MutableStateFlow<List<Disruption>>(TransitService.disruptions)
    val activeDisruptions: StateFlow<List<Disruption>> = _activeDisruptions.asStateFlow()

    // --- Favourites ---
    private val _favouriteStations = MutableStateFlow<Set<String>>(
        sharedPrefs.getStringSet("fav_stations", setOf("BL12", "BL11")) ?: setOf("BL12", "BL11")
    )
    val favouriteStations: StateFlow<Set<String>> = _favouriteStations.asStateFlow()

    private val _favouriteJourneys = MutableStateFlow<List<Pair<String, String>>>(
        listOf("BL12" to "R03") // Default favourite: Taipei Main to Taipei 101
    )
    val favouriteJourneys: StateFlow<List<Pair<String, String>>> = _favouriteJourneys.asStateFlow()

    // --- Tickets State ---
    private val _myTickets = MutableStateFlow<List<Ticket>>(
        listOf(
            Ticket(
                id = "demo_t1",
                type = TicketType.SINGLE,
                nameZh = "單程票",
                nameEn = "Single Journey",
                nameNan = "單程票",
                priceTwd = 30.0,
                validityDescZh = "限當日有效 (已使用)",
                validityDescEn = "Used today",
                validityDescNan = "已使用",
                ticketId = "TPM-8291-0391"
            )
        )
    )
    val myTickets: StateFlow<List<Ticket>> = _myTickets.asStateFlow()

    // --- Ticket Animation State ---
    private val _ticketAnimationStep = MutableStateFlow(0) // 0: None, 1: Processing, 2: Completed, 3: Slide Into My Tickets
    val ticketAnimationStep: StateFlow<Int> = _ticketAnimationStep.asStateFlow()

    // --- Navigation Functions ---
    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack() {
        if (screenStack.isNotEmpty()) {
            val prev = screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = prev
        } else {
            // Default back behavior
            _currentScreen.value = Screen.Home
        }
    }

    fun navigateToHome() {
        screenStack.clear()
        _currentScreen.value = Screen.Home
    }

    // --- Language / Dark Mode Functions ---
    fun changeLanguage(lang: String) {
        _selectedLanguage.value = lang
        sharedPrefs.edit().putString("lang", lang).apply()
    }

    fun toggleDarkMode() {
        val newVal = !_isDarkMode.value
        _isDarkMode.value = newVal
        sharedPrefs.edit().putBoolean("dark_mode", newVal).apply()
    }

    // --- Station Selector & Routing ---
    fun setFromStation(station: Station?) {
        _fromStation.value = station
        triggerRoutePlanning()
    }

    fun setToStation(station: Station?) {
        _toStation.value = station
        triggerRoutePlanning()
    }

    fun swapStations() {
        val temp = _fromStation.value
        _fromStation.value = _toStation.value
        _toStation.value = temp
        triggerRoutePlanning()
    }

    private fun triggerRoutePlanning() {
        val from = _fromStation.value
        val to = _toStation.value
        if (from != null && to != null) {
            _journeyResults.value = TransitService.planJourney(from.id, to.id)
        } else {
            _journeyResults.value = emptyList()
        }
    }

    fun selectJourney(journey: Journey) {
        _selectedJourney.value = journey
        navigateTo(Screen.JourneyDetail)
    }

    // --- Search ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addRecentSearch(stationId: String) {
        val current = _recentSearches.value.toMutableList()
        current.remove(stationId)
        current.add(0, stationId)
        val trimmed = current.take(5)
        _recentSearches.value = trimmed
        sharedPrefs.edit().putStringSet("recent_searches", trimmed.toSet()).apply()
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        sharedPrefs.edit().remove("recent_searches").apply()
    }

    // --- Favourites ---
    fun toggleFavouriteStation(stationId: String) {
        val current = _favouriteStations.value.toMutableSet()
        if (current.contains(stationId)) {
            current.remove(stationId)
        } else {
            current.add(stationId)
        }
        _favouriteStations.value = current
        sharedPrefs.edit().putStringSet("fav_stations", current).apply()
    }

    fun toggleFavouriteJourney(fromId: String, toId: String) {
        val current = _favouriteJourneys.value.toMutableList()
        val pair = fromId to toId
        if (current.contains(pair)) {
            current.remove(pair)
        } else {
            current.add(pair)
        }
        _favouriteJourneys.value = current
    }

    // --- Line Explorer ---
    fun selectLine(lineId: String) {
        _selectedLineId.value = lineId
    }

    // --- Ticket Booking Simulation ---
    fun purchaseTicket(type: TicketType, price: Double, nameZh: String, nameEn: String, nameNan: String) {
        val randomId = "TPM-${Random.nextInt(1000, 9999)}-${Random.nextInt(1000, 9999)}"
        val newTicket = Ticket(
            id = UUID.randomUUID().toString(),
            type = type,
            nameZh = nameZh,
            nameEn = nameEn,
            nameNan = nameNan,
            priceTwd = price,
            passengerCount = 1,
            validityDescZh = "限當日有效 (測試車票)",
            validityDescEn = "Valid today (DEMO)",
            validityDescNan = "今仔日有效 (測試)",
            ticketId = randomId,
            isDemo = true
        )
        
        // Add to purchase history list
        val currentList = _myTickets.value.toMutableList()
        currentList.add(0, newTicket)
        _myTickets.value = currentList

        // Navigate to confirmation screen
        navigateTo(Screen.TicketConfirmation(newTicket.id))
    }

    // String Helper matching selectedLanguage
    fun getString(key: String): String {
        return LocalizationManager.getString(key, _selectedLanguage.value, getApplication())
    }
}
