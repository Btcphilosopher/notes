# LogisticsStrike

A production-grade Python platform for modelling, forecasting, pricing and
optimising global freight markets. LogisticsStrike treats logistics
simultaneously as:

1. **A physical transportation network** — ports, airports, rail terminals,
   truck depots, warehouses, and the sea/air/rail/road legs connecting them.
2. **A dynamic market for freight capacity** — finite, scarce, and priced.

Its central objective is computing two numbers for any shipment or corridor:

- **SPOT PRICE** — what freight capacity costs *today*, as an emergent sum
  of priced components (base transport, capacity scarcity, fuel,
  congestion, handling, risk, urgency, route conditions), never a lookup
  table.
- **STRIKE PRICE** — the economically defensible price for securing
  *future* freight capacity subject to delivery, cost and reliability
  requirements, built from the expected future spot plus the risk premia a
  rational counterparty requires to commit early (capacity risk, congestion
  risk, fuel uncertainty, delay/reliability risk, liquidity premium,
  optionality).

## The fundamental loop

```
GLOBAL LOGISTICS STATE
        |
        v
     CAPACITY -> DEMAND -> ROUTING -> SPOT PRICE
        |
        v
FORWARD EXPECTATIONS -> STRIKE PRICE -> CONTRACT / ALLOCATION
        |
        v
  ACTUAL EXECUTION -> MARKET FEEDBACK  (loops back to the top)
```

realised concretely, once per simulated timestep, in
[`core/engine.py`](logistics_strike/core/engine.py):

```python
generate_freight_demand()
update_global_capacity()
update_weather()
update_fuel_prices()
update_port_and_network_congestion()
calculate_spot_prices()
update_forward_expectations()
calculate_strike_prices()
update_order_books()
match_capacity()
optimise_routes()
simulate_transit()
apply_disruptions()
settle_contracts()
update_market_state()
record_metrics()
```

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# run the end-to-end demo (builds a starter world, runs 30 simulated days,
# prints an inspectable spot/strike breakdown, a forward curve, a Monte
# Carlo risk fan, and a PORT_CLOSURE scenario comparison)
python demo.py

# run the test suite
pytest

# serve the API
uvicorn logistics_strike.api.main:app --reload
# then, e.g.:
curl -X POST localhost:8000/simulation -d '{"n_steps": 10}' -H 'content-type: application/json'
curl localhost:8000/spot/CNSHA-NLRTM-SEA
curl localhost:8000/strike/CNSHA-NLRTM-SEA
```

### Postgres

The platform targets PostgreSQL for persistent state (`logistics_strike/db`).
`DATABASE_URL` defaults to a local SQLite file so the demo, API and test
suite run with zero external setup; point it at Postgres for production:

```bash
docker compose up -d postgres
export DATABASE_URL=postgresql+psycopg2://logistics:logistics@localhost:5432/logisticsstrike
python -c "from logistics_strike.db.session import init_db; init_db()"
```

## Architecture

```
logistics_strike/
  core/          simulation engine, clock, event bus, global state registry
  network/       multimodal directed graph: ports, airports, rail, roads, warehouses, corridors
  cargo/         cargo types, containers, shipments, handling constraints
  carriers/      finite capacity pools; shipping/air/rail/trucking carriers
  pricing/       spot, forward, strike, congestion, fuel, volatility engines
  contracts/     spot/forward/strike/fixed/index-linked/reservation contracts, options, settlement
  markets/       order book, price/time-priority matching, uniform-price auctions, liquidity
  routing/       multi-criteria route search, multimodal enumeration, capacity checks, optimisation
  risk/          delay, disruption, weather, geopolitical, reliability, VaR/CVaR
  agents/        shippers, carriers, brokers, traders, demand generation (imperfect information)
  simulation/    world builder, scenario engine, Monte Carlo, recording/replay
  analytics/     freight indices, margins, utilisation, reliability, P&L, inventory economics
  visualisation/ dependency-free terminal tables/sparklines for curves and dashboards
  api/           FastAPI service (GET/POST spot, strike, forward, route, scenario, simulation, ...)
  db/            SQLAlchemy models + repository (Postgres-first, SQLite for tests)
  tests/         pytest suite covering pricing, risk, markets, contracts, routing, engine, analytics
```

Every pricing result is inspectable: `SpotPriceResult`, `StrikeResult` and
`ForwardCurve` all expose their component breakdown (`.components.as_dict()`
or `.explain()`), and every persisted pricing row records
`model_version`, `inputs`, `parameters`, `timestamp` and `scenario`.

## What's intentionally out of scope

This ships a complete, working *platform architecture* with real pricing,
routing, risk and market logic — not a calibrated real-world freight
forecast. The starter network in `simulation/world.py` covers a handful of
major ports/airports/rail hubs/corridors as a working demonstration; extend
`network/*` and `simulation/world.py`'s lane tables to grow it. Cost/vol/
risk parameters throughout are documented, defensible starting points, not
fitted market data.
