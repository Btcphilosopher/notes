#!/usr/bin/env python3
"""End-to-end demo of the LogisticsStrike platform.

Runs the default world for a month of simulated days, then prints:
  * the live metrics dashboard
  * a fully inspectable spot price breakdown
  * a fully inspectable strike price breakdown, with the spot-vs-strike
    reconciliation
  * a forward curve
  * a Monte Carlo risk fan
  * the outcome of the PORT_CLOSURE scenario vs. baseline

Run with:  python demo.py
"""

from __future__ import annotations

from logistics_strike.pricing.forward import Tenor
from logistics_strike.pricing.strike import explain_spot_vs_strike
from logistics_strike.simulation.monte_carlo import MonteCarloEngine
from logistics_strike.simulation.scenarios import ScenarioEngine
from logistics_strike.simulation.world import build_default_world
from logistics_strike.visualisation import render_forward_curve_table, render_metrics_dashboard, render_monte_carlo_fan

HEADLINE_CORRIDOR = "CNSHA->NLRTM:SEA"


def main() -> None:
    print("Building the default LogisticsStrike world (major Asia-Europe/Transpacific/air lanes)...")
    engine = build_default_world()

    print("\nRunning 30 simulated days...")
    snapshot = None
    for _ in range(30):
        snapshot = engine.step()

    print("\n" + render_metrics_dashboard(snapshot))

    print("\n--- SPOT PRICE (fully inspectable) ---")
    print(engine.state.spot_prices[HEADLINE_CORRIDOR].explain())

    print("\n--- STRIKE PRICE (fully inspectable) ---")
    strike_result = engine.state.strike_prices[HEADLINE_CORRIDOR]
    print(strike_result.explain())
    print()
    print(explain_spot_vs_strike(
        current_spot=engine.state.spot_prices[HEADLINE_CORRIDOR].price,
        expected_future_spot=engine.state.forward_curves[HEADLINE_CORRIDOR].point(Tenor.MONTHLY).expected_spot,
        strike_price=strike_result.strike_price,
    ))

    print("\n--- STRIKE BOUNDS ---")
    for k, v in engine.strike_engine.strike_bounds(strike_result).items():
        print(f"  {k:<28} {v:>10,.2f}")

    print("\n--- FORWARD CURVE ---")
    print(render_forward_curve_table(engine.state.forward_curves[HEADLINE_CORRIDOR]))

    print("\n--- MONTE CARLO (5,000 simulations) ---")
    spot_result = engine.state.spot_prices[HEADLINE_CORRIDOR]
    curve = engine.state.forward_curves[HEADLINE_CORRIDOR]
    mc = MonteCarloEngine().simulate(
        corridor_id=HEADLINE_CORRIDOR,
        forward_point=curve.point(Tenor.MONTHLY),
        strike_price=strike_result.strike_price,
        expected_transit_days=spot_result.expected_transit_days,
        transit_std_days=spot_result.transit_std_days,
        deadline_days=spot_result.expected_transit_days * 1.15,
        volume_units=2.0,
        capacity_scarcity_forecast=0.4,
    )
    print(render_monte_carlo_fan(mc, "future_spot"))
    print(render_monte_carlo_fan(mc, "buyer_pnl"))
    print(f"P(on time): {mc.reliability * 100:.1f}%")

    print("\n--- SCENARIO: PORT_CLOSURE vs baseline (15 days) ---")
    comparison = ScenarioEngine().run_comparison("PORT_CLOSURE", n_steps=15, start=engine.clock.start)
    for corridor, deltas in comparison.summary().items():
        spot_d = deltas["spot_delta"]
        strike_d = deltas["strike_delta"]
        if spot_d is None:
            continue
        print(f"  {corridor:<28} spot {spot_d:+9,.2f}   strike {strike_d:+9,.2f}")


if __name__ == "__main__":
    main()
