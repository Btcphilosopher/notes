"""LogisticsStrike REST API (FastAPI).

Wraps a single in-process simulation :class:`~logistics_strike.core.engine.Engine`
(built via :func:`~logistics_strike.simulation.world.build_default_world`)
as the platform's live world state. ``POST /simulation`` advances it;
every other endpoint reads from -- or prices on demand against -- its
current state, per requirement #34's endpoint list.

Run with:  ``uvicorn logistics_strike.api.main:app --reload``
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.cargo.shipments import Shipment
from logistics_strike.core.state import TransportMode
from logistics_strike.markets.liquidity import LiquidityEngine
from logistics_strike.pricing.forward import Tenor
from logistics_strike.pricing.spot import MODE_FUEL_TYPE
from logistics_strike.risk.delay import DelayModel
from logistics_strike.risk.var import RiskFactorExposure, build_risk_report
from logistics_strike.routing.optimisation import Objective, RouteObjectiveWeights, score_routes
from logistics_strike.simulation.monte_carlo import MonteCarloEngine
from logistics_strike.simulation.scenarios import STANDARD_SCENARIOS, ScenarioEngine
from logistics_strike.simulation.world import build_default_world

app = FastAPI(
    title="LogisticsStrike",
    description="Spot and strike pricing for global freight capacity.",
    version="0.1.0",
)

engine = build_default_world()
liquidity_engine = LiquidityEngine()
monte_carlo_engine = MonteCarloEngine()


# ---------------------------------------------------------------------------
# schemas
# ---------------------------------------------------------------------------

class CargoRequest(BaseModel):
    cargo_type: CargoType = CargoType.CONTAINER_40FT
    weight_kg: float = 22_000
    volume_m3: float = 67.0
    declared_value_usd: float = 60_000
    requires_temperature_control: bool = False


class SpotPriceRequest(BaseModel):
    origin_id: str
    destination_id: str
    mode: TransportMode = TransportMode.SEA
    cargo: CargoRequest = Field(default_factory=CargoRequest)
    deadline_days: float = 45.0
    required_reliability: float = 0.90


class StrikePriceRequest(BaseModel):
    origin_id: str
    destination_id: str
    mode: TransportMode = TransportMode.SEA
    tenor: Tenor = Tenor.MONTHLY
    required_reliability: float = 0.95
    max_transit_days: Optional[float] = None


class RouteOptimiseRequest(BaseModel):
    origin_id: str
    destination_id: str
    cargo: CargoRequest = Field(default_factory=CargoRequest)
    deadline_days: float = 45.0
    weights: Optional[Dict[str, float]] = None
    objective: Optional[Objective] = None


class ScenarioRequest(BaseModel):
    scenario_id: str
    n_steps: int = 30


class SimulationRequest(BaseModel):
    n_steps: int = 1


def _parse_route(route: str):
    parts = route.split("-")
    if len(parts) != 3:
        raise HTTPException(400, "route must be formatted ORIGIN-DESTINATION-MODE, e.g. CNSHA-NLRTM-SEA")
    origin, destination, mode_str = parts
    try:
        mode = TransportMode(mode_str.upper())
    except ValueError:
        raise HTTPException(400, f"unknown mode '{mode_str}'")
    return origin, destination, mode


def _to_cargo_spec(req: CargoRequest) -> CargoSpec:
    return CargoSpec(
        cargo_type=req.cargo_type,
        weight_kg=req.weight_kg,
        volume_m3=req.volume_m3,
        declared_value_usd=req.declared_value_usd,
        requires_temperature_control=req.requires_temperature_control,
    )


def _price_spot(origin: str, destination: str, mode: TransportMode, cargo: CargoSpec, deadline_days: float, required_reliability: float):
    route = engine.lane_route(origin, destination, mode)
    if not route:
        raise HTTPException(404, f"no route found for {origin}->{destination} ({mode.value})")
    shipment = Shipment(
        origin_id=origin,
        destination_id=destination,
        cargo=cargo,
        deadline=engine.clock.now + timedelta(days=deadline_days),
        required_reliability=required_reliability,
    )
    return engine.spot_engine.compute_spot(shipment, route, engine.capacity_pools), route


# ---------------------------------------------------------------------------
# GET endpoints
# ---------------------------------------------------------------------------

@app.get("/spot/{route}")
def get_spot(route: str):
    origin, destination, mode = _parse_route(route)
    result, _ = _price_spot(origin, destination, mode, _to_cargo_spec(CargoRequest()), 45.0, 0.90)
    return {"price": result.price, "currency": result.currency, "components": result.components.as_dict(),
            "expected_transit_days": result.expected_transit_days, "reliability": result.reliability,
            "explain": result.explain()}


@app.get("/strike/{route}")
def get_strike(route: str, tenor: Tenor = Tenor.MONTHLY, required_reliability: float = 0.95):
    origin, destination, mode = _parse_route(route)
    key = engine.state.corridor_key(origin, destination, mode)
    curve = engine.state.forward_curves.get(key)
    spot_result = engine.state.spot_prices.get(key)
    if curve is None or spot_result is None:
        raise HTTPException(404, f"no priced forward curve for {route} yet -- POST /simulation first")
    point = curve.point(tenor)
    route_edges = engine.lane_route(origin, destination, mode)
    fuel_type = MODE_FUEL_TYPE[mode]
    fuel_share = route_edges[0].fuel_share if route_edges else 0.3
    fuel_vol = engine.fuel_engine.params[fuel_type].volatility / engine.fuel_engine.params[fuel_type].long_run_mean
    result = engine.strike_engine.compute_strike(
        corridor_id=key, mode=mode.value, forward_point=point, current_spot=spot_result.price,
        capacity_scarcity_forecast=engine.capacity_scarcity_forecast(route_edges),
        congestion_forecast=engine.congestion_forecast(route_edges),
        fuel_share=fuel_share, fuel_volatility_horizon=fuel_vol * (point.horizon_days / 365.0) ** 0.5,
        required_reliability=required_reliability, baseline_reliability=spot_result.reliability,
    )
    return {"strike_price": result.strike_price, "current_spot": result.current_spot,
            "components": result.components.as_dict(), "bounds": engine.strike_engine.strike_bounds(result),
            "explain": result.explain()}


@app.get("/forward/{route}")
def get_forward(route: str):
    origin, destination, mode = _parse_route(route)
    key = engine.state.corridor_key(origin, destination, mode)
    curve = engine.state.forward_curves.get(key)
    if curve is None:
        raise HTTPException(404, f"no forward curve for {route} yet -- POST /simulation first")
    return {"corridor_id": curve.corridor_id, "mode": curve.mode, "current_spot": curve.current_spot, "curve": curve.as_table()}


@app.get("/market")
def get_market():
    metrics = liquidity_engine.measure_all(engine.order_book)
    return {k: vars(v) for k, v in metrics.items()}


@app.get("/orderbook")
def get_orderbook(corridor: Optional[str] = None):
    orders = engine.order_book.open_orders(corridor)
    return [
        {"id": o.id, "side": o.side.value, "participant_id": o.participant_id, "corridor": o.corridor_key(),
         "limit_price": o.limit_price, "remaining_units": o.remaining_units(), "status": o.status.value}
        for o in orders
    ]


@app.get("/risk")
def get_risk(corridor: str = Query(..., description="corridor key e.g. CNSHA->NLRTM:SEA"), confidence: float = 0.95):
    spot_result = engine.state.spot_prices.get(corridor)
    strike_result = engine.state.strike_prices.get(corridor)
    curve = engine.state.forward_curves.get(corridor)
    if not (spot_result and strike_result and curve):
        raise HTTPException(404, f"corridor '{corridor}' not priced yet -- POST /simulation first")
    mc = monte_carlo_engine.simulate(
        corridor_id=corridor, forward_point=curve.point(Tenor.MONTHLY), strike_price=strike_result.strike_price,
        expected_transit_days=spot_result.expected_transit_days, transit_std_days=spot_result.transit_std_days,
        deadline_days=spot_result.expected_transit_days * 1.15, volume_units=2.0,
        capacity_scarcity_forecast=0.4,
    )
    exposure = RiskFactorExposure(
        price_risk=min(1.0, curve.point(Tenor.MONTHLY).volatility_annualised),
        capacity_risk=0.4, delay_risk=1 - mc.reliability, fuel_risk=0.3,
        geopolitical_risk=0.2, weather_risk=0.2, route_risk=0.15,
    )
    report = build_risk_report(
        pnl_samples=[mc.buyer_pnl[p] for p in [5, 10, 50, 90, 95, 99]],
        exposure=exposure, expected_transit_days=spot_result.expected_transit_days,
        transit_std_days=spot_result.transit_std_days, deadline_days=spot_result.expected_transit_days * 1.15,
        confidence=confidence,
    )
    return {
        "exposure_composite": report.exposure.composite(),
        "var": report.var_result.var, "cvar": report.var_result.cvar,
        "expected_loss": report.var_result.expected_loss,
        "deadline_failure_probability": report.deadline_failure_probability,
        "monte_carlo": mc.summary(),
    }


@app.get("/contracts")
def get_contracts(status: Optional[str] = None):
    contracts = list(engine.state.contracts.values())
    if status:
        contracts = [c for c in contracts if c.status.value == status]
    return [
        {"id": c.id, "type": c.contract_type.value, "buyer": c.buyer_id, "seller": c.seller_id,
         "origin": c.origin_id, "destination": c.destination_id, "mode": c.mode, "price": c.price,
         "volume_units": c.volume_units, "status": c.status.value}
        for c in contracts
    ]


# ---------------------------------------------------------------------------
# POST endpoints
# ---------------------------------------------------------------------------

@app.post("/price/spot")
def post_price_spot(req: SpotPriceRequest):
    cargo = _to_cargo_spec(req.cargo)
    result, route = _price_spot(req.origin_id, req.destination_id, req.mode, cargo, req.deadline_days, req.required_reliability)
    return {"price": result.price, "components": result.components.as_dict(),
            "expected_transit_days": result.expected_transit_days, "transit_std_days": result.transit_std_days,
            "reliability": result.reliability, "mode_sequence": [e.mode.value for e in route]}


@app.post("/price/strike")
def post_price_strike(req: StrikePriceRequest):
    key = engine.state.corridor_key(req.origin_id, req.destination_id, req.mode)
    curve = engine.state.forward_curves.get(key)
    spot_result = engine.state.spot_prices.get(key)
    route_edges = engine.lane_route(req.origin_id, req.destination_id, req.mode)
    if not route_edges:
        raise HTTPException(404, "no route found")
    if curve is None or spot_result is None:
        # price on the fly rather than requiring a prior simulation step
        cargo = CargoSpec(cargo_type=CargoType.CONTAINER_40FT, weight_kg=22_000, volume_m3=67.0, declared_value_usd=60_000)
        spot_result, route_edges = _price_spot(req.origin_id, req.destination_id, req.mode, cargo, 45, req.required_reliability)
        curve = engine.forward_engine.build_curve(key, req.mode.value, engine.clock.now, spot_result.price, [spot_result.price])

    point = curve.point(req.tenor)
    fuel_type = MODE_FUEL_TYPE[req.mode]
    fuel_share = route_edges[0].fuel_share
    fuel_vol = engine.fuel_engine.params[fuel_type].volatility / engine.fuel_engine.params[fuel_type].long_run_mean

    result = engine.strike_engine.compute_strike(
        corridor_id=key, mode=req.mode.value, forward_point=point, current_spot=spot_result.price,
        capacity_scarcity_forecast=engine.capacity_scarcity_forecast(route_edges),
        congestion_forecast=engine.congestion_forecast(route_edges),
        fuel_share=fuel_share, fuel_volatility_horizon=fuel_vol * (point.horizon_days / 365.0) ** 0.5,
        required_reliability=req.required_reliability, baseline_reliability=spot_result.reliability,
        execution_window_start=point.horizon_date, execution_window_end=point.horizon_date + timedelta(days=14),
    )
    bounds = engine.strike_engine.strike_bounds(result)
    return {"strike_price": result.strike_price, "current_spot": result.current_spot,
            "expected_future_spot": point.expected_spot, "components": result.components.as_dict(), "bounds": bounds}


@app.post("/route/optimise")
def post_route_optimise(req: RouteOptimiseRequest):
    cargo = _to_cargo_spec(req.cargo)
    shipment = Shipment(origin_id=req.origin_id, destination_id=req.destination_id, cargo=cargo,
                         deadline=engine.clock.now + timedelta(days=req.deadline_days))
    candidates = engine.route_engine.price_candidates(shipment, engine.capacity_pools)
    if not candidates:
        raise HTTPException(404, "no feasible routes found")
    weights = RouteObjectiveWeights(**req.weights) if req.weights else None
    scored = score_routes(candidates, weights)
    return [
        {"path": s.candidate.path_ids, "modes": s.candidate.modes, "score": round(s.score, 4), **{k: round(v, 2) for k, v in s.breakdown.items()}}
        for s in scored
    ]


@app.post("/scenario")
def post_scenario(req: ScenarioRequest):
    if req.scenario_id not in STANDARD_SCENARIOS:
        raise HTTPException(404, f"unknown scenario '{req.scenario_id}'. known: {list(STANDARD_SCENARIOS)}")
    comparison = ScenarioEngine().run_comparison(req.scenario_id, n_steps=req.n_steps, start=engine.clock.now)
    return {"scenario_id": req.scenario_id, "summary": comparison.summary()}


@app.post("/simulation")
def post_simulation(req: SimulationRequest):
    history = [engine.step() for _ in range(max(1, req.n_steps))]
    return {"steps_run": len(history), "latest": history[-1]}


@app.get("/")
def root():
    return {
        "name": "LogisticsStrike",
        "version": "0.1.0",
        "step": engine.clock.step_index,
        "tracked_lanes": [f"{o}->{d}:{m.value}" for o, d, m in engine.tracked_lanes],
    }
