"""Road network model: truck depots and highway segments."""

from __future__ import annotations

from dataclasses import dataclass

from logistics_strike.core.state import NodeType, Region
from logistics_strike.network.multimodal_graph import Node


@dataclass
class TruckDepot:
    id: str
    name: str
    country: str
    region: Region
    lat: float
    lon: float
    fleet_size: int
    nominal_loads_per_day: float
    fleet_utilisation: float = 0.6

    def to_node(self) -> Node:
        return Node(
            id=self.id,
            name=self.name,
            node_type=NodeType.TRUCK_DEPOT,
            region=self.region,
            country=self.country,
            lat=self.lat,
            lon=self.lon,
            attributes={"fleet_size": self.fleet_size},
        )

    def congestion_score(self) -> float:
        return max(0.0, min(1.0, self.fleet_utilisation))


@dataclass
class RoadSegment:
    id: str
    origin_id: str
    destination_id: str
    length_km: float
    lanes: int
    nominal_daily_traffic: float
    capacity_daily_traffic: float
    accident_rate: float = 0.01  # incidents per day
    weather_exposure: float = 0.3  # 0-1, sensitivity to weather disruption

    def traffic_ratio(self) -> float:
        if self.capacity_daily_traffic <= 0:
            return 1.0
        return self.nominal_daily_traffic / self.capacity_daily_traffic

    def congestion_score(self) -> float:
        base = min(1.5, self.traffic_ratio()) / 1.5
        incident_penalty = min(0.3, self.accident_rate * 10)
        return max(0.0, min(1.0, base + incident_penalty))


DEFAULT_TRUCK_DEPOTS: list[TruckDepot] = [
    TruckDepot("NLDEP1", "Rotterdam Depot", "NL", Region.NORTH_EUROPE, 51.90, 4.48, fleet_size=1200, nominal_loads_per_day=900),
    TruckDepot("DEDEP1", "Duisburg Depot", "DE", Region.NORTH_EUROPE, 51.43, 6.76, fleet_size=800, nominal_loads_per_day=600),
    TruckDepot("USDEP1", "LA Basin Depot", "US", Region.NORTH_AMERICA_WEST, 33.94, -118.4, fleet_size=1500, nominal_loads_per_day=1100),
    TruckDepot("CNDEP1", "Shanghai Depot", "CN", Region.NORTH_ASIA, 31.30, 121.5, fleet_size=2000, nominal_loads_per_day=1600),
]

DEFAULT_ROAD_SEGMENTS: list[RoadSegment] = [
    RoadSegment("RD_RTM_DUI", "NLDEP1", "DEDEP1", length_km=220, lanes=4, nominal_daily_traffic=52000, capacity_daily_traffic=60000),
    RoadSegment("RD_LAX_DEPOT", "USLAX", "USDEP1", length_km=35, lanes=6, nominal_daily_traffic=140000, capacity_daily_traffic=150000),
    RoadSegment("RD_SHA_DEPOT", "CNSHA", "CNDEP1", length_km=28, lanes=8, nominal_daily_traffic=180000, capacity_daily_traffic=210000),
]
