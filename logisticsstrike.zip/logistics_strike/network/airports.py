"""Air cargo terminal model."""

from __future__ import annotations

from dataclasses import dataclass

from logistics_strike.core.state import NodeType, Region
from logistics_strike.network.multimodal_graph import Node


@dataclass
class Airport:
    id: str
    name: str
    country: str
    region: Region
    lat: float
    lon: float
    runway_slots_per_day: int
    cargo_terminal_capacity_tonnes_per_day: float
    nominal_freighter_flights_per_week: float
    slot_utilisation: float = 0.6

    def to_node(self) -> Node:
        return Node(
            id=self.id,
            name=self.name,
            node_type=NodeType.AIRPORT,
            region=self.region,
            country=self.country,
            lat=self.lat,
            lon=self.lon,
            attributes={
                "runway_slots_per_day": self.runway_slots_per_day,
                "cargo_terminal_capacity_tonnes_per_day": self.cargo_terminal_capacity_tonnes_per_day,
            },
        )

    def congestion_score(self) -> float:
        return max(0.0, min(1.0, self.slot_utilisation))


DEFAULT_AIRPORTS: list[Airport] = [
    Airport("CNPVG", "Shanghai Pudong", "CN", Region.NORTH_ASIA, 31.14, 121.80, runway_slots_per_day=900, cargo_terminal_capacity_tonnes_per_day=9500, nominal_freighter_flights_per_week=420),
    Airport("HKHKG", "Hong Kong", "HK", Region.NORTH_ASIA, 22.31, 113.91, runway_slots_per_day=1000, cargo_terminal_capacity_tonnes_per_day=13000, nominal_freighter_flights_per_week=520),
    Airport("NLAMS", "Amsterdam Schiphol", "NL", Region.NORTH_EUROPE, 52.31, 4.76, runway_slots_per_day=1200, cargo_terminal_capacity_tonnes_per_day=5200, nominal_freighter_flights_per_week=210),
    Airport("DEFRA", "Frankfurt", "DE", Region.NORTH_EUROPE, 50.03, 8.57, runway_slots_per_day=1300, cargo_terminal_capacity_tonnes_per_day=7000, nominal_freighter_flights_per_week=260),
    Airport("USMEM", "Memphis", "US", Region.NORTH_AMERICA_EAST, 35.04, -89.98, runway_slots_per_day=1100, cargo_terminal_capacity_tonnes_per_day=11000, nominal_freighter_flights_per_week=600),
    Airport("USANC", "Anchorage", "US", Region.NORTH_AMERICA_WEST, 61.17, -149.99, runway_slots_per_day=500, cargo_terminal_capacity_tonnes_per_day=6000, nominal_freighter_flights_per_week=380),
    Airport("AEDXB", "Dubai", "AE", Region.MIDDLE_EAST, 25.25, 55.36, runway_slots_per_day=1150, cargo_terminal_capacity_tonnes_per_day=6800, nominal_freighter_flights_per_week=300),
]
