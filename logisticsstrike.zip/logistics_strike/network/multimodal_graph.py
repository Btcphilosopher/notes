"""The world as a multimodal directed graph.

Nodes are physical locations (ports, airports, rail terminals, truck depots,
warehouses, distribution centres, border crossings, hubs). Edges are legs of
transport -- a sea lane, an air route, a rail corridor, a highway segment, or
an intra-hub transfer -- each carrying the physical/economic attributes the
rest of the platform prices against: distance, capacity, transit time, cost,
reliability, fuel exposure, congestion and risk.

Built on ``networkx.MultiDiGraph`` so that parallel edges (e.g. two shipping
lines serving the same port pair with different service levels) are
first-class.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

import networkx as nx

from logistics_strike.core.state import NodeType, Region, TransportMode


@dataclass
class Node:
    id: str
    name: str
    node_type: NodeType
    region: Region
    country: str
    lat: float
    lon: float
    # generic operational attributes filled in by network/{ports,airports,...}
    attributes: Dict[str, float] = field(default_factory=dict)

    def __hash__(self) -> int:
        return hash(self.id)


@dataclass
class Edge:
    """A single directed leg of transport between two nodes."""

    origin: str
    destination: str
    mode: TransportMode
    distance_km: float
    base_transit_days: float
    transit_variability_days: float  # std-dev of transit time
    capacity_per_week: float  # TEU-equivalent / tonnes / kg depending on mode
    base_cost_per_unit: float  # currency per TEU / kg / pallet depending on mode
    reliability: float  # baseline on-time probability, 0-1
    fuel_share: float  # fraction of cost exposed to fuel price moves, 0-1
    risk_score: float = 0.0  # baseline geopolitical/route risk, 0-1
    congestion: float = 0.0  # dynamic, updated every timestep, 0-1
    carrier_id: Optional[str] = None
    service_name: str = ""

    @property
    def key(self) -> str:
        return f"{self.origin}->{self.destination}:{self.mode.value}:{self.service_name or self.carrier_id or ''}"


class MultimodalGraph:
    """Thin, typed wrapper around a ``networkx.MultiDiGraph``."""

    def __init__(self) -> None:
        self._g = nx.MultiDiGraph()

    # -- construction -------------------------------------------------
    def add_node(self, node: Node) -> None:
        self._g.add_node(node.id, obj=node)

    def add_edge(self, edge: Edge) -> None:
        self._g.add_edge(edge.origin, edge.destination, key=edge.key, obj=edge)

    # -- lookups --------------------------------------------------------
    def node(self, node_id: str) -> Node:
        return self._g.nodes[node_id]["obj"]

    def has_node(self, node_id: str) -> bool:
        return node_id in self._g.nodes

    def nodes(self, node_type: Optional[NodeType] = None) -> List[Node]:
        out = [d["obj"] for _, d in self._g.nodes(data=True)]
        if node_type is not None:
            out = [n for n in out if n.node_type == node_type]
        return out

    def edges(self, mode: Optional[TransportMode] = None) -> List[Edge]:
        out = [d["obj"] for _, _, d in self._g.edges(data=True)]
        if mode is not None:
            out = [e for e in out if e.mode == mode]
        return out

    def edges_between(self, origin: str, destination: str) -> List[Edge]:
        if not self._g.has_edge(origin, destination):
            return []
        return [d["obj"] for d in self._g.get_edge_data(origin, destination).values()]

    def out_edges(self, node_id: str) -> List[Edge]:
        return [d["obj"] for _, _, d in self._g.out_edges(node_id, data=True)]

    def neighbours(self, node_id: str) -> List[str]:
        return list(self._g.successors(node_id))

    @property
    def raw(self) -> nx.MultiDiGraph:
        return self._g

    def update_edge_congestion(self, edge: Edge, congestion: float) -> None:
        edge.congestion = max(0.0, min(1.0, congestion))

    def corridor_edges(self, origin_region: Region, destination_region: Region) -> List[Edge]:
        out = []
        for e in self.edges():
            try:
                o = self.node(e.origin).region
                d = self.node(e.destination).region
            except KeyError:
                continue
            if o == origin_region and d == destination_region:
                out.append(e)
        return out

    def summary(self) -> Dict[str, int]:
        return {
            "nodes": self._g.number_of_nodes(),
            "edges": self._g.number_of_edges(),
        }
