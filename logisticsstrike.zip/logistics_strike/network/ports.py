"""Sea port operational model.

A port constrains sea-mode capacity through berths, cranes and yard space.
Its congestion state (queue of vessels waiting for a berth) feeds directly
into :mod:`logistics_strike.pricing.congestion` and therefore into spot and
strike prices.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from logistics_strike.core.state import NodeType, Region
from logistics_strike.network.multimodal_graph import Node


@dataclass
class Port:
    id: str
    name: str
    country: str
    region: Region
    lat: float
    lon: float
    berths: int
    cranes_per_berth: int
    yard_capacity_teu: int
    nominal_vessel_arrivals_per_week: float
    # dynamic state, mutated each timestep by the congestion model
    vessel_queue: int = 0
    yard_utilisation: float = 0.55
    labour_availability: float = 1.0  # 1.0 = fully staffed

    def to_node(self) -> Node:
        return Node(
            id=self.id,
            name=self.name,
            node_type=NodeType.PORT,
            region=self.region,
            country=self.country,
            lat=self.lat,
            lon=self.lon,
            attributes={
                "berths": self.berths,
                "cranes_per_berth": self.cranes_per_berth,
                "yard_capacity_teu": self.yard_capacity_teu,
            },
        )

    @property
    def crane_capacity(self) -> int:
        return self.berths * self.cranes_per_berth

    def berth_utilisation(self) -> float:
        """Fraction of nominal weekly berth throughput currently in use.

        > 1.0 means arrivals exceed service capacity -> queue builds.
        """
        service_rate = self.berths * 7  # simplistic: 1 vessel/berth/day serviceable
        if service_rate <= 0:
            return 1.0
        return self.nominal_vessel_arrivals_per_week / service_rate

    def queueing_score(self) -> float:
        """0-1 congestion proxy blending queue length, berth and yard use."""
        queue_component = min(1.0, self.vessel_queue / max(1, self.berths * 3))
        berth_component = min(1.0, self.berth_utilisation())
        yard_component = min(1.0, self.yard_utilisation)
        labour_penalty = 1.0 - self.labour_availability
        score = 0.4 * queue_component + 0.3 * berth_component + 0.2 * yard_component + 0.1 * labour_penalty
        return max(0.0, min(1.0, score))


DEFAULT_PORTS: list[Port] = [
    Port("CNSHA", "Shanghai", "CN", Region.NORTH_ASIA, 31.23, 121.47, berths=45, cranes_per_berth=4, yard_capacity_teu=5_000_000, nominal_vessel_arrivals_per_week=310),
    Port("CNNGB", "Ningbo-Zhoushan", "CN", Region.NORTH_ASIA, 29.87, 121.55, berths=38, cranes_per_berth=4, yard_capacity_teu=3_500_000, nominal_vessel_arrivals_per_week=260),
    Port("SGSIN", "Singapore", "SG", Region.SOUTHEAST_ASIA, 1.29, 103.85, berths=52, cranes_per_berth=4, yard_capacity_teu=4_200_000, nominal_vessel_arrivals_per_week=340),
    Port("NLRTM", "Rotterdam", "NL", Region.NORTH_EUROPE, 51.95, 4.14, berths=32, cranes_per_berth=4, yard_capacity_teu=2_900_000, nominal_vessel_arrivals_per_week=200),
    Port("DEHAM", "Hamburg", "DE", Region.NORTH_EUROPE, 53.54, 9.98, berths=24, cranes_per_berth=3, yard_capacity_teu=1_800_000, nominal_vessel_arrivals_per_week=150),
    Port("USLAX", "Los Angeles", "US", Region.NORTH_AMERICA_WEST, 33.73, -118.26, berths=27, cranes_per_berth=4, yard_capacity_teu=2_200_000, nominal_vessel_arrivals_per_week=170),
    Port("USNYC", "New York/New Jersey", "US", Region.NORTH_AMERICA_EAST, 40.66, -74.06, berths=22, cranes_per_berth=3, yard_capacity_teu=1_900_000, nominal_vessel_arrivals_per_week=140),
    Port("AEJEA", "Jebel Ali", "AE", Region.MIDDLE_EAST, 25.02, 55.06, berths=30, cranes_per_berth=4, yard_capacity_teu=2_600_000, nominal_vessel_arrivals_per_week=190),
    Port("EGPSD", "Port Said", "EG", Region.MIDDLE_EAST, 31.26, 32.30, berths=18, cranes_per_berth=3, yard_capacity_teu=1_100_000, nominal_vessel_arrivals_per_week=110),
    Port("BRSSZ", "Santos", "BR", Region.LATIN_AMERICA, -23.96, -46.33, berths=16, cranes_per_berth=3, yard_capacity_teu=900_000, nominal_vessel_arrivals_per_week=95),
]
