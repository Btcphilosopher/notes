"""Warehouse / distribution-centre storage model.

Storage is finite capacity too: it feeds :mod:`logistics_strike.analytics.pnl`
(inventory carrying cost) and :mod:`logistics_strike.analytics.pnl`'s total
landed cost calculation, since a slower shipment implies more inventory
sitting in a warehouse for longer.
"""

from __future__ import annotations

from dataclasses import dataclass

from logistics_strike.core.state import NodeType, Region
from logistics_strike.network.multimodal_graph import Node


@dataclass
class Warehouse:
    id: str
    name: str
    country: str
    region: Region
    lat: float
    lon: float
    storage_capacity_m3: float
    storage_cost_per_m3_per_day: float
    used_capacity_m3: float = 0.0
    is_distribution_centre: bool = False

    def to_node(self) -> Node:
        return Node(
            id=self.id,
            name=self.name,
            node_type=NodeType.DISTRIBUTION_CENTRE if self.is_distribution_centre else NodeType.WAREHOUSE,
            region=self.region,
            country=self.country,
            lat=self.lat,
            lon=self.lon,
            attributes={"storage_capacity_m3": self.storage_capacity_m3},
        )

    def utilisation(self) -> float:
        if self.storage_capacity_m3 <= 0:
            return 1.0
        return max(0.0, min(1.0, self.used_capacity_m3 / self.storage_capacity_m3))


DEFAULT_WAREHOUSES: list[Warehouse] = [
    Warehouse("NLWH1", "Rotterdam DC", "NL", Region.NORTH_EUROPE, 51.92, 4.5, storage_capacity_m3=250_000, storage_cost_per_m3_per_day=0.35, is_distribution_centre=True),
    Warehouse("USWH1", "Inland Empire DC", "US", Region.NORTH_AMERICA_WEST, 34.06, -117.3, storage_capacity_m3=400_000, storage_cost_per_m3_per_day=0.30, is_distribution_centre=True),
    Warehouse("CNWH1", "Shanghai Bonded WH", "CN", Region.NORTH_ASIA, 31.25, 121.55, storage_capacity_m3=300_000, storage_cost_per_m3_per_day=0.22),
]
