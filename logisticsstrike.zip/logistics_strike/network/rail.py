"""Rail terminal and corridor model."""

from __future__ import annotations

from dataclasses import dataclass

from logistics_strike.core.state import NodeType, Region
from logistics_strike.network.multimodal_graph import Node


@dataclass
class RailTerminal:
    id: str
    name: str
    country: str
    region: Region
    lat: float
    lon: float
    daily_wagon_slots: int
    nominal_trains_per_week: float
    slot_utilisation: float = 0.55

    def to_node(self) -> Node:
        return Node(
            id=self.id,
            name=self.name,
            node_type=NodeType.RAIL_TERMINAL,
            region=self.region,
            country=self.country,
            lat=self.lat,
            lon=self.lon,
            attributes={"daily_wagon_slots": self.daily_wagon_slots},
        )

    def congestion_score(self) -> float:
        return max(0.0, min(1.0, self.slot_utilisation))


@dataclass
class RailCorridor:
    id: str
    name: str
    track_capacity_trains_per_day: int
    track_utilisation: float = 0.5

    def congestion_score(self) -> float:
        return max(0.0, min(1.0, self.track_utilisation))


DEFAULT_RAIL_TERMINALS: list[RailTerminal] = [
    RailTerminal("CNZHY", "Zhengzhou Rail Hub", "CN", Region.NORTH_ASIA, 34.75, 113.62, daily_wagon_slots=600, nominal_trains_per_week=40),
    RailTerminal("PLMLA", "Malaszewicze", "PL", Region.NORTH_EUROPE, 52.17, 23.62, daily_wagon_slots=500, nominal_trains_per_week=55),
    RailTerminal("DEDUI", "Duisburg", "DE", Region.NORTH_EUROPE, 51.43, 6.76, daily_wagon_slots=700, nominal_trains_per_week=60),
    RailTerminal("USCHI", "Chicago Intermodal", "US", Region.NORTH_AMERICA_EAST, 41.88, -87.63, daily_wagon_slots=900, nominal_trains_per_week=110),
]

DEFAULT_RAIL_CORRIDORS: list[RailCorridor] = [
    RailCorridor("NEW_SILK_ROAD", "New Eurasian Land Bridge", track_capacity_trains_per_day=45),
    RailCorridor("NA_TRANSCON", "North American Transcontinental", track_capacity_trains_per_day=180),
]
