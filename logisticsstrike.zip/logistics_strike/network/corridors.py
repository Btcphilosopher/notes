"""Named trade corridors: groupings of region pairs used for indices,
forward curves and scenario targeting (e.g. "ASIA-EUROPE", "TRANSATLANTIC").
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

from logistics_strike.core.state import Region, TransportMode


@dataclass(frozen=True)
class Corridor:
    id: str
    name: str
    region_pairs: Tuple[Tuple[Region, Region], ...]
    modes: Tuple[TransportMode, ...]


CORRIDORS: List[Corridor] = [
    Corridor(
        "ASIA_EUROPE",
        "Asia-Europe",
        ((Region.NORTH_ASIA, Region.NORTH_EUROPE), (Region.SOUTHEAST_ASIA, Region.NORTH_EUROPE)),
        (TransportMode.SEA, TransportMode.RAIL, TransportMode.AIR),
    ),
    Corridor(
        "TRANSPACIFIC",
        "Transpacific",
        ((Region.NORTH_ASIA, Region.NORTH_AMERICA_WEST), (Region.SOUTHEAST_ASIA, Region.NORTH_AMERICA_WEST)),
        (TransportMode.SEA, TransportMode.AIR),
    ),
    Corridor(
        "TRANSATLANTIC",
        "Transatlantic",
        ((Region.NORTH_EUROPE, Region.NORTH_AMERICA_EAST),),
        (TransportMode.SEA, TransportMode.AIR),
    ),
    Corridor(
        "INTRA_EUROPE_ROAD",
        "Intra-Europe Road",
        ((Region.NORTH_EUROPE, Region.NORTH_EUROPE),),
        (TransportMode.ROAD,),
    ),
    Corridor(
        "NA_TRUCKING",
        "North American Trucking",
        ((Region.NORTH_AMERICA_WEST, Region.NORTH_AMERICA_EAST),),
        (TransportMode.ROAD, TransportMode.RAIL),
    ),
]


def corridor_for_regions(origin: Region, destination: Region, mode: TransportMode) -> Corridor | None:
    for c in CORRIDORS:
        if mode not in c.modes:
            continue
        for o, d in c.region_pairs:
            if (o == origin and d == destination) or (o == destination and d == origin):
                return c
    return None
