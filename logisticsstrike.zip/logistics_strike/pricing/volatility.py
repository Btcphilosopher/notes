"""Freight volatility engine.

Measures volatility of any tracked series -- spot prices, transit times,
fuel prices, capacity utilisation, congestion, weather severity, demand --
using a selectable model. Financial-style models (EWMA, GARCH) are offered
because freight *prices* genuinely cluster and mean-revert like commodities,
but they are opt-in per series: a logistics quantity like transit-time
variance is better served by plain historical/rolling volatility, so nothing
forces a GARCH fit onto data it doesn't suit (requirement #9).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Sequence

import numpy as np


class VolatilityModel(str, Enum):
    HISTORICAL = "HISTORICAL"
    EWMA = "EWMA"
    GARCH = "GARCH"
    MEAN_REVERSION = "MEAN_REVERSION"
    JUMP = "JUMP"


@dataclass
class VolatilityResult:
    model: VolatilityModel
    annualised_vol: float
    period_vol: float  # volatility over the sampling period used (e.g. daily)
    details: dict


def _returns(series: Sequence[float]) -> np.ndarray:
    arr = np.asarray(series, dtype=float)
    arr = arr[arr > 0]
    if len(arr) < 2:
        return np.array([])
    return np.diff(np.log(arr))


def historical_volatility(series: Sequence[float], periods_per_year: float = 365.0) -> VolatilityResult:
    r = _returns(series)
    if len(r) < 2:
        return VolatilityResult(VolatilityModel.HISTORICAL, 0.0, 0.0, {"n": len(r)})
    period_vol = float(np.std(r, ddof=1))
    return VolatilityResult(
        VolatilityModel.HISTORICAL,
        annualised_vol=period_vol * np.sqrt(periods_per_year),
        period_vol=period_vol,
        details={"n": len(r)},
    )


def ewma_volatility(series: Sequence[float], lam: float = 0.94, periods_per_year: float = 365.0) -> VolatilityResult:
    r = _returns(series)
    if len(r) < 2:
        return VolatilityResult(VolatilityModel.EWMA, 0.0, 0.0, {"lambda": lam})
    var = r[0] ** 2
    for x in r[1:]:
        var = lam * var + (1 - lam) * x ** 2
    period_vol = float(np.sqrt(var))
    return VolatilityResult(
        VolatilityModel.EWMA,
        annualised_vol=period_vol * np.sqrt(periods_per_year),
        period_vol=period_vol,
        details={"lambda": lam},
    )


def garch_1_1_volatility(
    series: Sequence[float],
    omega: float = 1e-6,
    alpha: float = 0.08,
    beta: float = 0.90,
    periods_per_year: float = 365.0,
) -> VolatilityResult:
    """A hand-rolled GARCH(1,1) filter (no MLE fit -- fixed, plausible
    parameters) producing a conditional-volatility path and its latest value.
    Adequate for a simulation engine; swap in ``arch``/``statsmodels`` for a
    fitted model if production-grade calibration is required.
    """
    r = _returns(series)
    if len(r) < 2:
        return VolatilityResult(VolatilityModel.GARCH, 0.0, 0.0, {"omega": omega, "alpha": alpha, "beta": beta})
    var = float(np.var(r))
    path = [var]
    for x in r[1:]:
        var = omega + alpha * x ** 2 + beta * var
        path.append(var)
    period_vol = float(np.sqrt(path[-1]))
    return VolatilityResult(
        VolatilityModel.GARCH,
        annualised_vol=period_vol * np.sqrt(periods_per_year),
        period_vol=period_vol,
        details={"omega": omega, "alpha": alpha, "beta": beta, "path_len": len(path)},
    )


def mean_reversion_halflife(series: Sequence[float]) -> VolatilityResult:
    """Estimate mean-reversion speed via OLS on ``dx_t = a + b*x_{t-1} + e``
    (Ornstein-Uhlenbeck discretisation). Returns half-life in periods inside
    ``details`` and residual std as the "volatility"."""
    arr = np.asarray(series, dtype=float)
    if len(arr) < 3:
        return VolatilityResult(VolatilityModel.MEAN_REVERSION, 0.0, 0.0, {"half_life": None})
    x = arr[:-1]
    dx = np.diff(arr)
    x_mean, dx_mean = x.mean(), dx.mean()
    denom = np.sum((x - x_mean) ** 2)
    b = float(np.sum((x - x_mean) * (dx - dx_mean)) / denom) if denom > 0 else 0.0
    resid = dx - (dx_mean + b * (x - x_mean))
    resid_std = float(np.std(resid, ddof=1)) if len(resid) > 1 else 0.0
    half_life = float(np.log(2) / -b) if b < 0 else None
    return VolatilityResult(
        VolatilityModel.MEAN_REVERSION,
        annualised_vol=resid_std * np.sqrt(365.0),
        period_vol=resid_std,
        details={"reversion_coeff": b, "half_life_periods": half_life},
    )


def jump_frequency(series: Sequence[float], threshold_sigma: float = 3.0) -> VolatilityResult:
    """Flag returns beyond ``threshold_sigma`` standard deviations as jumps
    and report their empirical frequency and average size."""
    r = _returns(series)
    if len(r) < 2:
        return VolatilityResult(VolatilityModel.JUMP, 0.0, 0.0, {"jump_frequency": 0.0})
    sigma = float(np.std(r, ddof=1))
    if sigma == 0:
        return VolatilityResult(VolatilityModel.JUMP, 0.0, 0.0, {"jump_frequency": 0.0})
    jumps = r[np.abs(r) > threshold_sigma * sigma]
    freq = len(jumps) / len(r)
    avg_size = float(np.mean(np.abs(jumps))) if len(jumps) else 0.0
    return VolatilityResult(
        VolatilityModel.JUMP,
        annualised_vol=sigma * np.sqrt(365.0),
        period_vol=sigma,
        details={"jump_frequency": freq, "avg_jump_size": avg_size, "n_jumps": int(len(jumps))},
    )


_MODEL_FUNCS = {
    VolatilityModel.HISTORICAL: historical_volatility,
    VolatilityModel.EWMA: ewma_volatility,
    VolatilityModel.GARCH: garch_1_1_volatility,
    VolatilityModel.MEAN_REVERSION: mean_reversion_halflife,
    VolatilityModel.JUMP: jump_frequency,
}


def compute_volatility(series: Sequence[float], model: VolatilityModel = VolatilityModel.EWMA, **kwargs) -> VolatilityResult:
    return _MODEL_FUNCS[model](series, **kwargs)


@dataclass
class VolatilityTracker:
    """Rolling window tracker for a single named series (e.g. a corridor's
    spot price), used by forward/strike pricing to derive risk premia."""

    name: str
    max_history: int = 365
    values: List[float] = field(default_factory=list)

    def push(self, value: float) -> None:
        self.values.append(value)
        if len(self.values) > self.max_history:
            self.values = self.values[-self.max_history :]

    def volatility(self, model: VolatilityModel = VolatilityModel.EWMA, **kwargs) -> VolatilityResult:
        return compute_volatility(self.values, model=model, **kwargs)
