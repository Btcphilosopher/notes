"""Strike pricing engine.

The strike price is the economically defensible price for securing future
freight capacity subject to delivery, cost and reliability requirements. It
is built on top of the forward curve's expected future spot
(:mod:`logistics_strike.pricing.forward`) by adding the risk premia a
rational counterparty would require to commit today to a price for
tomorrow's capacity:

    expected future spot
    + capacity risk        (will there be a slot at all?)
    + congestion risk       (will the terminal/route be jammed?)
    + fuel uncertainty       (how much could bunker/jet/diesel move?)
    + delay risk             (reliability premium for the stated requirement)
    + liquidity premium       (thinness of the forward market for this corridor)
    + optionality            (value of locking in a price now vs. waiting)

A strike is *not* simply the expected future spot -- see
:func:`explain_spot_vs_strike` for the reconciliation the platform must
always be able to produce (requirement #7).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from math import erf, exp, pi, sqrt
from typing import Dict, Optional

from logistics_strike.pricing.forward import ForwardPoint
from logistics_strike.risk.reliability import ReliabilityPricingModel


def _black76_atm_call_factor(vol: float, t_years: float) -> float:
    """Approximate at-the-money Black-76 call premium as a fraction of the
    forward price: F * (2*Phi(0.5*sigma*sqrt(T)) - 1) ~= F * sigma*sqrt(T/(2*pi))
    for small vol*sqrt(T). Used to price the optionality of locking in a
    strike today rather than buying at the spot prevailing on the execution
    date."""
    if vol <= 0 or t_years <= 0:
        return 0.0
    sigma_sqrt_t = vol * sqrt(t_years)
    return sigma_sqrt_t / sqrt(2 * pi)


@dataclass
class StrikeComponents:
    expected_future_spot: float = 0.0
    capacity_risk: float = 0.0
    congestion_risk: float = 0.0
    fuel_uncertainty: float = 0.0
    delay_risk: float = 0.0
    liquidity_premium: float = 0.0
    optionality: float = 0.0

    def total(self) -> float:
        return (
            self.expected_future_spot
            + self.capacity_risk
            + self.congestion_risk
            + self.fuel_uncertainty
            + self.delay_risk
            + self.liquidity_premium
            + self.optionality
        )

    def risk_load(self) -> float:
        return self.total() - self.expected_future_spot

    def as_dict(self) -> Dict[str, float]:
        d = {
            "expected_future_spot": self.expected_future_spot,
            "capacity_risk": self.capacity_risk,
            "congestion_risk": self.congestion_risk,
            "fuel_uncertainty": self.fuel_uncertainty,
            "delay_risk": self.delay_risk,
            "liquidity_premium": self.liquidity_premium,
            "optionality": self.optionality,
            "total": self.total(),
        }
        return {k: round(v, 2) for k, v in d.items()}


@dataclass
class StrikeResult:
    corridor_id: str
    mode: str
    execution_window_start: datetime
    execution_window_end: datetime
    required_reliability: float
    baseline_reliability: float
    components: StrikeComponents
    current_spot: float

    @property
    def strike_price(self) -> float:
        return round(self.components.total(), 2)

    def explain(self) -> str:
        c = self.components.as_dict()
        lines = [
            f"STRIKE {self.corridor_id} ({self.mode})",
            f"  window: {self.execution_window_start.date()} - {self.execution_window_end.date()}",
            f"  required reliability: {self.required_reliability*100:.1f}% (baseline {self.baseline_reliability*100:.1f}%)",
            f"  expected future spot   {c['expected_future_spot']:>10.2f}",
            f"  capacity risk          {c['capacity_risk']:>10.2f}",
            f"  congestion risk        {c['congestion_risk']:>10.2f}",
            f"  fuel uncertainty       {c['fuel_uncertainty']:>10.2f}",
            f"  delay/reliability risk {c['delay_risk']:>10.2f}",
            f"  liquidity premium      {c['liquidity_premium']:>10.2f}",
            f"  optionality            {c['optionality']:>10.2f}",
            f"  --------------------------------",
            f"  STRIKE                 {c['total']:>10.2f}",
            f"  (current spot: {self.current_spot:.2f})",
        ]
        return "\n".join(lines)


@dataclass
class StrikeEngine:
    reliability_model: ReliabilityPricingModel = field(default_factory=ReliabilityPricingModel)
    capacity_risk_weight: float = 0.12
    congestion_risk_weight: float = 0.08
    fuel_uncertainty_weight: float = 0.5
    base_liquidity_premium_bps: float = 40.0

    def compute_strike(
        self,
        corridor_id: str,
        mode: str,
        forward_point: ForwardPoint,
        current_spot: float,
        capacity_scarcity_forecast: float,
        congestion_forecast: float,
        fuel_share: float,
        fuel_volatility_horizon: float,  # e.g. annualised fuel vol scaled to sqrt(horizon)
        required_reliability: float,
        baseline_reliability: float,
        order_book_depth: float = 1.0,  # 0 = illiquid/no quotes, 1 = deep liquid market
        execution_window_start: Optional[datetime] = None,
        execution_window_end: Optional[datetime] = None,
    ) -> StrikeResult:
        expected_future_spot = forward_point.expected_spot

        capacity_risk = expected_future_spot * capacity_scarcity_forecast * self.capacity_risk_weight
        congestion_risk = expected_future_spot * congestion_forecast * self.congestion_risk_weight
        fuel_uncertainty = expected_future_spot * fuel_share * fuel_volatility_horizon * self.fuel_uncertainty_weight

        delay_risk = self.reliability_model.reliability_premium(
            expected_future_spot, baseline_reliability, required_reliability
        )
        delay_risk = max(0.0, delay_risk)  # a strike never pays the shipper for accepting lower reliability

        illiquidity_factor = 1.0 + (1.0 - max(0.0, min(1.0, order_book_depth)))
        liquidity_premium = expected_future_spot * (self.base_liquidity_premium_bps / 10_000.0) * illiquidity_factor

        t_years = forward_point.horizon_days / 365.0
        option_factor = _black76_atm_call_factor(forward_point.volatility_annualised, t_years)
        optionality = expected_future_spot * option_factor

        components = StrikeComponents(
            expected_future_spot=expected_future_spot,
            capacity_risk=capacity_risk,
            congestion_risk=congestion_risk,
            fuel_uncertainty=fuel_uncertainty,
            delay_risk=delay_risk,
            liquidity_premium=liquidity_premium,
            optionality=optionality,
        )

        return StrikeResult(
            corridor_id=corridor_id,
            mode=mode,
            execution_window_start=execution_window_start or forward_point.horizon_date,
            execution_window_end=execution_window_end or forward_point.horizon_date,
            required_reliability=required_reliability,
            baseline_reliability=baseline_reliability,
            components=components,
            current_spot=current_spot,
        )

    def strike_bounds(self, result: StrikeResult) -> Dict[str, float]:
        """Section 26: minimum reasonable / fair / risk-adjusted / maximum
        commercial strike, each explained by which components it includes."""
        c = result.components
        minimum_reasonable = c.expected_future_spot + 0.3 * c.capacity_risk
        fair = c.expected_future_spot + c.capacity_risk + c.congestion_risk + c.fuel_uncertainty
        risk_adjusted = c.total()
        maximum_commercial = risk_adjusted + 0.5 * c.liquidity_premium + 0.5 * c.optionality
        return {
            "minimum_reasonable_strike": round(minimum_reasonable, 2),
            "fair_strike": round(fair, 2),
            "risk_adjusted_strike": round(risk_adjusted, 2),
            "maximum_commercial_strike": round(maximum_commercial, 2),
        }


def explain_spot_vs_strike(current_spot: float, expected_future_spot: float, strike_price: float) -> str:
    return (
        f"CURRENT SPOT:          {current_spot:,.2f}\n"
        f"EXPECTED FUTURE SPOT:  {expected_future_spot:,.2f}\n"
        f"RISK-ADJUSTED STRIKE:  {strike_price:,.2f}\n\n"
        f"The spot price is what this shipment would cost if executed right now, "
        f"under today's capacity, congestion and fuel conditions. The strike price "
        f"is what a rational counterparty should accept today to guarantee execution "
        f"in the future: it starts from the expected future spot and adds the price "
        f"of the risks a shipper offloads onto the carrier by locking in early -- "
        f"capacity scarcity, congestion, fuel uncertainty, the shipper's reliability "
        f"requirement, market illiquidity and the optionality of certainty itself."
    )
