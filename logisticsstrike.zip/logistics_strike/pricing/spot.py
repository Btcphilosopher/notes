"""Spot pricing engine.

Computes the cost of moving a specific shipment along a specific
(multi-leg) route *right now*, as an emergent sum of priced components
rather than a lookup table:

    base transport cost
    + capacity scarcity
    + fuel
    + congestion
    + handling
    + risk
    + urgency
    + route conditions (transit-time/variance loading)

Every component is retained on the result (:class:`SpotPriceResult`) so the
calculation is fully inspectable -- callers can print
``result.components`` and see exactly what produced the headline number.

Costs are expressed per TEU-equivalent unit of cargo (see
``cargo.cargo.CARGO_PROFILE``) as a deliberate simplifying convention so
that a single cost basis works across sea/rail/road/air in this platform;
a production system would additionally chargeable-weight air cargo.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from logistics_strike.cargo.cargo import CargoSpec
from logistics_strike.cargo.shipments import Shipment
from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.core.state import TransportMode
from logistics_strike.network.multimodal_graph import Edge
from logistics_strike.pricing.fuel import FuelPriceEngine, FuelType

MODE_FUEL_TYPE: Dict[TransportMode, FuelType] = {
    TransportMode.SEA: FuelType.MARINE_VLSFO,
    TransportMode.AIR: FuelType.JET_FUEL,
    TransportMode.ROAD: FuelType.DIESEL,
    TransportMode.RAIL: FuelType.ELECTRICITY,
}


@dataclass
class SpotPriceComponents:
    base_transport: float = 0.0
    capacity_scarcity: float = 0.0
    fuel: float = 0.0
    congestion: float = 0.0
    handling: float = 0.0
    risk: float = 0.0
    urgency: float = 0.0
    route_conditions: float = 0.0

    def total(self) -> float:
        return (
            self.base_transport
            + self.capacity_scarcity
            + self.fuel
            + self.congestion
            + self.handling
            + self.risk
            + self.urgency
            + self.route_conditions
        )

    def as_dict(self) -> Dict[str, float]:
        return {
            "base_transport": round(self.base_transport, 2),
            "capacity_scarcity": round(self.capacity_scarcity, 2),
            "fuel": round(self.fuel, 2),
            "congestion": round(self.congestion, 2),
            "handling": round(self.handling, 2),
            "risk": round(self.risk, 2),
            "urgency": round(self.urgency, 2),
            "route_conditions": round(self.route_conditions, 2),
            "total": round(self.total(), 2),
        }


@dataclass
class SpotPriceResult:
    shipment_id: str
    origin_id: str
    destination_id: str
    mode: TransportMode
    components: SpotPriceComponents
    expected_transit_days: float
    transit_std_days: float
    reliability: float
    currency: str = "USD"

    @property
    def price(self) -> float:
        return round(self.components.total(), 2)

    def explain(self) -> str:
        c = self.components.as_dict()
        lines = [
            f"SPOT {self.origin_id} -> {self.destination_id} ({self.mode.value})",
            f"  base transport      {c['base_transport']:>10.2f}",
            f"  capacity scarcity   {c['capacity_scarcity']:>10.2f}",
            f"  fuel                {c['fuel']:>10.2f}",
            f"  congestion          {c['congestion']:>10.2f}",
            f"  handling            {c['handling']:>10.2f}",
            f"  risk                {c['risk']:>10.2f}",
            f"  urgency             {c['urgency']:>10.2f}",
            f"  route conditions    {c['route_conditions']:>10.2f}",
            f"  ------------------------------",
            f"  TOTAL               {c['total']:>10.2f} {self.currency}",
            f"  transit: {self.expected_transit_days:.1f} days (+/- {self.transit_std_days:.1f})",
            f"  reliability: {self.reliability * 100:.1f}%",
        ]
        return "\n".join(lines)


@dataclass
class SpotPriceEngine:
    fuel_engine: FuelPriceEngine

    def compute_spot(
        self,
        shipment: Shipment,
        route: List[Edge],
        capacity_pools: Optional[Dict[str, CapacityPool]] = None,
    ) -> SpotPriceResult:
        if not route:
            raise ValueError("route must contain at least one edge")

        capacity_pools = capacity_pools or {}
        cargo = shipment.cargo
        teu = cargo.teu_equivalent()

        components = SpotPriceComponents()
        transit_days = 0.0
        transit_var = 0.0
        reliability = 1.0

        for edge in route:
            leg_units = teu
            base = edge.base_cost_per_unit * leg_units
            components.base_transport += base

            pool = capacity_pools.get(edge.key)
            scarcity = pool.scarcity() if pool is not None else 0.35  # neutral default
            # scarcity premium grows convexly as a pool fills up -- the last
            # units of a nearly-full sailing/flight are far pricier than the
            # first, mirroring real yield-managed freight capacity.
            scarcity_multiplier = scarcity ** 2 * 0.9
            components.capacity_scarcity += base * scarcity_multiplier

            fuel_type = MODE_FUEL_TYPE[edge.mode]
            fuel_index = self.fuel_engine.index(fuel_type)  # 1.0 = at long-run mean
            fuel_delta = max(-0.6, fuel_index - 1.0)
            components.fuel += base * edge.fuel_share * fuel_delta

            components.congestion += base * 0.5 * edge.congestion

            components.risk += base * edge.risk_score * 0.4

            # route conditions: reliability/variance loading -- a leg with
            # high transit-time variability relative to its duration is
            # inherently more expensive to firm up.
            if edge.base_transit_days > 0:
                variability_ratio = edge.transit_variability_days / edge.base_transit_days
            else:
                variability_ratio = 0.0
            components.route_conditions += base * 0.15 * min(1.0, variability_ratio)

            transit_days += edge.base_transit_days * (1.0 + 0.5 * edge.congestion)
            transit_var += edge.transit_variability_days ** 2 * (1.0 + edge.congestion)
            reliability *= edge.reliability * (1.0 - 0.25 * edge.congestion) * (1.0 - 0.15 * edge.risk_score)

        components.handling = components.base_transport * (cargo.handling_multiplier() - 1.0)
        components.urgency = components.base_transport * shipment.urgency() * 0.6

        transit_std = transit_var ** 0.5
        mode = route[0].mode if len(set(e.mode for e in route)) == 1 else TransportMode.MULTIMODAL

        return SpotPriceResult(
            shipment_id=shipment.id,
            origin_id=route[0].origin,
            destination_id=route[-1].destination,
            mode=mode,
            components=components,
            expected_transit_days=transit_days,
            transit_std_days=transit_std,
            reliability=max(0.01, min(0.999, reliability)),
        )
