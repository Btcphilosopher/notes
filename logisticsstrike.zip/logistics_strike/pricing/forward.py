"""Freight forward curves.

For a given corridor and mode, projects expected future spot prices across
daily/weekly/monthly/quarterly tenors, and derives a forward price (a modest
risk/liquidity load on top of expected spot) with a volatility-implied
confidence interval. The strike price (``pricing/strike.py``) builds on top
of the forward curve by adding the fuller set of forward-looking risk premia
(capacity, congestion, fuel uncertainty, delay, liquidity, optionality).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Sequence

from logistics_strike.pricing.volatility import VolatilityModel, VolatilityResult, compute_volatility


class Tenor(str, Enum):
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    QUARTERLY = "QUARTERLY"


TENOR_DAYS: Dict[Tenor, int] = {
    Tenor.DAILY: 1,
    Tenor.WEEKLY: 7,
    Tenor.MONTHLY: 30,
    Tenor.QUARTERLY: 90,
}

Z_90 = 1.645  # one-sided-ish two-tail 90% CI multiplier


@dataclass
class ForwardPoint:
    tenor: Tenor
    horizon_date: datetime
    horizon_days: int
    expected_spot: float
    forward_price: float
    volatility_annualised: float
    ci_low: float
    ci_high: float


@dataclass
class ForwardCurve:
    corridor_id: str
    mode: str
    as_of: datetime
    current_spot: float
    points: List[ForwardPoint] = field(default_factory=list)
    volatility_model: VolatilityModel = VolatilityModel.EWMA

    def point(self, tenor: Tenor) -> ForwardPoint:
        for p in self.points:
            if p.tenor == tenor:
                return p
        raise KeyError(tenor)

    def as_table(self) -> List[Dict]:
        return [
            {
                "tenor": p.tenor.value,
                "horizon": p.horizon_date.date().isoformat(),
                "expected_spot": round(p.expected_spot, 2),
                "forward": round(p.forward_price, 2),
                "vol": round(p.volatility_annualised, 4),
                "ci_low": round(p.ci_low, 2),
                "ci_high": round(p.ci_high, 2),
            }
            for p in self.points
        ]


@dataclass
class ForwardCurveEngine:
    liquidity_premium_bps: float = 60.0  # forward vs expected-spot load, in bps
    volatility_model: VolatilityModel = VolatilityModel.EWMA

    def build_curve(
        self,
        corridor_id: str,
        mode: str,
        as_of: datetime,
        current_spot: float,
        spot_history: Sequence[float],
        trend_per_day: float = 0.0,
        seasonality: Dict[Tenor, float] | None = None,
    ) -> ForwardCurve:
        """``trend_per_day`` is a fractional daily drift (e.g. from a
        demand/capacity imbalance signal); ``seasonality`` multiplies the
        expected spot per tenor (e.g. peak-season loading on the monthly and
        quarterly points)."""
        seasonality = seasonality or {}
        vol_result = compute_volatility(list(spot_history) + [current_spot], model=self.volatility_model)

        points: List[ForwardPoint] = []
        for tenor in Tenor:
            days = TENOR_DAYS[tenor]
            horizon_date = as_of + timedelta(days=days)
            drift_factor = (1.0 + trend_per_day) ** days
            season_factor = seasonality.get(tenor, 1.0)
            expected_spot = current_spot * drift_factor * season_factor

            forward_price = expected_spot * (1.0 + self.liquidity_premium_bps / 10_000.0)

            horizon_vol = vol_result.annualised_vol * (days / 365.0) ** 0.5
            ci_half_width = expected_spot * horizon_vol * Z_90

            points.append(
                ForwardPoint(
                    tenor=tenor,
                    horizon_date=horizon_date,
                    horizon_days=days,
                    expected_spot=expected_spot,
                    forward_price=forward_price,
                    volatility_annualised=vol_result.annualised_vol,
                    ci_low=max(0.0, expected_spot - ci_half_width),
                    ci_high=expected_spot + ci_half_width,
                )
            )

        return ForwardCurve(
            corridor_id=corridor_id,
            mode=mode,
            as_of=as_of,
            current_spot=current_spot,
            points=points,
            volatility_model=self.volatility_model,
        )
