"""Congestion model.

Congestion is computed per-node from the operational state of ports,
airports, rail terminals and road segments (queue length, berth/crane/yard
occupancy, slot utilisation, traffic ratios -- see ``network/*``), then
propagated onto the edges that touch each node. The resulting 0-1 congestion
score is consumed directly by :mod:`logistics_strike.pricing.spot` and by
:mod:`logistics_strike.risk.delay` (congestion inflates both price and
transit-time variance).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable

from logistics_strike.network.airports import Airport
from logistics_strike.network.multimodal_graph import MultimodalGraph
from logistics_strike.network.ports import Port
from logistics_strike.network.rail import RailCorridor, RailTerminal
from logistics_strike.network.roads import RoadSegment, TruckDepot


@dataclass
class CongestionModel:
    """Computes and stores a congestion score (0=free-flow, 1=gridlock) per
    node id, and exposes an edge-level congestion figure blending both
    endpoints."""

    ports: Dict[str, Port]
    airports: Dict[str, Airport]
    rail_terminals: Dict[str, RailTerminal]
    rail_corridors: Dict[str, RailCorridor]
    truck_depots: Dict[str, TruckDepot]
    road_segments: Dict[str, RoadSegment]
    node_scores: Dict[str, float] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self.node_scores = {}

    def recompute(self) -> Dict[str, float]:
        scores: Dict[str, float] = {}
        for pid, p in self.ports.items():
            scores[pid] = p.queueing_score()
        for aid, a in self.airports.items():
            scores[aid] = a.congestion_score()
        for rid, r in self.rail_terminals.items():
            scores[rid] = r.congestion_score()
        for did, d in self.truck_depots.items():
            scores[did] = d.congestion_score()
        self.node_scores = scores
        return scores

    def rail_corridor_congestion(self) -> float:
        if not self.rail_corridors:
            return 0.0
        return sum(c.congestion_score() for c in self.rail_corridors.values()) / len(self.rail_corridors)

    def node_congestion(self, node_id: str) -> float:
        return self.node_scores.get(node_id, 0.2)  # mild default congestion for unmodelled nodes

    def edge_congestion(self, origin_id: str, destination_id: str, road_segment_id: str | None = None) -> float:
        """Blend origin/destination congestion (dwell-time risk at each end)
        with any explicit road-segment congestion (in-transit risk)."""
        o = self.node_congestion(origin_id)
        d = self.node_congestion(destination_id)
        endpoint = 0.5 * o + 0.5 * d
        if road_segment_id and road_segment_id in self.road_segments:
            segment = self.road_segments[road_segment_id].congestion_score()
            return max(0.0, min(1.0, 0.5 * endpoint + 0.5 * segment))
        return endpoint

    def apply_to_graph(self, graph: MultimodalGraph) -> None:
        for edge in graph.edges():
            score = self.edge_congestion(edge.origin, edge.destination)
            graph.update_edge_congestion(edge, score)

    def apply_capacity_shock(self, node_id: str, severity: float) -> None:
        """Used by the disruption engine: a port closure / strike raises
        congestion sharply at a node (severity in 0-1)."""
        current = self.node_scores.get(node_id, 0.2)
        self.node_scores[node_id] = max(0.0, min(1.0, current + severity * (1.0 - current)))
