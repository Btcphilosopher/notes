"""Fuel price engine.

Models marine (VLSFO), jet, diesel and electricity prices as mean-reverting
stochastic processes (Ornstein-Uhlenbeck), which is the standard, defensible
choice for commodity prices that oscillate around a slowly drifting
equilibrium rather than the pure random walk more appropriate to equities.
Prices only *propagate into* freight costs through the pricing engines
(spot/forward/strike) on the next pricing pass -- see module docstring in
``pricing/spot.py`` -- rather than being applied instantaneously to
in-flight contracts, matching requirement #13 (do not update freight prices
instantly without modelling contract and market response).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict

import numpy as np


class FuelType(str, Enum):
    MARINE_VLSFO = "MARINE_VLSFO"  # USD / tonne
    JET_FUEL = "JET_FUEL"  # USD / tonne
    DIESEL = "DIESEL"  # USD / litre
    ELECTRICITY = "ELECTRICITY"  # USD / kWh


@dataclass
class FuelProcessParams:
    long_run_mean: float
    mean_reversion_speed: float  # theta
    volatility: float  # sigma, annualised-ish but applied per step
    jump_intensity: float = 0.0  # probability of a jump per step
    jump_scale: float = 0.0  # relative size of a jump when it occurs


DEFAULT_FUEL_PARAMS: Dict[FuelType, FuelProcessParams] = {
    FuelType.MARINE_VLSFO: FuelProcessParams(long_run_mean=620.0, mean_reversion_speed=0.06, volatility=18.0, jump_intensity=0.01, jump_scale=0.18),
    FuelType.JET_FUEL: FuelProcessParams(long_run_mean=870.0, mean_reversion_speed=0.05, volatility=22.0, jump_intensity=0.01, jump_scale=0.15),
    FuelType.DIESEL: FuelProcessParams(long_run_mean=1.05, mean_reversion_speed=0.04, volatility=0.03, jump_intensity=0.008, jump_scale=0.12),
    FuelType.ELECTRICITY: FuelProcessParams(long_run_mean=0.14, mean_reversion_speed=0.03, volatility=0.006, jump_intensity=0.005, jump_scale=0.20),
}


@dataclass
class FuelPriceEngine:
    """Ornstein-Uhlenbeck + Poisson-jump price process for each fuel type."""

    params: Dict[FuelType, FuelProcessParams] = field(default_factory=lambda: dict(DEFAULT_FUEL_PARAMS))
    prices: Dict[FuelType, float] = field(default_factory=dict)
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng(7))
    history: Dict[FuelType, list] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for ft, p in self.params.items():
            self.prices.setdefault(ft, p.long_run_mean)
            self.history.setdefault(ft, [self.prices[ft]])

    def step(self, dt_days: float = 1.0) -> Dict[FuelType, float]:
        dt = dt_days / 365.0
        for ft, p in self.params.items():
            x = self.prices[ft]
            drift = p.mean_reversion_speed * (p.long_run_mean - x) * dt
            shock = p.volatility * np.sqrt(dt) * self.rng.standard_normal()
            jump = 0.0
            if self.rng.random() < p.jump_intensity * dt_days:
                direction = 1 if self.rng.random() < 0.5 else -1
                jump = direction * p.jump_scale * x
            new_price = max(0.01, x + drift + shock + jump)
            self.prices[ft] = new_price
            self.history[ft].append(new_price)
        return dict(self.prices)

    def apply_shock(self, fuel_type: FuelType, relative_change: float) -> None:
        """Used by the scenario engine, e.g. FUEL +50%."""
        self.prices[fuel_type] *= 1.0 + relative_change
        self.history[fuel_type].append(self.prices[fuel_type])

    def price(self, fuel_type: FuelType) -> float:
        return self.prices[fuel_type]

    def index(self, fuel_type: FuelType) -> float:
        """Current price relative to long-run mean; 1.0 = at equilibrium."""
        p = self.params[fuel_type]
        return self.prices[fuel_type] / p.long_run_mean
