"""Monte Carlo engine.

Simulates thousands of future logistics states for a single corridor
decision (rather than thousands of full discrete-event runs of the whole
platform, which would be prohibitively slow) by drawing vectorised samples
of the stochastic drivers already modelled elsewhere -- future spot
(lognormal around the forward curve's expected spot, per
``pricing/strike.py``'s own assumption), transit time
(:class:`~logistics_strike.risk.delay.DelayModel`), and capacity scarcity --
and reports P5/P10/P50/P90/P95/P99 for each key variable plus buyer/seller
profit-and-loss under a candidate strike.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np

from logistics_strike.pricing.forward import ForwardPoint
from logistics_strike.risk.delay import DelayModel

PERCENTILES = [5, 10, 50, 90, 95, 99]


@dataclass
class PercentileSet:
    values: Dict[int, float]

    def __getitem__(self, p: int) -> float:
        return self.values[p]

    def as_dict(self) -> Dict[str, float]:
        return {f"P{p}": round(v, 2) for p, v in self.values.items()}


def _percentiles(samples: np.ndarray) -> PercentileSet:
    return PercentileSet({p: float(np.percentile(samples, p)) for p in PERCENTILES})


@dataclass
class MonteCarloResult:
    corridor_id: str
    n_simulations: int
    future_spot: PercentileSet
    transit_days: PercentileSet
    delay_days: PercentileSet
    reliability: float  # fraction of simulations delivered within the deadline
    capacity_scarcity: PercentileSet
    buyer_pnl: PercentileSet
    seller_pnl: PercentileSet

    def summary(self) -> Dict:
        return {
            "corridor_id": self.corridor_id,
            "n_simulations": self.n_simulations,
            "future_spot": self.future_spot.as_dict(),
            "transit_days": self.transit_days.as_dict(),
            "delay_days": self.delay_days.as_dict(),
            "reliability": round(self.reliability, 4),
            "capacity_scarcity": self.capacity_scarcity.as_dict(),
            "buyer_pnl": self.buyer_pnl.as_dict(),
            "seller_pnl": self.seller_pnl.as_dict(),
        }


@dataclass
class MonteCarloEngine:
    seed: int = 2026

    def simulate(
        self,
        corridor_id: str,
        forward_point: ForwardPoint,
        strike_price: float,
        expected_transit_days: float,
        transit_std_days: float,
        deadline_days: float,
        volume_units: float,
        capacity_scarcity_forecast: float,
        capacity_scarcity_std: float = 0.15,
        n_simulations: int = 5_000,
    ) -> MonteCarloResult:
        rng = np.random.default_rng(self.seed)

        # future spot: lognormal so it can never go negative, calibrated to
        # match the forward curve's expected value and horizon volatility.
        t_years = forward_point.horizon_days / 365.0
        sigma = max(1e-6, forward_point.volatility_annualised * t_years ** 0.5)
        mu = np.log(max(forward_point.expected_spot, 1e-6)) - 0.5 * sigma ** 2
        future_spot = rng.lognormal(mu, sigma, size=n_simulations)

        delay_model = DelayModel(expected_transit_days, transit_std_days)
        transit_days = delay_model.sample(n_simulations, seed=self.seed + 1)
        delay_days = np.clip(transit_days - deadline_days, 0, None)
        on_time = transit_days <= deadline_days

        scarcity = np.clip(
            rng.normal(capacity_scarcity_forecast, capacity_scarcity_std, size=n_simulations), 0.0, 1.0
        )

        buyer_pnl = (future_spot - strike_price) * volume_units
        seller_pnl = -buyer_pnl

        return MonteCarloResult(
            corridor_id=corridor_id,
            n_simulations=n_simulations,
            future_spot=_percentiles(future_spot),
            transit_days=_percentiles(transit_days),
            delay_days=_percentiles(delay_days),
            reliability=float(np.mean(on_time)),
            capacity_scarcity=_percentiles(scarcity),
            buyer_pnl=_percentiles(buyer_pnl),
            seller_pnl=_percentiles(seller_pnl),
        )
