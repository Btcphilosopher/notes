"""Default world builder.

Assembles a ready-to-run :class:`~logistics_strike.core.engine.Engine`
using the starter network/carrier data in ``network/*`` and ``carriers/*``:
a handful of major ports, airports, rail terminals and road segments,
connected by representative sea/air/rail/road legs, with a shipping line,
an airline, a rail operator and a trucking company supplying capacity, and
a small population of shipper/carrier/trader/broker agents.

This is the "hello world" of the platform -- enough of a network to
demonstrate every subsystem end-to-end -- not an attempt at a complete
global freight network. Extend ``network/*`` with more nodes/edges and
this builder keeps working unchanged.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List

from logistics_strike.agents.brokers import BrokerAgent
from logistics_strike.agents.carriers import make_carrier_agents
from logistics_strike.agents.demand import DemandEngine, DemandLane
from logistics_strike.agents.shippers import DEFAULT_SHIPPERS
from logistics_strike.agents.traders import TraderAgent
from logistics_strike.cargo.cargo import CargoType
from logistics_strike.carriers.airlines import DEFAULT_AIRLINES
from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit
from logistics_strike.carriers.rail_operators import DEFAULT_RAIL_OPERATORS
from logistics_strike.carriers.shipping import DEFAULT_SHIPPING_LINES
from logistics_strike.carriers.trucking import DEFAULT_TRUCKING_COMPANIES
from logistics_strike.contracts.settlement import SettlementEngine
from logistics_strike.core.clock import SimClock
from logistics_strike.core.engine import Engine
from logistics_strike.network.airports import DEFAULT_AIRPORTS
from logistics_strike.network.multimodal_graph import Edge, MultimodalGraph
from logistics_strike.network.ports import DEFAULT_PORTS
from logistics_strike.network.rail import DEFAULT_RAIL_CORRIDORS, DEFAULT_RAIL_TERMINALS
from logistics_strike.network.roads import DEFAULT_ROAD_SEGMENTS, DEFAULT_TRUCK_DEPOTS
from logistics_strike.core.state import TransportMode
from logistics_strike.markets.matching import MatchingEngine
from logistics_strike.markets.order_book import OrderBook
from logistics_strike.pricing.congestion import CongestionModel
from logistics_strike.pricing.forward import ForwardCurveEngine
from logistics_strike.pricing.fuel import FuelPriceEngine
from logistics_strike.pricing.spot import SpotPriceEngine
from logistics_strike.pricing.strike import StrikeEngine
from logistics_strike.risk.disruption import DisruptionEngine
from logistics_strike.risk.geopolitical import GeopoliticalRiskEngine
from logistics_strike.risk.weather import WeatherEngine
from logistics_strike.routing.route_engine import RouteEngine

# representative sea lanes: (origin, destination, distance_km, days, capacity_teu/wk, cost/teu, reliability)
SEA_LANES = [
    ("CNSHA", "NLRTM", 19_000, 29.0, 3.5, 4200, 2400, 0.90),
    ("CNSHA", "USLAX", 10_500, 16.0, 2.5, 3600, 2700, 0.88),
    ("SGSIN", "NLRTM", 15_800, 24.0, 3.0, 3800, 2100, 0.91),
    ("NLRTM", "USNYC", 6_200, 9.0, 1.5, 2400, 1900, 0.92),
    ("AEJEA", "NLRTM", 11_200, 17.0, 2.5, 3200, 1700, 0.87),
    ("CNNGB", "USLAX", 10_800, 17.0, 2.2, 3700, 2600, 0.87),
]

AIR_LANES = [
    ("CNPVG", "NLAMS", 8_900, 1.3, 0.3, 700, 5800, 0.94),
    ("HKHKG", "USMEM", 13_000, 1.8, 0.3, 900, 6900, 0.93),
    ("AEDXB", "DEFRA", 4_800, 0.9, 0.2, 500, 4100, 0.95),
]

RAIL_LANES = [
    ("CNZHY", "PLMLA", 9_800, 16.0, 2.0, 900, 3100, 0.83),
    ("PLMLA", "DEDUI", 1_100, 2.0, 0.5, 1200, 900, 0.90),
]

ROAD_LANES = [
    ("NLDEP1", "DEDEP1", 220, 0.6, 0.2, 3000, 650, 0.95),
    ("USDEP1", "USLAX", 35, 0.2, 0.1, 5000, 180, 0.97),
]


def _build_graph() -> MultimodalGraph:
    graph = MultimodalGraph()
    for port in DEFAULT_PORTS:
        graph.add_node(port.to_node())
    for airport in DEFAULT_AIRPORTS:
        graph.add_node(airport.to_node())
    for terminal in DEFAULT_RAIL_TERMINALS:
        graph.add_node(terminal.to_node())
    for depot in DEFAULT_TRUCK_DEPOTS:
        graph.add_node(depot.to_node())

    for origin, dest, dist, days, days_std, cap, cost, rel in SEA_LANES:
        graph.add_edge(Edge(origin, dest, TransportMode.SEA, dist, days, days_std, cap, cost, rel, fuel_share=0.55, risk_score=0.1, service_name="OCEANIC"))
    for origin, dest, dist, days, days_std, cap, cost, rel in AIR_LANES:
        graph.add_edge(Edge(origin, dest, TransportMode.AIR, dist, days, days_std, cap, cost, rel, fuel_share=0.45, risk_score=0.08, service_name="SKYFREIGHT"))
    for origin, dest, dist, days, days_std, cap, cost, rel in RAIL_LANES:
        graph.add_edge(Edge(origin, dest, TransportMode.RAIL, dist, days, days_std, cap, cost, rel, fuel_share=0.25, risk_score=0.15, service_name="EURASIA_RAIL"))
    for origin, dest, dist, days, days_std, cap, cost, rel in ROAD_LANES:
        graph.add_edge(Edge(origin, dest, TransportMode.ROAD, dist, days, days_std, cap, cost, rel, fuel_share=0.35, risk_score=0.05, service_name="CONTINENTAL"))

    return graph


def _build_capacity_pools(graph: MultimodalGraph) -> Dict[str, CapacityPool]:
    pools: Dict[str, CapacityPool] = {}
    for edge in graph.edges():
        unit = {
            TransportMode.SEA: CapacityUnit.TEU,
            TransportMode.AIR: CapacityUnit.KG,
            TransportMode.RAIL: CapacityUnit.TONNES,
            TransportMode.ROAD: CapacityUnit.PALLETS,
        }.get(edge.mode, CapacityUnit.TEU)
        pools[edge.key] = CapacityPool(
            id=edge.key,
            mode=edge.mode.value,
            unit=unit,
            total_capacity=edge.capacity_per_week,
            marginal_cost_per_unit=edge.base_cost_per_unit * 0.75,
            revenue_potential_per_unit=edge.base_cost_per_unit,
        )
    return pools


def _build_demand_engine() -> DemandEngine:
    lanes = [
        DemandLane("CNSHA", "NLRTM", TransportMode.SEA, base_shipments_per_day=1.4, cargo_mix={CargoType.CONTAINER_40FT: 0.55, CargoType.CONTAINER_20FT: 0.25, CargoType.REEFER: 0.10, CargoType.HIGH_VALUE: 0.10}),
        DemandLane("CNSHA", "USLAX", TransportMode.SEA, base_shipments_per_day=1.2, cargo_mix={CargoType.CONTAINER_40FT: 0.6, CargoType.CONTAINER_20FT: 0.2, CargoType.BULK: 0.2}),
        DemandLane("SGSIN", "NLRTM", TransportMode.SEA, base_shipments_per_day=0.6, cargo_mix={CargoType.CONTAINER_40FT: 0.5, CargoType.LCL: 0.3, CargoType.CONTAINER_20FT: 0.2}),
        DemandLane("CNPVG", "NLAMS", TransportMode.AIR, base_shipments_per_day=0.5, cargo_mix={CargoType.HIGH_VALUE: 0.5, CargoType.PARCEL: 0.4, CargoType.PALLET: 0.1}),
    ]
    return DemandEngine(lanes=lanes)


def build_default_world(start: datetime | None = None) -> Engine:
    start = start or datetime(2026, 1, 1)
    graph = _build_graph()
    capacity_pools = _build_capacity_pools(graph)

    congestion_model = CongestionModel(
        ports={p.id: p for p in DEFAULT_PORTS},
        airports={a.id: a for a in DEFAULT_AIRPORTS},
        rail_terminals={r.id: r for r in DEFAULT_RAIL_TERMINALS},
        rail_corridors={c.id: c for c in DEFAULT_RAIL_CORRIDORS},
        truck_depots={d.id: d for d in DEFAULT_TRUCK_DEPOTS},
        road_segments={r.id: r for r in DEFAULT_ROAD_SEGMENTS},
    )
    congestion_model.recompute()

    fuel_engine = FuelPriceEngine()
    weather_engine = WeatherEngine()
    geo_engine = GeopoliticalRiskEngine()
    disruption_engine = DisruptionEngine()
    demand_engine = _build_demand_engine()
    route_engine = RouteEngine(graph=graph, spot_engine=SpotPriceEngine(fuel_engine=fuel_engine))
    spot_engine = route_engine.spot_engine
    forward_engine = ForwardCurveEngine()
    strike_engine = StrikeEngine()
    order_book = OrderBook()
    matching_engine = MatchingEngine()
    settlement_engine = SettlementEngine()

    carrier_agents = make_carrier_agents(list(capacity_pools.values())[:12])
    brokers = [BrokerAgent("BROKER_ATLAS", "Atlas Freight Brokerage")]
    traders = [TraderAgent("TRADER_MERIDIAN", "Meridian Capital Freight Desk", forecast_bias=0.01)]

    tracked_lanes = [
        ("CNSHA", "NLRTM", TransportMode.SEA),
        ("CNSHA", "USLAX", TransportMode.SEA),
        ("SGSIN", "NLRTM", TransportMode.SEA),
        ("CNPVG", "NLAMS", TransportMode.AIR),
    ]

    engine = Engine(
        clock=SimClock(start=start, step_size=timedelta(days=1)),
        graph=graph,
        congestion_model=congestion_model,
        fuel_engine=fuel_engine,
        weather_engine=weather_engine,
        geo_engine=geo_engine,
        disruption_engine=disruption_engine,
        demand_engine=demand_engine,
        route_engine=route_engine,
        spot_engine=spot_engine,
        forward_engine=forward_engine,
        strike_engine=strike_engine,
        order_book=order_book,
        matching_engine=matching_engine,
        settlement_engine=settlement_engine,
        capacity_pools=capacity_pools,
        shippers=list(DEFAULT_SHIPPERS),
        carrier_agents=carrier_agents,
        brokers=brokers,
        traders=traders,
        tracked_lanes=tracked_lanes,
    )
    return engine
