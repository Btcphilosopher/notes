"""Scenario engine.

Applies a named, parameterised shock to a freshly-built world at step 0
(port closure, +50% fuel, +30% demand, -20% capacity, peak season, canal
closure, ...) and compares the resulting trajectory against an unperturbed
baseline run of the same world, so the platform can answer "what would
Suez closing do to the Asia-Europe strike price?" concretely.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Callable, Dict, List, Optional

from logistics_strike.core.engine import Engine
from logistics_strike.pricing.fuel import FuelType
from logistics_strike.risk.disruption import DisruptionEngine
from logistics_strike.simulation.world import build_default_world


class ScenarioType(str, Enum):
    PORT_CLOSURE = "PORT_CLOSURE"
    FUEL_SHOCK = "FUEL_SHOCK"
    DEMAND_SURGE = "DEMAND_SURGE"
    CAPACITY_CUT = "CAPACITY_CUT"
    AIR_FREIGHT_DISRUPTION = "AIR_FREIGHT_DISRUPTION"
    RAIL_INTERRUPTION = "RAIL_INTERRUPTION"
    GLOBAL_RECESSION = "GLOBAL_RECESSION"
    PEAK_SEASON = "PEAK_SEASON"
    CANAL_CLOSURE = "CANAL_CLOSURE"


@dataclass
class ScenarioDefinition:
    id: str
    scenario_type: ScenarioType
    description: str
    apply: Callable[[Engine], None]


def _apply_port_closure(engine: Engine, port_id: str = "CNSHA", severity: float = 0.85, duration_steps: int = 14) -> None:
    engine.disruption_engine.trigger(DisruptionEngine.port_closure(port_id, start_step=1, duration_steps=duration_steps, severity=severity))


def _apply_fuel_shock(engine: Engine, fuel_type: FuelType = FuelType.MARINE_VLSFO, pct_change: float = 0.5) -> None:
    engine.disruption_engine.trigger(DisruptionEngine.fuel_shock(fuel_type, start_step=1, pct_change=pct_change, duration_steps=1))


def _apply_demand_surge(engine: Engine, multiplier: float = 1.3) -> None:
    for lane in engine.demand_engine.lanes:
        lane.base_shipments_per_day *= multiplier


def _apply_capacity_cut(engine: Engine, fraction: float = 0.2) -> None:
    for pool in engine.capacity_pools.values():
        pool.base_capacity *= (1.0 - fraction)
        pool.total_capacity = pool.base_capacity


def _apply_air_freight_disruption(engine: Engine, airport_id: str = "CNPVG", severity: float = 0.7, duration_steps: int = 10) -> None:
    engine.disruption_engine.trigger(DisruptionEngine.port_strike(airport_id, start_step=1, duration_steps=duration_steps, severity=severity))


def _apply_rail_interruption(engine: Engine, edge_key_substring: str = "CNZHY->PLMLA", severity: float = 0.75, duration_steps: int = 14) -> None:
    matching = [e for e in engine.graph.edges() if edge_key_substring in e.key]
    for e in matching:
        engine.disruption_engine.trigger(
            DisruptionEngine.canal_disruption(e.key, start_step=1, duration_steps=duration_steps, severity=severity)
        )


def _apply_global_recession(engine: Engine, demand_multiplier: float = 0.65) -> None:
    for lane in engine.demand_engine.lanes:
        lane.base_shipments_per_day *= demand_multiplier
        lane.growth_per_year = -0.03


def _apply_peak_season(engine: Engine, multiplier: float = 1.6) -> None:
    for lane in engine.demand_engine.lanes:
        lane.seasonal_multiplier = max(lane.seasonal_multiplier, multiplier)
        lane.seasonal_peak_months = tuple(range(1, 13))  # force "peak" for the whole run


def _apply_canal_closure(engine: Engine, edge_key_substring: str = "CNSHA->NLRTM", severity: float = 0.9, duration_steps: int = 21) -> None:
    matching = [e for e in engine.graph.edges() if edge_key_substring in e.key and e.mode.value == "SEA"]
    for e in matching:
        engine.disruption_engine.trigger(
            DisruptionEngine.canal_disruption(e.key, start_step=1, duration_steps=duration_steps, severity=severity)
        )


STANDARD_SCENARIOS: Dict[str, ScenarioDefinition] = {
    d.id: d
    for d in [
        ScenarioDefinition("PORT_CLOSURE", ScenarioType.PORT_CLOSURE, "Major origin port closes for two weeks", _apply_port_closure),
        ScenarioDefinition("FUEL_PLUS_50", ScenarioType.FUEL_SHOCK, "Marine fuel price shocks +50%", lambda e: _apply_fuel_shock(e, FuelType.MARINE_VLSFO, 0.5)),
        ScenarioDefinition("DEMAND_PLUS_30", ScenarioType.DEMAND_SURGE, "Freight demand surges +30%", lambda e: _apply_demand_surge(e, 1.3)),
        ScenarioDefinition("CAPACITY_MINUS_20", ScenarioType.CAPACITY_CUT, "Carrier capacity withdrawn -20%", lambda e: _apply_capacity_cut(e, 0.2)),
        ScenarioDefinition("AIR_FREIGHT_DISRUPTION", ScenarioType.AIR_FREIGHT_DISRUPTION, "Major air cargo hub disrupted", _apply_air_freight_disruption),
        ScenarioDefinition("RAIL_INTERRUPTION", ScenarioType.RAIL_INTERRUPTION, "Eurasian rail corridor interrupted", _apply_rail_interruption),
        ScenarioDefinition("GLOBAL_RECESSION", ScenarioType.GLOBAL_RECESSION, "Global demand contraction", _apply_global_recession),
        ScenarioDefinition("PEAK_SEASON", ScenarioType.PEAK_SEASON, "Peak-season demand loading", _apply_peak_season),
        ScenarioDefinition("CANAL_CLOSURE", ScenarioType.CANAL_CLOSURE, "Key canal chokepoint closed", _apply_canal_closure),
    ]
}


@dataclass
class ScenarioComparison:
    scenario_id: str
    baseline_history: List[Dict]
    scenario_history: List[Dict]

    def _avg(self, history: List[Dict], field_path: Callable[[Dict], Optional[float]]) -> Optional[float]:
        values = [v for v in (field_path(h) for h in history) if v is not None]
        return sum(values) / len(values) if values else None

    def spot_delta(self, corridor_key: str) -> Optional[float]:
        base = self._avg(self.baseline_history, lambda h: h["spot_prices"].get(corridor_key))
        scen = self._avg(self.scenario_history, lambda h: h["spot_prices"].get(corridor_key))
        if base is None or scen is None:
            return None
        return scen - base

    def strike_delta(self, corridor_key: str) -> Optional[float]:
        base = self._avg(self.baseline_history, lambda h: h["strike_prices"].get(corridor_key))
        scen = self._avg(self.scenario_history, lambda h: h["strike_prices"].get(corridor_key))
        if base is None or scen is None:
            return None
        return scen - base

    def summary(self) -> Dict[str, Dict[str, Optional[float]]]:
        keys = set()
        for h in self.baseline_history + self.scenario_history:
            keys.update(h["spot_prices"].keys())
        return {
            k: {"spot_delta": self.spot_delta(k), "strike_delta": self.strike_delta(k)}
            for k in keys
        }


@dataclass
class ScenarioEngine:
    def run_comparison(
        self,
        scenario_id: str,
        n_steps: int = 30,
        start: Optional[datetime] = None,
    ) -> ScenarioComparison:
        if scenario_id not in STANDARD_SCENARIOS:
            raise KeyError(f"Unknown scenario '{scenario_id}'. Known: {list(STANDARD_SCENARIOS)}")
        definition = STANDARD_SCENARIOS[scenario_id]

        baseline_engine = build_default_world(start=start)
        scenario_engine = build_default_world(start=start)
        definition.apply(scenario_engine)

        baseline_history = [baseline_engine.step() for _ in range(n_steps)]
        scenario_history = [scenario_engine.step() for _ in range(n_steps)]

        return ScenarioComparison(scenario_id=scenario_id, baseline_history=baseline_history, scenario_history=scenario_history)
