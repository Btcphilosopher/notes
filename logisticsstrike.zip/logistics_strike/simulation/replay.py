"""Simulation recording and replay.

Wraps the metrics history the engine already accumulates
(``engine.state.metrics_history``) and the event bus's event log into a
single serialisable recording, and provides a cursor-based replay so a
recorded run can be stepped through after the fact -- for debugging,
analytics dashboards, or feeding a UI timeline -- without re-running the
simulation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from logistics_strike.core.engine import Engine
from logistics_strike.core.events import Event


@dataclass
class Recording:
    metrics_history: List[Dict]
    events: List[Dict]

    def to_json(self) -> str:
        return json.dumps({"metrics_history": self.metrics_history, "events": self.events}, default=str, indent=2)

    @classmethod
    def from_json(cls, text: str) -> "Recording":
        data = json.loads(text)
        return cls(metrics_history=data["metrics_history"], events=data["events"])

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            f.write(self.to_json())

    @classmethod
    def load(cls, path: str) -> "Recording":
        with open(path) as f:
            return cls.from_json(f.read())


def _event_to_dict(event: Event) -> Dict:
    return {
        "type": event.type.value,
        "timestamp": event.timestamp.isoformat(),
        "source": event.source,
        "payload_repr": repr(event.payload)[:500],
    }


def record(engine: Engine) -> Recording:
    """Snapshot everything recorded so far by ``engine`` into a ``Recording``."""
    events = [_event_to_dict(e) for e in engine.event_bus.history()]
    return Recording(metrics_history=list(engine.state.metrics_history), events=events)


@dataclass
class ReplayCursor:
    recording: Recording
    index: int = 0

    def has_next(self) -> bool:
        return self.index < len(self.recording.metrics_history)

    def next(self) -> Optional[Dict]:
        if not self.has_next():
            return None
        snapshot = self.recording.metrics_history[self.index]
        self.index += 1
        return snapshot

    def seek(self, step: int) -> Optional[Dict]:
        for i, snap in enumerate(self.recording.metrics_history):
            if snap.get("step") == step:
                self.index = i + 1
                return snap
        return None

    def reset(self) -> None:
        self.index = 0

    def events_between(self, start_step: int, end_step: int) -> List[Dict]:
        # events don't carry a step index directly; approximate using the
        # metrics history's timestamps as step boundaries.
        history = self.recording.metrics_history
        if not history:
            return []
        start_ts = next((h["timestamp"] for h in history if h["step"] == start_step), None)
        end_ts = next((h["timestamp"] for h in history if h["step"] == end_step), None)
        if start_ts is None or end_ts is None:
            return []
        return [e for e in self.recording.events if start_ts <= e["timestamp"] <= end_ts]
