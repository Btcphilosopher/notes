"""Multimodal path enumeration helpers.

Groups the raw candidate paths produced by
:class:`~logistics_strike.routing.route_engine.RouteEngine` by their mode
sequence (e.g. SEA, SEA->RAIL->ROAD, AIR->ROAD) so callers can compare
"sea only" vs "sea+rail+road" vs "air+road" strategies directly, matching
requirement #14's worked example.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List

from logistics_strike.routing.route_engine import RouteCandidate


def mode_sequence(candidate: RouteCandidate) -> str:
    seq: List[str] = []
    for m in candidate.modes:
        if not seq or seq[-1] != m:
            seq.append(m)
    return "->".join(seq)


def group_by_mode_sequence(candidates: List[RouteCandidate]) -> Dict[str, List[RouteCandidate]]:
    groups: Dict[str, List[RouteCandidate]] = defaultdict(list)
    for c in candidates:
        groups[mode_sequence(c)].append(c)
    return dict(groups)


def best_per_mode_sequence(candidates: List[RouteCandidate]) -> Dict[str, RouteCandidate]:
    """The cheapest candidate for each distinct mode-sequence strategy, so
    e.g. SEA->RAIL->ROAD can be compared head-to-head against AIR->ROAD."""
    groups = group_by_mode_sequence(candidates)
    return {seq: min(cands, key=lambda c: c.spot.price) for seq, cands in groups.items()}
