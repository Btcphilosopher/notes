"""Route-level capacity feasibility checks.

A priced route is not necessarily bookable -- every leg's capacity pool must
have room for the shipment's cargo. This module checks and (optionally)
reserves capacity across a whole multi-leg route atomically: either every
leg gets its allocation or none do, so a route never ends up half-booked.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from logistics_strike.cargo.shipments import Shipment
from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.network.multimodal_graph import Edge


@dataclass
class CapacityCheckResult:
    feasible: bool
    constrained_legs: List[str]


def check_route_capacity(
    route: List[Edge],
    shipment: Shipment,
    capacity_pools: Dict[str, CapacityPool],
) -> CapacityCheckResult:
    constrained = []
    required_units = shipment.cargo.teu_equivalent()
    for edge in route:
        pool = capacity_pools.get(edge.key)
        if pool is None:
            continue  # unmodelled pool: assume open capacity
        if pool.available() < required_units:
            constrained.append(edge.key)
    return CapacityCheckResult(feasible=len(constrained) == 0, constrained_legs=constrained)


def reserve_route_capacity(
    route: List[Edge],
    shipment: Shipment,
    capacity_pools: Dict[str, CapacityPool],
) -> bool:
    """Atomically reserve capacity for every leg of ``route``. Rolls back all
    partial allocations if any leg cannot be reserved."""
    required_units = shipment.cargo.teu_equivalent()
    reserved: List[CapacityPool] = []
    for edge in route:
        pool = capacity_pools.get(edge.key)
        if pool is None:
            continue
        if pool.allocate(required_units):
            reserved.append(pool)
        else:
            for p in reserved:
                p.release(required_units)
            return False
    return True
