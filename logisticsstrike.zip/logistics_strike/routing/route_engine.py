"""Route engine: multi-criteria path search over the multimodal graph.

For a given shipment, enumerates candidate paths (see
:mod:`logistics_strike.routing.multimodal` for the mode-combination
enumeration), prices each one (spot cost, expected cost, reliability) and
returns a ranked list. Deliberately does *not* assume the cheapest route is
always optimal (requirement #15) -- ranking is driven by a configurable,
weighted multi-objective score computed in
:mod:`logistics_strike.routing.optimisation`.
"""

from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from logistics_strike.cargo.constraints import is_feasible
from logistics_strike.cargo.shipments import Shipment
from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.network.multimodal_graph import Edge, MultimodalGraph
from logistics_strike.pricing.spot import SpotPriceEngine, SpotPriceResult


@dataclass
class RouteCandidate:
    edges: List[Edge]
    spot: SpotPriceResult

    @property
    def path_ids(self) -> List[str]:
        ids = [self.edges[0].origin]
        ids.extend(e.destination for e in self.edges)
        return ids

    @property
    def modes(self) -> List[str]:
        return [e.mode.value for e in self.edges]

    def __repr__(self) -> str:  # pragma: no cover
        return f"RouteCandidate({'->'.join(self.path_ids)}, modes={self.modes}, spot={self.spot.price})"


@dataclass
class RouteEngine:
    graph: MultimodalGraph
    spot_engine: SpotPriceEngine
    max_paths: int = 8
    max_hops: int = 5

    def find_candidate_paths(self, origin_id: str, destination_id: str) -> List[List[Edge]]:
        """K-shortest-ish enumeration by (cost, time) using a bounded DFS with
        a priority frontier -- adequate for the sparse, hub-oriented graphs
        this platform builds (tens to low hundreds of nodes), and keeps every
        path inspectable rather than relying on an opaque library call."""
        results: List[Tuple[float, List[Edge]]] = []
        # priority = (cost, insertion order) -- the tie-breaker counter keeps
        # heapq from ever falling through to comparing paths/edges, which
        # have no defined ordering.
        counter = itertools.count()
        frontier: List[Tuple[float, int, str, List[Edge], set]] = [
            (0.0, next(counter), origin_id, [], {origin_id})
        ]
        while frontier and len(results) < self.max_paths * 4:
            cost, _, node_id, path, visited = heapq.heappop(frontier)
            if node_id == destination_id and path:
                results.append((cost, path))
                continue
            if len(path) >= self.max_hops:
                continue
            for edge in self.graph.out_edges(node_id):
                if edge.destination in visited:
                    continue
                new_cost = cost + edge.base_cost_per_unit + edge.base_transit_days * 50
                heapq.heappush(
                    frontier,
                    (new_cost, next(counter), edge.destination, path + [edge], visited | {edge.destination}),
                )
        results.sort(key=lambda t: t[0])
        return [p for _, p in results[: self.max_paths]]

    def price_candidates(
        self,
        shipment: Shipment,
        capacity_pools: Optional[Dict[str, CapacityPool]] = None,
    ) -> List[RouteCandidate]:
        candidates: List[RouteCandidate] = []
        for path in self.find_candidate_paths(shipment.origin_id, shipment.destination_id):
            if not all(is_feasible(shipment.cargo, e.mode) for e in path):
                continue
            spot = self.spot_engine.compute_spot(shipment, path, capacity_pools)
            candidates.append(RouteCandidate(edges=path, spot=spot))
        return candidates
