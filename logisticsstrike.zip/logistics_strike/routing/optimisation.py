"""Route scoring and multi-objective optimisation.

Deliberately does not assume the cheapest route wins (requirement #15):
:func:`score_routes` normalises cost, time, reliability, risk and (when
enabled) carbon across the candidate set and combines them with
user-supplied weights. :class:`MultiObjectiveOptimiser` additionally
supports pure Pareto-front extraction and the platform-wide objective
vocabulary from requirement #32 (minimum cost / time / risk, maximum
reliability / capacity utilisation).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from logistics_strike.routing.route_engine import RouteCandidate


class Objective(str, Enum):
    MINIMUM_COST = "MINIMUM_COST"
    MINIMUM_TIME = "MINIMUM_TIME"
    MAXIMUM_RELIABILITY = "MAXIMUM_RELIABILITY"
    MINIMUM_RISK = "MINIMUM_RISK"
    MAXIMUM_CAPACITY_UTILISATION = "MAXIMUM_CAPACITY_UTILISATION"


@dataclass
class RouteObjectiveWeights:
    cost: float = 0.35
    time: float = 0.25
    reliability: float = 0.25
    risk: float = 0.10
    carbon: float = 0.05

    def normalised(self) -> "RouteObjectiveWeights":
        total = self.cost + self.time + self.reliability + self.risk + self.carbon
        if total <= 0:
            return RouteObjectiveWeights(0.2, 0.2, 0.2, 0.2, 0.2)
        return RouteObjectiveWeights(
            self.cost / total, self.time / total, self.reliability / total, self.risk / total, self.carbon / total
        )


@dataclass
class ScoredRoute:
    candidate: RouteCandidate
    score: float
    breakdown: Dict[str, float]


def _route_risk(candidate: RouteCandidate) -> float:
    if not candidate.edges:
        return 0.0
    return sum(e.risk_score for e in candidate.edges) / len(candidate.edges)


def _route_carbon_proxy(candidate: RouteCandidate) -> float:
    """Simple carbon proxy: SEA is cheapest per tonne-km, AIR by far the
    highest, ROAD/RAIL in between -- used only when carbon weighting is
    enabled."""
    factors = {"SEA": 1.0, "RAIL": 1.4, "ROAD": 3.0, "AIR": 12.0, "MULTIMODAL": 2.5}
    return sum(factors.get(e.mode.value, 2.0) * e.distance_km for e in candidate.edges)


def score_routes(
    candidates: List[RouteCandidate],
    weights: Optional[RouteObjectiveWeights] = None,
    enable_carbon: bool = False,
) -> List[ScoredRoute]:
    if not candidates:
        return []
    weights = (weights or RouteObjectiveWeights()).normalised()

    costs = [c.spot.price for c in candidates]
    times = [c.spot.expected_transit_days for c in candidates]
    reliabilities = [c.spot.reliability for c in candidates]
    risks = [_route_risk(c) for c in candidates]
    carbons = [_route_carbon_proxy(c) for c in candidates] if enable_carbon else [0.0] * len(candidates)

    def norm(values: List[float], invert: bool = False) -> List[float]:
        lo, hi = min(values), max(values)
        if hi - lo < 1e-9:
            return [0.5 for _ in values]
        n = [(v - lo) / (hi - lo) for v in values]
        return [1.0 - x for x in n] if invert else n

    cost_n = norm(costs)  # lower is better -> already 0=best after norm (no invert needed, since best=lowest gets 0)
    time_n = norm(times)
    risk_n = norm(risks)
    carbon_n = norm(carbons)
    reliability_n = norm(reliabilities, invert=True)  # higher reliability is better -> invert so 0=best

    scored: List[ScoredRoute] = []
    for i, c in enumerate(candidates):
        # lower combined score = better route
        combined = (
            weights.cost * cost_n[i]
            + weights.time * time_n[i]
            + weights.reliability * reliability_n[i]
            + weights.risk * risk_n[i]
            + weights.carbon * carbon_n[i]
        )
        scored.append(
            ScoredRoute(
                candidate=c,
                score=combined,
                breakdown={
                    "cost": costs[i],
                    "time_days": times[i],
                    "reliability": reliabilities[i],
                    "risk": risks[i],
                    "carbon_proxy": carbons[i],
                    "normalised_score": combined,
                },
            )
        )
    scored.sort(key=lambda s: s.score)
    return scored


@dataclass
class MultiObjectiveOptimiser:
    """Pareto-front extraction plus single-objective convenience selectors
    covering requirement #32's objective vocabulary."""

    def pareto_front(self, candidates: List[RouteCandidate]) -> List[RouteCandidate]:
        front = []
        for c in candidates:
            dominated = False
            for other in candidates:
                if other is c:
                    continue
                if (
                    other.spot.price <= c.spot.price
                    and other.spot.expected_transit_days <= c.spot.expected_transit_days
                    and other.spot.reliability >= c.spot.reliability
                    and (
                        other.spot.price < c.spot.price
                        or other.spot.expected_transit_days < c.spot.expected_transit_days
                        or other.spot.reliability > c.spot.reliability
                    )
                ):
                    dominated = True
                    break
            if not dominated:
                front.append(c)
        return front

    def select(self, candidates: List[RouteCandidate], objective: Objective) -> Optional[RouteCandidate]:
        if not candidates:
            return None
        if objective == Objective.MINIMUM_COST:
            return min(candidates, key=lambda c: c.spot.price)
        if objective == Objective.MINIMUM_TIME:
            return min(candidates, key=lambda c: c.spot.expected_transit_days)
        if objective == Objective.MAXIMUM_RELIABILITY:
            return max(candidates, key=lambda c: c.spot.reliability)
        if objective == Objective.MINIMUM_RISK:
            return min(candidates, key=_route_risk)
        if objective == Objective.MAXIMUM_CAPACITY_UTILISATION:
            # proxy: prefer routes whose legs show the highest average
            # scarcity component share, i.e. legs already running hot are
            # being used efficiently rather than left idle.
            def util_proxy(c: RouteCandidate) -> float:
                base = c.spot.components.base_transport or 1.0
                return c.spot.components.capacity_scarcity / base

            return max(candidates, key=util_proxy)
        raise ValueError(f"Unknown objective {objective}")
