"""Ocean carriers: shipping lines and vessels."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit


@dataclass
class Vessel:
    id: str
    name: str
    teu_capacity: int
    service_speed_knots: float
    fuel_consumption_tonnes_per_day: float
    current_location_id: str | None = None


@dataclass
class ShippingLine:
    id: str
    name: str
    vessels: List[Vessel] = field(default_factory=list)
    reliability_rating: float = 0.90  # baseline schedule reliability
    cost_efficiency: float = 1.0  # <1 = cheaper than market, >1 = pricier

    def total_teu(self) -> float:
        return sum(v.teu_capacity for v in self.vessels)

    def make_capacity_pool(self, pool_id: str, weekly_sailings: float) -> CapacityPool:
        weekly_teu = self.total_teu() / max(1, len(self.vessels)) * weekly_sailings if self.vessels else 0.0
        return CapacityPool(
            id=pool_id,
            mode="SEA",
            unit=CapacityUnit.TEU,
            total_capacity=weekly_teu,
            period_days=7.0,
        )


DEFAULT_SHIPPING_LINES: List[ShippingLine] = [
    ShippingLine(
        "OCEANIC",
        "Oceanic Alliance Line",
        vessels=[Vessel(f"OA-{i}", f"Oceanic {i}", teu_capacity=18000, service_speed_knots=22, fuel_consumption_tonnes_per_day=210) for i in range(1, 9)],
        reliability_rating=0.90,
        cost_efficiency=1.0,
    ),
    ShippingLine(
        "MERIDIAN",
        "Meridian Container Line",
        vessels=[Vessel(f"MC-{i}", f"Meridian {i}", teu_capacity=14000, service_speed_knots=20, fuel_consumption_tonnes_per_day=175) for i in range(1, 7)],
        reliability_rating=0.93,
        cost_efficiency=1.08,
    ),
    ShippingLine(
        "PACIFICSTAR",
        "PacificStar Shipping",
        vessels=[Vessel(f"PS-{i}", f"PacificStar {i}", teu_capacity=9000, service_speed_knots=19, fuel_consumption_tonnes_per_day=130) for i in range(1, 6)],
        reliability_rating=0.86,
        cost_efficiency=0.92,
    ),
]
