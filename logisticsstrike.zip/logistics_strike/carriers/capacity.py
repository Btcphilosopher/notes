"""Finite, dynamically-allocated freight capacity.

Every physical asset class (vessel, aircraft, train, truck, warehouse) is
reduced to a ``CapacityPool``: a unit of measure (TEU, kg, tonnes, pallets,
m3), a total quantity available per period, and how much of it is currently
allocated. Unused capacity is not free -- :meth:`CapacityPool.opportunity_cost`
prices the economic cost of a slot sitting idle, which feeds into spot
pricing (empty capacity should be discounted to fill; scarce capacity should
command a premium).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class CapacityUnit(str, Enum):
    TEU = "TEU"
    KG = "KG"
    TONNES = "TONNES"
    PALLETS = "PALLETS"
    M3 = "M3"


@dataclass
class CapacityPool:
    """A finite pool of capacity for one asset/service over one period."""

    id: str
    mode: str  # TransportMode value, kept as str to avoid import cycle
    unit: CapacityUnit
    total_capacity: float
    allocated_capacity: float = 0.0
    period_days: float = 7.0
    marginal_cost_per_unit: float = 0.0  # cost of the last unit of capacity to supply
    revenue_potential_per_unit: float = 0.0  # what the market would pay for the last unit
    base_capacity: float = 0.0  # nominal, undisrupted capacity -- see restore()/apply_multiplier()

    def __post_init__(self) -> None:
        if self.base_capacity <= 0:
            self.base_capacity = self.total_capacity

    def apply_multiplier(self, multiplier: float) -> None:
        """Set ``total_capacity`` to ``base_capacity * multiplier``.

        Used by the disruption engine so that repeated application across
        timesteps of a multi-step disruption does not compound (each call
        is relative to the undisrupted baseline, not the previous value).
        """
        self.total_capacity = max(0.0, self.base_capacity * multiplier)

    def restore(self) -> None:
        self.total_capacity = self.base_capacity

    def available(self) -> float:
        return max(0.0, self.total_capacity - self.allocated_capacity)

    def utilisation(self) -> float:
        if self.total_capacity <= 0:
            return 1.0
        return max(0.0, min(1.0, self.allocated_capacity / self.total_capacity))

    def scarcity(self) -> float:
        """0 = empty, 1 = fully booked. Drives the scarcity term in spot pricing."""
        return self.utilisation()

    def allocate(self, quantity: float) -> bool:
        if quantity <= self.available() + 1e-9:
            self.allocated_capacity += quantity
            return True
        return False

    def release(self, quantity: float) -> None:
        self.allocated_capacity = max(0.0, self.allocated_capacity - quantity)

    def reset_period(self) -> None:
        self.allocated_capacity = 0.0

    def opportunity_cost(self) -> float:
        """Economic cost of unused capacity: forgone revenue net of avoided
        marginal cost, scaled by how much sits idle."""
        idle_fraction = 1.0 - self.utilisation()
        forgone_margin = max(0.0, self.revenue_potential_per_unit - self.marginal_cost_per_unit)
        return idle_fraction * forgone_margin * self.available()
