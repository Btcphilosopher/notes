"""Road freight carriers: trucking companies and trucks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit


@dataclass
class Truck:
    id: str
    pallet_capacity: int
    max_payload_kg: float


@dataclass
class TruckingCompany:
    id: str
    name: str
    trucks: List[Truck] = field(default_factory=list)
    reliability_rating: float = 0.93
    cost_efficiency: float = 1.0

    def make_capacity_pool(self, pool_id: str, daily_trips_per_truck: float) -> CapacityPool:
        total_pallets = sum(t.pallet_capacity for t in self.trucks)
        return CapacityPool(
            id=pool_id,
            mode="ROAD",
            unit=CapacityUnit.PALLETS,
            total_capacity=total_pallets * daily_trips_per_truck * 7,
            period_days=7.0,
        )


DEFAULT_TRUCKING_COMPANIES: List[TruckingCompany] = [
    TruckingCompany(
        "CONTINENTAL",
        "Continental Trucking",
        trucks=[Truck(f"CT-{i}", pallet_capacity=26, max_payload_kg=22000) for i in range(1, 200)],
        reliability_rating=0.94,
        cost_efficiency=1.0,
    ),
    TruckingCompany(
        "SWIFTHAUL",
        "SwiftHaul Logistics",
        trucks=[Truck(f"SH-{i}", pallet_capacity=24, max_payload_kg=20000) for i in range(1, 150)],
        reliability_rating=0.90,
        cost_efficiency=0.94,
    ),
]
