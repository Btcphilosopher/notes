"""Air cargo carriers: airlines and aircraft."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit


@dataclass
class Aircraft:
    id: str
    model: str
    payload_kg: float
    volume_m3: float
    cruise_speed_kmh: float
    fuel_burn_kg_per_km: float


@dataclass
class Airline:
    id: str
    name: str
    fleet: List[Aircraft] = field(default_factory=list)
    reliability_rating: float = 0.94
    cost_efficiency: float = 1.0

    def total_payload_kg(self) -> float:
        return sum(a.payload_kg for a in self.fleet)

    def make_capacity_pool(self, pool_id: str, weekly_flights: float) -> CapacityPool:
        avg_payload = self.total_payload_kg() / max(1, len(self.fleet)) if self.fleet else 0.0
        return CapacityPool(
            id=pool_id,
            mode="AIR",
            unit=CapacityUnit.KG,
            total_capacity=avg_payload * weekly_flights,
            period_days=7.0,
        )


DEFAULT_AIRLINES: List[Airline] = [
    Airline(
        "SKYFREIGHT",
        "SkyFreight Cargo",
        fleet=[Aircraft(f"SF-{i}", "B777F", payload_kg=103000, volume_m3=650, cruise_speed_kmh=890, fuel_burn_kg_per_km=8.0) for i in range(1, 6)],
        reliability_rating=0.95,
        cost_efficiency=1.0,
    ),
    Airline(
        "AEROLOGIC",
        "AeroLogic Express",
        fleet=[Aircraft(f"AL-{i}", "B747F", payload_kg=112000, volume_m3=700, cruise_speed_kmh=910, fuel_burn_kg_per_km=9.5) for i in range(1, 5)],
        reliability_rating=0.92,
        cost_efficiency=1.05,
    ),
]
