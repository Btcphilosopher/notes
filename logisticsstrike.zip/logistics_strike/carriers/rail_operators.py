"""Rail freight carriers: operators and trains."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit


@dataclass
class Train:
    id: str
    wagons: int
    tonnes_per_wagon: float

    def total_tonnes(self) -> float:
        return self.wagons * self.tonnes_per_wagon


@dataclass
class RailOperator:
    id: str
    name: str
    trains: List[Train] = field(default_factory=list)
    reliability_rating: float = 0.88
    cost_efficiency: float = 1.0

    def make_capacity_pool(self, pool_id: str, weekly_departures: float) -> CapacityPool:
        avg_tonnes = (
            sum(t.total_tonnes() for t in self.trains) / max(1, len(self.trains)) if self.trains else 0.0
        )
        return CapacityPool(
            id=pool_id,
            mode="RAIL",
            unit=CapacityUnit.TONNES,
            total_capacity=avg_tonnes * weekly_departures,
            period_days=7.0,
        )


DEFAULT_RAIL_OPERATORS: List[RailOperator] = [
    RailOperator(
        "EURASIA_RAIL",
        "Eurasia Rail Freight",
        trains=[Train(f"ER-{i}", wagons=50, tonnes_per_wagon=68) for i in range(1, 10)],
        reliability_rating=0.85,
        cost_efficiency=0.9,
    ),
    RailOperator(
        "TRANSCON_RAIL",
        "Transcontinental Rail",
        trains=[Train(f"TR-{i}", wagons=120, tonnes_per_wagon=90) for i in range(1, 8)],
        reliability_rating=0.91,
        cost_efficiency=0.95,
    ),
]
