"""LogisticsStrike: a production-grade platform for modelling, forecasting,
pricing and optimising global freight markets.

The platform treats logistics simultaneously as a physical transportation
network and as a dynamic market for freight capacity. Its central purpose is
computing two numbers for any shipment or corridor:

    SPOT PRICE   -- what freight capacity costs right now
    STRIKE PRICE -- the economically defensible price for securing future
                    freight capacity subject to delivery, cost and
                    reliability requirements

See ``logistics_strike.simulation.world`` for a runnable end-to-end example
and ``logistics_strike.core.engine`` for the simulation loop.
"""

__version__ = "0.1.0"
