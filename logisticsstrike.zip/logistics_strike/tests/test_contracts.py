from datetime import datetime, timedelta

from logistics_strike.contracts.freight_contract import SLA, ContractType, FreightContract
from logistics_strike.contracts.settlement import SettlementEngine
from logistics_strike.contracts.strike_contract import LogisticsOption, OptionType, StrikeContractEconomics


def _contract(price=5000, volume=2, max_transit=30):
    now = datetime(2026, 1, 1)
    return FreightContract(
        contract_type=ContractType.STRIKE, buyer_id="BUYER", seller_id="SELLER",
        origin_id="A", destination_id="B", mode="SEA", price=price, volume_units=volume,
        execution_window_start=now, execution_window_end=now + timedelta(days=60),
        sla=SLA(max_transit_days=max_transit, min_reliability=0.9),
    )


def test_settlement_on_time_no_penalty():
    contract = _contract()
    result = SettlementEngine().settle(contract, actual_transit_days=28)
    assert result.on_time
    assert result.penalty == 0
    assert result.final_amount == result.base_amount


def test_settlement_late_applies_penalty_capped_at_max():
    contract = _contract(max_transit=30)
    contract.sla.max_penalty_pct = 0.25
    contract.sla.late_penalty_pct_per_day = 0.05
    result = SettlementEngine().settle(contract, actual_transit_days=50)  # 20 days late * 5%/day = 100%, capped at 25%
    assert not result.on_time
    assert result.penalty == round(result.base_amount * 0.25, 2)
    assert result.final_amount < result.base_amount


def test_strike_contract_economics_summary_has_expected_keys():
    econ = StrikeContractEconomics(
        strike_price=5260, expected_future_spot=5110, volume_units=2, volatility_annualised=0.3,
        horizon_years=0.15, execution_probability=0.95,
    )
    summary = econ.summary()
    for key in ["strike_price", "expected_future_spot", "buyer_value", "seller_value", "downside_p10", "upside_p90"]:
        assert key in summary


def test_strike_contract_downside_below_upside():
    econ = StrikeContractEconomics(
        strike_price=5000, expected_future_spot=5000, volume_units=1, volatility_annualised=0.4,
        horizon_years=0.25, execution_probability=1.0,
    )
    assert econ.downside(0.10) < econ.upside(0.90)


def test_logistics_option_premium_nonnegative_and_bounded_by_intrinsic_plus_time_value():
    option = LogisticsOption(
        option_type=OptionType.CAPACITY_CALL, strike=5200, current_spot=4820,
        volatility_annualised=0.35, horizon_years=0.15, volume_units=2, capacity_availability_forecast=0.8,
    )
    assert option.fair_premium() >= 0
    assert option.fair_premium() == option.intrinsic_value() + option.time_value()
    assert 0 <= option.probability_of_exercise() <= 1


def test_deep_in_the_money_call_has_high_exercise_probability():
    option = LogisticsOption(
        option_type=OptionType.CAPACITY_CALL, strike=1000, current_spot=5000,
        volatility_annualised=0.2, horizon_years=0.1, volume_units=1, capacity_availability_forecast=1.0,
    )
    assert option.probability_of_exercise() > 0.9
