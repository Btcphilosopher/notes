from datetime import datetime, timedelta

import pytest

from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.cargo.shipments import Shipment, ShipmentPriority
from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit
from logistics_strike.core.state import TransportMode
from logistics_strike.network.multimodal_graph import Edge
from logistics_strike.pricing.forward import ForwardCurveEngine, Tenor
from logistics_strike.pricing.fuel import FuelPriceEngine, FuelType
from logistics_strike.pricing.spot import SpotPriceEngine
from logistics_strike.pricing.strike import StrikeEngine, explain_spot_vs_strike
from logistics_strike.pricing.volatility import VolatilityModel, compute_volatility


def _standard_edge(congestion=0.2, risk=0.1) -> Edge:
    return Edge(
        origin="CNSHA", destination="NLRTM", mode=TransportMode.SEA,
        distance_km=19000, base_transit_days=29, transit_variability_days=3,
        capacity_per_week=4000, base_cost_per_unit=2400, reliability=0.9,
        fuel_share=0.5, risk_score=risk, congestion=congestion,
    )


def _standard_shipment() -> Shipment:
    cargo = CargoSpec(cargo_type=CargoType.CONTAINER_40FT, weight_kg=22000, volume_m3=67, declared_value_usd=60000)
    return Shipment(origin_id="CNSHA", destination_id="NLRTM", cargo=cargo, deadline=datetime(2026, 3, 1))


def test_spot_price_is_inspectable_and_positive():
    fuel_engine = FuelPriceEngine()
    engine = SpotPriceEngine(fuel_engine=fuel_engine)
    result = engine.compute_spot(_standard_shipment(), [_standard_edge()])
    assert result.price > 0
    assert result.components.total() == pytest.approx(result.price, rel=1e-6)
    assert "TOTAL" in result.explain()


def test_spot_price_rises_with_congestion():
    fuel_engine = FuelPriceEngine()
    engine = SpotPriceEngine(fuel_engine=fuel_engine)
    low = engine.compute_spot(_standard_shipment(), [_standard_edge(congestion=0.1)])
    high = engine.compute_spot(_standard_shipment(), [_standard_edge(congestion=0.9)])
    assert high.price > low.price
    assert high.reliability < low.reliability


def test_spot_price_rises_with_capacity_scarcity():
    fuel_engine = FuelPriceEngine()
    engine = SpotPriceEngine(fuel_engine=fuel_engine)
    edge = _standard_edge()
    empty_pool = CapacityPool("p", "SEA", CapacityUnit.TEU, total_capacity=1000, allocated_capacity=0)
    full_pool = CapacityPool("p", "SEA", CapacityUnit.TEU, total_capacity=1000, allocated_capacity=950)
    low = engine.compute_spot(_standard_shipment(), [edge], {edge.key: empty_pool})
    high = engine.compute_spot(_standard_shipment(), [edge], {edge.key: full_pool})
    assert high.price > low.price


def test_urgency_increases_price():
    fuel_engine = FuelPriceEngine()
    engine = SpotPriceEngine(fuel_engine=fuel_engine)
    cargo = CargoSpec(cargo_type=CargoType.CONTAINER_40FT, weight_kg=22000, volume_m3=67, declared_value_usd=60000)
    economy = Shipment(origin_id="CNSHA", destination_id="NLRTM", cargo=cargo, deadline=datetime(2026, 3, 1), priority=ShipmentPriority.ECONOMY)
    critical = Shipment(origin_id="CNSHA", destination_id="NLRTM", cargo=cargo, deadline=datetime(2026, 3, 1), priority=ShipmentPriority.CRITICAL)
    e_result = engine.compute_spot(economy, [_standard_edge()])
    c_result = engine.compute_spot(critical, [_standard_edge()])
    assert c_result.price > e_result.price


def test_forward_curve_tenors_increase_with_horizon():
    engine = ForwardCurveEngine()
    curve = engine.build_curve("TEST", "SEA", datetime(2026, 1, 1), 5000, spot_history=[4800, 4900, 5000, 5050, 5000])
    days = [p.horizon_days for p in curve.points]
    assert days == sorted(days)
    ci_widths = [p.ci_high - p.ci_low for p in curve.points]
    assert ci_widths == sorted(ci_widths)  # uncertainty widens with horizon


def test_strike_price_includes_risk_premium_over_expected_spot():
    fuel_engine = FuelPriceEngine()
    forward_engine = ForwardCurveEngine()
    strike_engine = StrikeEngine()

    curve = forward_engine.build_curve("TEST", "SEA", datetime(2026, 1, 1), 4820, spot_history=[4700, 4750, 4800, 4820])
    point = curve.point(Tenor.MONTHLY)

    result = strike_engine.compute_strike(
        corridor_id="TEST", mode="SEA", forward_point=point, current_spot=4820,
        capacity_scarcity_forecast=0.5, congestion_forecast=0.3, fuel_share=0.5,
        fuel_volatility_horizon=0.1, required_reliability=0.95, baseline_reliability=0.85,
    )
    assert result.strike_price > point.expected_spot  # risk load must be non-negative here
    assert result.components.total() == pytest.approx(result.strike_price, rel=1e-6)

    bounds = strike_engine.strike_bounds(result)
    assert bounds["minimum_reasonable_strike"] <= bounds["fair_strike"] <= bounds["risk_adjusted_strike"] <= bounds["maximum_commercial_strike"]


def test_strike_never_equals_expected_spot_when_reliability_gap_exists():
    forward_engine = ForwardCurveEngine()
    strike_engine = StrikeEngine()
    curve = forward_engine.build_curve("TEST", "SEA", datetime(2026, 1, 1), 5000, spot_history=[5000])
    point = curve.point(Tenor.MONTHLY)
    result = strike_engine.compute_strike(
        corridor_id="TEST", mode="SEA", forward_point=point, current_spot=5000,
        capacity_scarcity_forecast=0.0, congestion_forecast=0.0, fuel_share=0.0,
        fuel_volatility_horizon=0.0, required_reliability=0.99, baseline_reliability=0.80,
    )
    assert result.strike_price != pytest.approx(point.expected_spot)


def test_explain_spot_vs_strike_mentions_all_three_numbers():
    text = explain_spot_vs_strike(4820, 5110, 5260)
    assert "4,820" in text and "5,110" in text and "5,260" in text


@pytest.mark.parametrize("model", list(VolatilityModel))
def test_volatility_models_run_without_error(model):
    series = [100, 102, 101, 105, 103, 108, 110, 107, 112, 115]
    result = compute_volatility(series, model=model)
    assert result.annualised_vol >= 0
