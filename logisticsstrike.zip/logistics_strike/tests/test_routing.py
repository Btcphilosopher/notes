from datetime import datetime

from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.cargo.shipments import Shipment
from logistics_strike.core.state import NodeType, Region, TransportMode
from logistics_strike.network.multimodal_graph import Edge, MultimodalGraph, Node
from logistics_strike.pricing.fuel import FuelPriceEngine
from logistics_strike.pricing.spot import SpotPriceEngine
from logistics_strike.routing.optimisation import MultiObjectiveOptimiser, Objective, RouteObjectiveWeights, score_routes
from logistics_strike.routing.route_engine import RouteEngine


def _build_graph() -> MultimodalGraph:
    graph = MultimodalGraph()
    for nid, region in [("A", Region.NORTH_ASIA), ("B", Region.NORTH_EUROPE), ("C", Region.MIDDLE_EAST)]:
        graph.add_node(Node(nid, nid, NodeType.PORT, region, "XX", 0, 0))
    # cheap but slow direct route
    graph.add_edge(Edge("A", "B", TransportMode.SEA, 19000, 30, 3, 3000, 2000, 0.9, fuel_share=0.5, risk_score=0.1))
    # fast but expensive via hub C
    graph.add_edge(Edge("A", "C", TransportMode.AIR, 6000, 1, 0.2, 500, 4000, 0.95, fuel_share=0.4, risk_score=0.05))
    graph.add_edge(Edge("C", "B", TransportMode.AIR, 5000, 1, 0.2, 500, 3500, 0.95, fuel_share=0.4, risk_score=0.05))
    return graph


def _shipment() -> Shipment:
    cargo = CargoSpec(cargo_type=CargoType.CONTAINER_40FT, weight_kg=22000, volume_m3=67, declared_value_usd=60000)
    return Shipment(origin_id="A", destination_id="B", cargo=cargo, deadline=datetime(2026, 3, 1))


def test_route_engine_finds_multiple_paths():
    graph = _build_graph()
    engine = RouteEngine(graph=graph, spot_engine=SpotPriceEngine(fuel_engine=FuelPriceEngine()))
    candidates = engine.price_candidates(_shipment())
    assert len(candidates) >= 2
    mode_sequences = {tuple(c.modes) for c in candidates}
    assert ("SEA",) in mode_sequences
    assert ("AIR", "AIR") in mode_sequences


def test_cheapest_route_is_not_always_top_scored_when_time_weighted():
    graph = _build_graph()
    engine = RouteEngine(graph=graph, spot_engine=SpotPriceEngine(fuel_engine=FuelPriceEngine()))
    candidates = engine.price_candidates(_shipment())

    cheapest = min(candidates, key=lambda c: c.spot.price)
    time_focused = score_routes(candidates, RouteObjectiveWeights(cost=0.0, time=1.0, reliability=0.0, risk=0.0, carbon=0.0))
    assert time_focused[0].candidate is not cheapest or len(candidates) == 1


def test_pareto_front_excludes_dominated_routes():
    graph = _build_graph()
    engine = RouteEngine(graph=graph, spot_engine=SpotPriceEngine(fuel_engine=FuelPriceEngine()))
    candidates = engine.price_candidates(_shipment())
    front = MultiObjectiveOptimiser().pareto_front(candidates)
    assert len(front) <= len(candidates)
    assert len(front) >= 1


def test_objective_selectors_return_expected_extremes():
    graph = _build_graph()
    engine = RouteEngine(graph=graph, spot_engine=SpotPriceEngine(fuel_engine=FuelPriceEngine()))
    candidates = engine.price_candidates(_shipment())
    optimiser = MultiObjectiveOptimiser()

    cheapest = optimiser.select(candidates, Objective.MINIMUM_COST)
    fastest = optimiser.select(candidates, Objective.MINIMUM_TIME)
    assert cheapest.spot.price == min(c.spot.price for c in candidates)
    assert fastest.spot.expected_transit_days == min(c.spot.expected_transit_days for c in candidates)
