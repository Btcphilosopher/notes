import pytest

from logistics_strike.carriers.capacity import CapacityPool, CapacityUnit
from logistics_strike.network.multimodal_graph import Edge, MultimodalGraph, Node
from logistics_strike.core.state import NodeType, Region, TransportMode
from logistics_strike.pricing.congestion import CongestionModel
from logistics_strike.pricing.fuel import FuelPriceEngine, FuelType
from logistics_strike.risk.delay import DelayModel
from logistics_strike.risk.disruption import DisruptionEngine
from logistics_strike.risk.reliability import ReliabilityPricingModel
from logistics_strike.risk.var import compute_var_cvar


def test_delay_model_probability_bounds():
    model = DelayModel(expected_transit_days=30, transit_std_days=4)
    assert 0.0 <= model.p_on_time(30) <= 1.0
    assert model.p_on_time(60) > model.p_on_time(20)
    assert model.tail_delay(0.99) > model.tail_delay(0.5)


def test_reliability_premium_is_convex_and_nonnegative_for_positive_gap():
    model = ReliabilityPricingModel()
    small_gap = model.reliability_premium(5000, baseline_reliability=0.85, required_reliability=0.90)
    large_gap = model.reliability_premium(5000, baseline_reliability=0.85, required_reliability=0.99)
    assert small_gap >= 0
    assert large_gap > small_gap * 2  # convexity: doubling+ the gap more than doubles the premium


def test_reliability_discount_for_lower_requirement():
    model = ReliabilityPricingModel()
    discount = model.reliability_premium(5000, baseline_reliability=0.90, required_reliability=0.80)
    assert discount < 0


def test_disruption_capacity_effect_does_not_compound_across_steps():
    graph = MultimodalGraph()
    graph.add_node(Node("A", "A", NodeType.PORT, Region.NORTH_ASIA, "CN", 0, 0))
    graph.add_node(Node("B", "B", NodeType.PORT, Region.NORTH_EUROPE, "NL", 0, 0))
    edge = Edge("A", "B", TransportMode.SEA, 1000, 10, 1, 100, 50, 0.9, fuel_share=0.5)
    graph.add_edge(edge)

    pool_id = edge.key
    pool = CapacityPool(pool_id, "SEA", CapacityUnit.TEU, total_capacity=1000)
    capacity_pools = {pool_id: pool}

    congestion_model = CongestionModel(ports={}, airports={}, rail_terminals={}, rail_corridors={}, truck_depots={}, road_segments={})
    fuel_engine = FuelPriceEngine()
    disruption_engine = DisruptionEngine()
    disruption_engine.trigger(DisruptionEngine.port_closure("A", start_step=1, duration_steps=5, severity=0.8))

    # DisruptionEngine.port_closure sets capacity_multiplier = 1 - 0.85*severity
    expected_multiplier = 1.0 - 0.85 * 0.8

    for step in range(1, 6):
        congestion_model.recompute()
        disruption_engine.apply_effects(step, graph, congestion_model, capacity_pools, fuel_engine)
        # capacity should be knocked down to a fixed fraction of base and
        # STAY there, never compounding further down across repeated steps
        assert pool.total_capacity == pytest.approx(pool.base_capacity * expected_multiplier, rel=1e-6)

    # after the disruption expires, capacity must fully recover
    disruption_engine.step(6)
    disruption_engine.apply_effects(6, graph, congestion_model, capacity_pools, fuel_engine)
    assert pool.total_capacity == pytest.approx(pool.base_capacity, rel=1e-6)


def test_var_cvar_ordering():
    pnl_samples = [-500, -300, -100, 0, 100, 200, 300, -1000, 50, -50]
    result = compute_var_cvar(pnl_samples, confidence=0.9)
    assert result.cvar >= result.var  # CVaR is the mean of the tail beyond VaR, so >= VaR
    assert result.expected_loss >= 0
