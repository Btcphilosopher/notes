from datetime import datetime, timedelta

from logistics_strike.markets.auctions import UniformPriceAuction
from logistics_strike.markets.liquidity import LiquidityEngine
from logistics_strike.markets.matching import MatchingEngine
from logistics_strike.markets.order_book import Order, OrderBook, OrderSide


def _order(side, price, units=10, participant="P"):
    now = datetime(2026, 1, 1)
    return Order(
        side=side, participant_id=participant, origin_id="A", destination_id="B", mode="SEA",
        cargo_units=units, execution_window_start=now, execution_window_end=now + timedelta(days=30),
        limit_price=price, created_at=now,
    )


def test_order_book_best_bid_ask_and_spread():
    book = OrderBook()
    book.submit(_order(OrderSide.BUY, 100))
    book.submit(_order(OrderSide.BUY, 110))
    book.submit(_order(OrderSide.SELL, 120))
    book.submit(_order(OrderSide.SELL, 115))

    assert book.best_bid("A->B:SEA").limit_price == 110
    assert book.best_ask("A->B:SEA").limit_price == 115
    assert book.spread("A->B:SEA") == 5


def test_matching_engine_clears_crossed_orders():
    book = OrderBook()
    book.submit(_order(OrderSide.BUY, 120, units=10, participant="BUYER"))
    book.submit(_order(OrderSide.SELL, 100, units=10, participant="SELLER"))

    matches = MatchingEngine().match_corridor(book, "A->B:SEA", datetime(2026, 1, 1))
    assert len(matches) == 1
    assert matches[0].matched_units == 10
    assert matches[0].matched_price == 110  # midpoint of 120/100


def test_matching_engine_does_not_cross_disjoint_prices():
    book = OrderBook()
    book.submit(_order(OrderSide.BUY, 90))
    book.submit(_order(OrderSide.SELL, 100))
    matches = MatchingEngine().match_corridor(book, "A->B:SEA", datetime(2026, 1, 1))
    assert matches == []


def test_uniform_price_auction_allocates_by_price_and_sets_single_clearing_price():
    bids = [_order(OrderSide.BUY, 150, units=5, participant="X"), _order(OrderSide.BUY, 100, units=5, participant="Y"), _order(OrderSide.BUY, 80, units=5, participant="Z")]
    result = UniformPriceAuction().run(bids, available_capacity=8)
    assert result.total_capacity == 8
    prices = {a.clearing_price for a in result.allocations}
    assert len(prices) == 1  # uniform price
    assert sum(a.allocated_units for a in result.allocations) == 8


def test_liquidity_engine_reports_depth_and_spread():
    book = OrderBook()
    book.submit(_order(OrderSide.BUY, 100, units=50))
    book.submit(_order(OrderSide.SELL, 110, units=50))
    metrics = LiquidityEngine(depth_reference_units=100).measure(book, "A->B:SEA")
    assert metrics.depth_units == 100
    assert 0 <= metrics.depth_score <= 1
