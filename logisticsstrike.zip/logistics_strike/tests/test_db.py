from logistics_strike.db import repository
from logistics_strike.db.session import init_db, session_scope
from logistics_strike.db.models import SpotPrice, StrikePrice
from logistics_strike.simulation.world import build_default_world


def test_pricing_results_round_trip_through_sqlite(tmp_path):
    db_path = tmp_path / "test.db"
    init_db(f"sqlite:///{db_path}")

    engine = build_default_world()
    for _ in range(4):
        engine.step()

    key = next(iter(engine.state.spot_prices))
    spot_result = engine.state.spot_prices[key]
    strike_result = engine.state.strike_prices[key]
    curve = engine.state.forward_curves[key]

    with session_scope() as session:
        repository.save_spot_price(session, spot_result, key, scenario="baseline")
        repository.save_strike_price(session, strike_result, scenario="baseline")
        repository.save_forward_curve(session, curve, scenario="baseline")

    with session_scope() as session:
        spot_rows = session.query(SpotPrice).filter_by(corridor_key=key).all()
        strike_rows = session.query(StrikePrice).filter_by(corridor_key=key).all()
        assert len(spot_rows) == 1
        assert len(strike_rows) == 1
        assert spot_rows[0].model_version == "0.1.0"
        assert spot_rows[0].scenario == "baseline"
        assert spot_rows[0].price == spot_result.price
