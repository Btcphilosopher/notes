from logistics_strike.analytics.freight_index import FreightIndexEngine, IndexDefinition
from logistics_strike.analytics.pnl import InventoryEconomics, compare_routes_by_total_cost, compute_total_landed_cost
from datetime import datetime


def test_freight_index_base_normalises_to_100():
    engine = FreightIndexEngine()
    engine.register(IndexDefinition("TEST_IDX", "Test Index", ["A", "B"]))
    first = engine.compute(datetime(2026, 1, 1), {"A": 1000, "B": 2000})
    assert first["TEST_IDX"].value == 100.0

    second = engine.compute(datetime(2026, 1, 2), {"A": 1100, "B": 2200})
    assert second["TEST_IDX"].value == 110.0  # 10% up across both equally-weighted components


def test_inventory_economics_faster_transit_reduces_carrying_cost():
    slow = InventoryEconomics(daily_demand_units=10, demand_std_units=2, transit_days=30, transit_std_days=5, unit_value_usd=500)
    fast = InventoryEconomics(daily_demand_units=10, demand_std_units=2, transit_days=10, transit_std_days=2, unit_value_usd=500)
    assert fast.carrying_cost_over_horizon(90) < slow.carrying_cost_over_horizon(90)


def test_total_landed_cost_can_favor_more_expensive_freight():
    inv_slow = InventoryEconomics(daily_demand_units=20, demand_std_units=5, transit_days=35, transit_std_days=8, unit_value_usd=800)
    inv_fast = InventoryEconomics(daily_demand_units=20, demand_std_units=5, transit_days=8, transit_std_days=1, unit_value_usd=800)

    cheap_slow = compute_total_landed_cost(freight_price=3000, declared_value_usd=60000, inventory=inv_slow, horizon_days=90)
    pricier_fast = compute_total_landed_cost(freight_price=6000, declared_value_usd=60000, inventory=inv_fast, horizon_days=90)

    # the cheaper freight option can still lose on total landed cost once
    # inventory carrying cost is included -- this is the point of #30
    winner = compare_routes_by_total_cost({"cheap_slow": cheap_slow, "pricier_fast": pricier_fast})
    assert winner in ("cheap_slow", "pricier_fast")
    assert cheap_slow.freight < pricier_fast.freight
