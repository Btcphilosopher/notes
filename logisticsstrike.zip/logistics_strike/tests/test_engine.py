from logistics_strike.simulation.monte_carlo import MonteCarloEngine
from logistics_strike.simulation.world import build_default_world
from logistics_strike.pricing.forward import Tenor


def test_engine_runs_end_to_end_for_multiple_steps():
    engine = build_default_world()
    snapshots = [engine.step() for _ in range(10)]

    assert len(snapshots) == 10
    assert snapshots[-1]["step"] == 10
    # every tracked lane should have a spot and strike price by the end
    assert len(engine.state.spot_prices) > 0
    assert len(engine.state.strike_prices) > 0
    assert len(engine.state.forward_curves) > 0
    # some contracts should have been created via matching
    assert len(engine.state.contracts) >= 0  # matching is stochastic; just must not error


def test_engine_capacity_pools_never_go_negative():
    engine = build_default_world()
    for _ in range(15):
        engine.step()
    for pool in engine.capacity_pools.values():
        assert pool.total_capacity >= 0
        assert pool.allocated_capacity >= 0


def test_engine_metrics_history_grows_monotonically():
    engine = build_default_world()
    for _ in range(5):
        engine.step()
    steps = [m["step"] for m in engine.state.metrics_history]
    assert steps == sorted(steps)
    assert len(set(steps)) == len(steps)


def test_monte_carlo_percentiles_are_ordered():
    engine = build_default_world()
    for _ in range(6):
        engine.step()
    key = next(iter(engine.state.spot_prices))
    spot_result = engine.state.spot_prices[key]
    curve = engine.state.forward_curves[key]
    mc = MonteCarloEngine().simulate(
        corridor_id=key, forward_point=curve.point(Tenor.MONTHLY), strike_price=engine.state.strike_prices[key].strike_price,
        expected_transit_days=spot_result.expected_transit_days, transit_std_days=spot_result.transit_std_days,
        deadline_days=spot_result.expected_transit_days * 1.2, volume_units=2.0, capacity_scarcity_forecast=0.4,
        n_simulations=2000,
    )
    d = mc.future_spot.as_dict()
    ordered_values = [d[f"P{p}"] for p in [5, 10, 50, 90, 95, 99]]
    assert ordered_values == sorted(ordered_values)
