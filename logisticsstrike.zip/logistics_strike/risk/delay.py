"""Delay as a priced variable.

Transit time is modelled as a lognormal random variable (strictly positive,
right-skewed -- consistent with how freight transit times actually behave:
most shipments arrive close to schedule, a minority arrive very late). From
that distribution we derive the on-time delivery probability against a
deadline, expected delay, and tail delay (the loss-given-delay analogue used
by the risk engine's CVaR calculation).
"""

from __future__ import annotations

from dataclasses import dataclass
from math import erf, exp, log, sqrt

import numpy as np


def _lognormal_params(mean_days: float, std_days: float) -> tuple[float, float]:
    """Convert a (mean, std) of the transit-time distribution itself into the
    underlying normal's (mu, sigma) parameters."""
    mean_days = max(mean_days, 0.1)
    std_days = max(std_days, 1e-6)
    variance = std_days ** 2
    sigma2 = log(1.0 + variance / mean_days ** 2)
    sigma = sqrt(sigma2)
    mu = log(mean_days) - 0.5 * sigma2
    return mu, sigma


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


@dataclass
class DelayModel:
    expected_transit_days: float
    transit_std_days: float

    def __post_init__(self) -> None:
        self.mu, self.sigma = _lognormal_params(self.expected_transit_days, self.transit_std_days)

    def p_on_time(self, allowed_days: float) -> float:
        """P(actual transit time <= allowed_days)."""
        if allowed_days <= 0:
            return 0.0
        if self.sigma == 0:
            return 1.0 if allowed_days >= self.expected_transit_days else 0.0
        z = (log(allowed_days) - self.mu) / self.sigma
        return _norm_cdf(z)

    def expected_delay_given_late(self, allowed_days: float, n_samples: int = 20_000, seed: int = 42) -> float:
        """Monte Carlo estimate of E[actual - allowed | actual > allowed]."""
        rng = np.random.default_rng(seed)
        draws = rng.lognormal(self.mu, self.sigma, size=n_samples)
        late = draws[draws > allowed_days]
        if len(late) == 0:
            return 0.0
        return float(np.mean(late - allowed_days))

    def tail_delay(self, percentile: float = 0.95) -> float:
        """The transit time at the given percentile (e.g. P95 delay)."""
        rng_val = np.random.default_rng(1)
        # closed-form lognormal quantile
        from scipy.stats import norm

        z = norm.ppf(percentile)
        return float(exp(self.mu + self.sigma * z))

    def deadline_probability(self, deadline_days: float) -> float:
        return self.p_on_time(deadline_days)

    def sample(self, n: int = 1, seed: int | None = None) -> np.ndarray:
        rng = np.random.default_rng(seed)
        return rng.lognormal(self.mu, self.sigma, size=n)
