"""Geopolitical risk engine.

Maintains a slowly-varying risk score (0-1) per region and per named chokepoint
(e.g. Suez, Panama, Strait of Hormuz), used to load edge ``risk_score`` and,
through :mod:`logistics_strike.pricing.spot`/``strike``, freight prices for
routes that transit high-risk areas. Distinct from
:mod:`logistics_strike.risk.disruption`: disruptions are discrete events;
geopolitical risk is the persistent baseline those events are drawn on top
of.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

from logistics_strike.core.state import Region

DEFAULT_REGION_RISK: Dict[Region, float] = {
    Region.NORTH_ASIA: 0.12,
    Region.SOUTHEAST_ASIA: 0.10,
    Region.SOUTH_ASIA: 0.15,
    Region.NORTH_EUROPE: 0.06,
    Region.MEDITERRANEAN: 0.18,
    Region.NORTH_AMERICA_EAST: 0.04,
    Region.NORTH_AMERICA_WEST: 0.04,
    Region.MIDDLE_EAST: 0.35,
    Region.LATIN_AMERICA: 0.16,
    Region.AFRICA: 0.22,
    Region.OCEANIA: 0.05,
}

DEFAULT_CHOKEPOINT_RISK: Dict[str, float] = {
    "SUEZ": 0.20,
    "PANAMA": 0.12,
    "HORMUZ": 0.30,
    "MALACCA": 0.10,
    "BAB_EL_MANDEB": 0.28,
}


@dataclass
class GeopoliticalRiskEngine:
    region_risk: Dict[Region, float] = field(default_factory=lambda: dict(DEFAULT_REGION_RISK))
    chokepoint_risk: Dict[str, float] = field(default_factory=lambda: dict(DEFAULT_CHOKEPOINT_RISK))
    drift_volatility: float = 0.01
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng(23))

    def step(self) -> None:
        """Slow random walk, mean-reverting toward the defaults so a shock
        applied by the disruption/scenario engine fades gradually rather
        than persisting forever."""
        for region, base in DEFAULT_REGION_RISK.items():
            current = self.region_risk[region]
            reverted = current + 0.03 * (base - current)
            shocked = reverted + self.drift_volatility * self.rng.standard_normal()
            self.region_risk[region] = max(0.0, min(1.0, shocked))
        for cp, base in DEFAULT_CHOKEPOINT_RISK.items():
            current = self.chokepoint_risk[cp]
            reverted = current + 0.03 * (base - current)
            shocked = reverted + self.drift_volatility * self.rng.standard_normal()
            self.chokepoint_risk[cp] = max(0.0, min(1.0, shocked))

    def escalate_region(self, region: Region, delta: float) -> None:
        self.region_risk[region] = max(0.0, min(1.0, self.region_risk[region] + delta))

    def escalate_chokepoint(self, chokepoint: str, delta: float) -> None:
        self.chokepoint_risk[chokepoint] = max(0.0, min(1.0, self.chokepoint_risk.get(chokepoint, 0.1) + delta))

    def route_risk(self, regions: list[Region], chokepoints: list[str]) -> float:
        """Combine region and chokepoint risk for a route into a single 0-1
        score using a "not all fail independently" complement-of-products
        formula, so risk saturates rather than exceeding 1."""
        survival = 1.0
        for r in regions:
            survival *= 1.0 - self.region_risk.get(r, 0.1)
        for cp in chokepoints:
            survival *= 1.0 - self.chokepoint_risk.get(cp, 0.1)
        return max(0.0, min(1.0, 1.0 - survival))
