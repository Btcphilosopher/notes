"""Portfolio-level risk engine: VaR, CVaR, expected loss and deadline-failure
probability (requirement #31), aggregating the individual risk factors
computed elsewhere in this package (price/delay/disruption/weather/
geopolitical/route risk) into a single exposure report.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Sequence

import numpy as np

from logistics_strike.risk.delay import DelayModel


@dataclass
class VaRResult:
    confidence: float
    var: float  # loss threshold not expected to be exceeded at ``confidence``
    cvar: float  # expected loss *given* the VaR threshold is breached (tail mean)
    expected_loss: float
    n_samples: int


def compute_var_cvar(pnl_samples: Sequence[float], confidence: float = 0.95) -> VaRResult:
    """``pnl_samples`` are simulated P&L outcomes (positive = gain). VaR/CVaR
    are computed on the *loss* distribution, i.e. ``-pnl``."""
    losses = -np.asarray(pnl_samples, dtype=float)
    if len(losses) == 0:
        return VaRResult(confidence, 0.0, 0.0, 0.0, 0)
    var = float(np.quantile(losses, confidence))
    tail = losses[losses >= var]
    cvar = float(tail.mean()) if len(tail) else var
    expected_loss = float(np.mean(np.clip(losses, 0, None)))
    return VaRResult(confidence=confidence, var=round(var, 2), cvar=round(cvar, 2), expected_loss=round(expected_loss, 2), n_samples=len(losses))


@dataclass
class RiskFactorExposure:
    price_risk: float
    capacity_risk: float
    delay_risk: float
    fuel_risk: float
    geopolitical_risk: float
    weather_risk: float
    route_risk: float

    def composite(self, weights: Dict[str, float] | None = None) -> float:
        w = weights or {
            "price_risk": 0.25, "capacity_risk": 0.15, "delay_risk": 0.20,
            "fuel_risk": 0.15, "geopolitical_risk": 0.10, "weather_risk": 0.10, "route_risk": 0.05,
        }
        total = sum(getattr(self, k) * v for k, v in w.items())
        return max(0.0, min(1.0, total))


@dataclass
class RiskEngineReport:
    exposure: RiskFactorExposure
    var_result: VaRResult
    deadline_failure_probability: float


def build_risk_report(
    pnl_samples: Sequence[float],
    exposure: RiskFactorExposure,
    expected_transit_days: float,
    transit_std_days: float,
    deadline_days: float,
    confidence: float = 0.95,
) -> RiskEngineReport:
    var_result = compute_var_cvar(pnl_samples, confidence)
    delay_model = DelayModel(expected_transit_days, transit_std_days)
    p_fail = 1.0 - delay_model.deadline_probability(deadline_days)
    return RiskEngineReport(exposure=exposure, var_result=var_result, deadline_failure_probability=round(p_fail, 4))
