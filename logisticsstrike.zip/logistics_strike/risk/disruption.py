"""Global disruption engine.

Disruptions are discrete events (port closure, canal disruption, strike,
labour shortage, fuel shock, war, sanctions, weather, earthquake, pandemic,
capacity withdrawal) that propagate through the network:

    DISRUPTION -> CAPACITY REMOVED / CONGESTION UP / RISK UP
        -> QUEUE INCREASE -> TRANSIT TIME INCREASE
        -> SPOT PRICE UP -> FORWARD EXPECTATIONS UP -> STRIKE PRICE UP

Rather than hard-coding eleven bespoke propagation paths, every disruption
is expressed as a small set of generic effects (a congestion delta, a
capacity multiplier, a risk delta, an optional fuel shock) applied to a
target (a node, an edge, a region, a capacity pool, or the whole network).
The 11 named types in :class:`DisruptionType` are realised as factory
functions that pick sensible defaults for that target/effect combination --
the propagation mechanics are shared and therefore consistent.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.network.multimodal_graph import MultimodalGraph
from logistics_strike.pricing.congestion import CongestionModel
from logistics_strike.pricing.fuel import FuelPriceEngine, FuelType

_id_counter = itertools.count(1)


class DisruptionType(str, Enum):
    PORT_CLOSURE = "PORT_CLOSURE"
    CANAL_DISRUPTION = "CANAL_DISRUPTION"
    PORT_STRIKE = "PORT_STRIKE"
    LABOUR_SHORTAGE = "LABOUR_SHORTAGE"
    FUEL_SHOCK = "FUEL_SHOCK"
    WAR = "WAR"
    SANCTIONS = "SANCTIONS"
    WEATHER = "WEATHER"
    EARTHQUAKE = "EARTHQUAKE"
    PANDEMIC = "PANDEMIC"
    CAPACITY_WITHDRAWAL = "CAPACITY_WITHDRAWAL"


class TargetType(str, Enum):
    NODE = "NODE"
    EDGE = "EDGE"
    REGION = "REGION"
    CAPACITY_POOL = "CAPACITY_POOL"
    FUEL = "FUEL"
    GLOBAL = "GLOBAL"


@dataclass
class Disruption:
    id: str
    type: DisruptionType
    target_type: TargetType
    target_id: str
    severity: float  # 0-1
    start_step: int
    duration_steps: int
    congestion_delta: float = 0.0
    capacity_multiplier: float = 1.0  # applied to CapacityPool.total_capacity
    risk_delta: float = 0.0
    fuel_type: Optional[FuelType] = None
    fuel_shock_pct: float = 0.0
    description: str = ""

    def is_active(self, step: int) -> bool:
        return self.start_step <= step < self.start_step + self.duration_steps

    def remaining_steps(self, step: int) -> int:
        return max(0, self.start_step + self.duration_steps - step)


@dataclass
class DisruptionEngine:
    active: Dict[str, Disruption] = field(default_factory=dict)
    resolved: List[Disruption] = field(default_factory=list)

    def trigger(self, disruption: Disruption) -> Disruption:
        self.active[disruption.id] = disruption
        return disruption

    def step(self, current_step: int) -> List[Disruption]:
        """Expire disruptions whose duration has elapsed. Returns the list of
        disruptions that just resolved."""
        newly_resolved = []
        for did, d in list(self.active.items()):
            if not d.is_active(current_step):
                newly_resolved.append(d)
                self.resolved.append(d)
                del self.active[did]
        return newly_resolved

    def apply_effects(
        self,
        current_step: int,
        graph: MultimodalGraph,
        congestion_model: CongestionModel,
        capacity_pools: Dict[str, CapacityPool],
        fuel_engine: FuelPriceEngine,
    ) -> None:
        """Apply every currently-active disruption to the network for this
        timestep.

        Capacity multipliers are combined *per pool* (product across all
        active disruptions touching that pool) and then applied once,
        relative to each pool's undisrupted ``base_capacity`` -- see
        :meth:`CapacityPool.apply_multiplier`. This keeps a multi-step
        disruption's effect constant for its duration rather than
        compounding every timestep, and automatically restores pools once
        the disruption expires (product over zero active disruptions is 1).
        """
        active = [d for d in self.active.values() if d.is_active(current_step)]

        pool_multipliers: Dict[str, float] = {pid: 1.0 for pid in capacity_pools}

        for d in active:
            if d.target_type == TargetType.NODE:
                congestion_model.apply_capacity_shock(d.target_id, d.severity * abs(d.congestion_delta) or d.severity)
                for pool_id in capacity_pools:
                    if d.target_id in pool_id:
                        pool_multipliers[pool_id] *= d.capacity_multiplier

            elif d.target_type == TargetType.EDGE:
                for edge in graph.edges():
                    if edge.key == d.target_id or f"{edge.origin}->{edge.destination}" == d.target_id:
                        edge.congestion = max(0.0, min(1.0, edge.congestion + d.congestion_delta))
                        edge.risk_score = max(0.0, min(1.0, edge.risk_score + d.risk_delta))

            elif d.target_type == TargetType.REGION:
                for node in graph.nodes():
                    if node.region.value == d.target_id:
                        congestion_model.apply_capacity_shock(node.id, d.severity * 0.5)

            elif d.target_type == TargetType.CAPACITY_POOL:
                if d.target_id in pool_multipliers:
                    pool_multipliers[d.target_id] *= d.capacity_multiplier

            elif d.target_type == TargetType.FUEL and d.fuel_type is not None:
                fuel_engine.apply_shock(d.fuel_type, d.fuel_shock_pct)

            elif d.target_type == TargetType.GLOBAL:
                for pool_id in pool_multipliers:
                    pool_multipliers[pool_id] *= d.capacity_multiplier
                for edge in graph.edges():
                    edge.risk_score = max(0.0, min(1.0, edge.risk_score + d.risk_delta))

        for pool_id, multiplier in pool_multipliers.items():
            capacity_pools[pool_id].apply_multiplier(multiplier)

    # -- factory presets ------------------------------------------------
    @staticmethod
    def port_closure(port_id: str, start_step: int, duration_steps: int = 7, severity: float = 0.9) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.PORT_CLOSURE,
            target_type=TargetType.NODE,
            target_id=port_id,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity,
            capacity_multiplier=1.0 - 0.85 * severity,
            description=f"Port closure at {port_id}",
        )

    @staticmethod
    def port_strike(port_id: str, start_step: int, duration_steps: int = 5, severity: float = 0.6) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.PORT_STRIKE,
            target_type=TargetType.NODE,
            target_id=port_id,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity * 0.8,
            capacity_multiplier=1.0 - 0.6 * severity,
            description=f"Labour strike at {port_id}",
        )

    @staticmethod
    def labour_shortage(node_id: str, start_step: int, duration_steps: int = 14, severity: float = 0.35) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.LABOUR_SHORTAGE,
            target_type=TargetType.NODE,
            target_id=node_id,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity * 0.5,
            capacity_multiplier=1.0 - 0.3 * severity,
            description=f"Labour shortage at {node_id}",
        )

    @staticmethod
    def canal_disruption(canal_edge_key: str, start_step: int, duration_steps: int = 10, severity: float = 0.8) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.CANAL_DISRUPTION,
            target_type=TargetType.EDGE,
            target_id=canal_edge_key,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity * 0.7,
            risk_delta=severity * 0.5,
            description=f"Canal disruption on {canal_edge_key}",
        )

    @staticmethod
    def fuel_shock(fuel_type: FuelType, start_step: int, pct_change: float = 0.5, duration_steps: int = 1) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.FUEL_SHOCK,
            target_type=TargetType.FUEL,
            target_id=fuel_type.value,
            severity=min(1.0, abs(pct_change)),
            start_step=start_step,
            duration_steps=duration_steps,
            fuel_type=fuel_type,
            fuel_shock_pct=pct_change,
            description=f"Fuel shock: {fuel_type.value} {pct_change:+.0%}",
        )

    @staticmethod
    def war(region: str, start_step: int, duration_steps: int = 60, severity: float = 0.7) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.WAR,
            target_type=TargetType.REGION,
            target_id=region,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity * 0.4,
            risk_delta=severity,
            description=f"Armed conflict affecting {region}",
        )

    @staticmethod
    def sanctions(region: str, start_step: int, duration_steps: int = 180, severity: float = 0.5) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.SANCTIONS,
            target_type=TargetType.REGION,
            target_id=region,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            risk_delta=severity * 0.6,
            capacity_multiplier=1.0 - 0.2 * severity,
            description=f"Sanctions regime affecting {region}",
        )

    @staticmethod
    def earthquake(node_id: str, start_step: int, duration_steps: int = 21, severity: float = 0.85) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.EARTHQUAKE,
            target_type=TargetType.NODE,
            target_id=node_id,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            congestion_delta=severity,
            capacity_multiplier=1.0 - 0.7 * severity,
            description=f"Earthquake impacting {node_id}",
        )

    @staticmethod
    def pandemic(start_step: int, duration_steps: int = 120, severity: float = 0.4) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.PANDEMIC,
            target_type=TargetType.GLOBAL,
            target_id="GLOBAL",
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            capacity_multiplier=1.0 - 0.25 * severity,
            risk_delta=severity * 0.3,
            description="Global pandemic capacity/labour shock",
        )

    @staticmethod
    def capacity_withdrawal(pool_id: str, start_step: int, duration_steps: int = 30, severity: float = 0.3) -> Disruption:
        return Disruption(
            id=f"DIS-{next(_id_counter):05d}",
            type=DisruptionType.CAPACITY_WITHDRAWAL,
            target_type=TargetType.CAPACITY_POOL,
            target_id=pool_id,
            severity=severity,
            start_step=start_step,
            duration_steps=duration_steps,
            capacity_multiplier=1.0 - severity,
            description=f"Carrier withdraws capacity from {pool_id}",
        )
