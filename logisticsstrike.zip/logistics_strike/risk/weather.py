"""Weather risk engine.

Generates a stochastic weather-severity score per region each timestep
(seasonally modulated -- e.g. Q3 typhoon season in North Asia, Q1 winter
storms in North Europe/North America) and exposes it as a congestion/risk
input for sea, road and rail edges. Severe draws can also be escalated into
a full :class:`~logistics_strike.risk.disruption.Disruption` by the
simulation world (see ``simulation/world.py``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

from logistics_strike.core.state import Region

# crude seasonal severity multipliers by (region, month)
_SEASONAL_MULTIPLIER: Dict[Region, Dict[int, float]] = {
    Region.NORTH_ASIA: {m: (1.6 if m in (7, 8, 9) else 0.9) for m in range(1, 13)},
    Region.SOUTHEAST_ASIA: {m: (1.5 if m in (10, 11, 12) else 0.9) for m in range(1, 13)},
    Region.NORTH_EUROPE: {m: (1.4 if m in (12, 1, 2) else 0.85) for m in range(1, 13)},
    Region.NORTH_AMERICA_EAST: {m: (1.5 if m in (8, 9, 10) else 0.9) for m in range(1, 13)},
    Region.NORTH_AMERICA_WEST: {m: (1.1 if m in (12, 1, 2) else 0.9) for m in range(1, 13)},
    Region.MIDDLE_EAST: {m: 0.7 for m in range(1, 13)},
    Region.LATIN_AMERICA: {m: (1.3 if m in (1, 2, 3) else 0.9) for m in range(1, 13)},
    Region.AFRICA: {m: 0.8 for m in range(1, 13)},
    Region.OCEANIA: {m: (1.3 if m in (1, 2, 3) else 0.9) for m in range(1, 13)},
    Region.SOUTH_ASIA: {m: (1.6 if m in (6, 7, 8, 9) else 0.9) for m in range(1, 13)},
    Region.MEDITERRANEAN: {m: 0.85 for m in range(1, 13)},
}


@dataclass
class WeatherEngine:
    base_severity: float = 0.15
    volatility: float = 0.10
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng(11))
    severity: Dict[Region, float] = field(default_factory=dict)

    def step(self, month: int) -> Dict[Region, float]:
        for region in Region:
            mult = _SEASONAL_MULTIPLIER.get(region, {}).get(month, 1.0)
            draw = self.base_severity * mult + self.volatility * mult * self.rng.standard_normal()
            self.severity[region] = float(max(0.0, min(1.0, draw)))
        return dict(self.severity)

    def severity_for(self, region: Region) -> float:
        return self.severity.get(region, self.base_severity)

    def is_severe(self, region: Region, threshold: float = 0.55) -> bool:
        return self.severity_for(region) >= threshold
