"""Composite reliability model and reliability-premium pricing.

Combines delay probability (:mod:`logistics_strike.risk.delay`), active
disruption exposure, weather severity and geopolitical risk into a single
on-time-delivery reliability score for a route, then prices the premium a
shipper should rationally pay to move from a lower reliability requirement
to a higher one (requirement #11).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from logistics_strike.risk.delay import DelayModel


@dataclass
class ReliabilityBreakdown:
    delay_reliability: float  # P(on time) from the transit-time distribution
    disruption_factor: float  # multiplicative haircut from active disruptions on-route
    weather_factor: float  # multiplicative haircut from weather severity
    geopolitical_factor: float  # multiplicative haircut from geopolitical risk

    @property
    def composite(self) -> float:
        return max(
            0.01,
            min(
                0.999,
                self.delay_reliability
                * self.disruption_factor
                * self.weather_factor
                * self.geopolitical_factor,
            ),
        )


def compute_reliability(
    expected_transit_days: float,
    transit_std_days: float,
    allowed_days: float,
    disruption_exposure: float = 0.0,  # 0-1, e.g. mean congestion delta along route from active disruptions
    weather_severity: float = 0.0,  # 0-1
    geopolitical_risk: float = 0.0,  # 0-1
) -> ReliabilityBreakdown:
    delay_model = DelayModel(expected_transit_days, transit_std_days)
    p_on_time = delay_model.deadline_probability(allowed_days)
    return ReliabilityBreakdown(
        delay_reliability=p_on_time,
        disruption_factor=1.0 - 0.5 * disruption_exposure,
        weather_factor=1.0 - 0.3 * weather_severity,
        geopolitical_factor=1.0 - 0.25 * geopolitical_risk,
    )


@dataclass
class ReliabilityPricingModel:
    """Prices the premium for requiring higher reliability than a route's
    baseline, and the discount for accepting lower reliability.

    The functional form is convex in the reliability gap: moving from 80%
    to 90% required reliability costs less than moving from 90% to 99%,
    which matches the empirical shape of freight reliability markets (the
    last percentage points of certainty are disproportionately expensive
    because they require holding back-up capacity / faster, less efficient
    routings).
    """

    premium_scale: float = 1.35  # base price sensitivity to a 1.0 reliability gap
    convexity: float = 2.2  # >1 => convex (increasingly expensive at the margin)

    def reliability_premium(self, base_price: float, baseline_reliability: float, required_reliability: float) -> float:
        gap = required_reliability - baseline_reliability
        if gap <= 0:
            # accepting lower reliability than baseline earns a (smaller,
            # linear) discount rather than a symmetric convex premium --
            # carriers don't reward laxity as aggressively as they charge
            # for certainty.
            return base_price * gap * 0.6
        normalised_gap = gap / max(1e-6, 1.0 - baseline_reliability)
        return base_price * self.premium_scale * normalised_gap ** self.convexity * gap

    def price_for_reliability(self, base_price: float, baseline_reliability: float, required_reliability: float) -> float:
        return base_price + self.reliability_premium(base_price, baseline_reliability, required_reliability)

    def implied_value_of_reliability(
        self,
        base_price: float,
        baseline_reliability: float,
        high_reliability: float,
        high_price: float,
    ) -> float:
        """Given two quoted (reliability, price) points, back out the implied
        USD value the market places on each additional percentage point of
        reliability."""
        gap = high_reliability - baseline_reliability
        if gap <= 0:
            return 0.0
        return (high_price - base_price) / (gap * 100)
