"""Lightweight, dependency-free visualisation helpers.

The platform's real UI is expected to be a proper dashboard (or a notebook
using matplotlib/plotly against the API), so this module deliberately
avoids adding a heavy plotting dependency. It instead renders forward
curves, price history and Monte Carlo percentile fans as terminal-friendly
tables and Unicode sparklines -- useful for CLI demos, logs, and quick
sanity checks in a REPL.
"""

from __future__ import annotations

from typing import Dict, List, Sequence

from logistics_strike.pricing.forward import ForwardCurve
from logistics_strike.simulation.monte_carlo import MonteCarloResult

_SPARK_CHARS = " ▁▂▃▄▅▆▇█"


def sparkline(values: Sequence[float]) -> str:
    if not values:
        return ""
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return _SPARK_CHARS[4] * len(values)
    scaled = [(v - lo) / (hi - lo) for v in values]
    return "".join(_SPARK_CHARS[min(len(_SPARK_CHARS) - 1, int(s * (len(_SPARK_CHARS) - 1)))] for s in scaled)


def render_price_history(name: str, values: Sequence[float]) -> str:
    if not values:
        return f"{name}: (no history)"
    return f"{name}: {sparkline(values)}  latest={values[-1]:,.2f}  min={min(values):,.2f}  max={max(values):,.2f}"


def render_forward_curve_table(curve: ForwardCurve) -> str:
    rows = curve.as_table()
    header = f"{'Tenor':<10}{'Horizon':<12}{'Expected':>12}{'Forward':>12}{'CI Low':>12}{'CI High':>12}"
    lines = [f"Forward curve: {curve.corridor_id} ({curve.mode}) as of {curve.as_of.date()}", header, "-" * len(header)]
    for r in rows:
        lines.append(
            f"{r['tenor']:<10}{r['horizon']:<12}{r['expected_spot']:>12,.2f}{r['forward']:>12,.2f}"
            f"{r['ci_low']:>12,.2f}{r['ci_high']:>12,.2f}"
        )
    return "\n".join(lines)


def render_monte_carlo_fan(result: MonteCarloResult, metric: str = "future_spot") -> str:
    percentile_set = getattr(result, metric)
    d = percentile_set.as_dict()
    header = f"Monte Carlo ({result.n_simulations:,} sims) -- {metric} for {result.corridor_id}"
    body = "  ".join(f"{k}={v:,.2f}" for k, v in d.items())
    return f"{header}\n  {body}"


def render_metrics_dashboard(latest_snapshot: Dict) -> str:
    lines = [f"=== Simulation step {latest_snapshot['step']} ({latest_snapshot['timestamp']}) ==="]
    lines.append(f"shipments generated: {latest_snapshot['n_shipments_generated']}  matches: {latest_snapshot['n_matches']}  "
                 f"contracts: {latest_snapshot['n_contracts']}  in-transit: {latest_snapshot['n_in_transit']}")
    lines.append(f"avg capacity utilisation: {latest_snapshot['avg_utilisation']*100:.1f}%  active disruptions: {latest_snapshot['active_disruptions']}")
    lines.append("spot prices:")
    for k, v in latest_snapshot["spot_prices"].items():
        lines.append(f"  {k:<28} {v:>10,.2f}")
    lines.append("strike prices:")
    for k, v in latest_snapshot["strike_prices"].items():
        lines.append(f"  {k:<28} {v:>10,.2f}")
    return "\n".join(lines)
