"""Freight price indices.

Configurable, corridor-weighted indices (Global Container Index,
Asia-Europe Spot, Transatlantic Spot, Air Freight Index, North American
Trucking Index, ...) built from the platform's own simulated/ingested spot
prices -- never a static number, always a live aggregate of the
:class:`~logistics_strike.pricing.spot.SpotPriceResult` objects the engine
produces each timestep.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List


@dataclass
class IndexDefinition:
    id: str
    name: str
    corridor_keys: List[str]
    weights: Dict[str, float] = field(default_factory=dict)  # corridor_key -> weight; equal-weighted if empty

    def weight_for(self, corridor_key: str) -> float:
        if self.weights:
            return self.weights.get(corridor_key, 0.0)
        return 1.0 / len(self.corridor_keys) if self.corridor_keys else 0.0


@dataclass
class IndexPoint:
    as_of: datetime
    value: float
    n_components: int
    components: Dict[str, float]


STANDARD_INDICES: List[IndexDefinition] = [
    IndexDefinition("GLOBAL_CONTAINER", "Global Container Index", []),  # populated at runtime with all SEA corridors
    IndexDefinition("ASIA_EUROPE_SPOT", "Asia-Europe Spot", []),
    IndexDefinition("TRANSATLANTIC_SPOT", "Transatlantic Spot", []),
    IndexDefinition("AIR_FREIGHT", "Air Freight Index", []),
    IndexDefinition("NA_TRUCKING", "North American Trucking Index", []),
]


@dataclass
class FreightIndexEngine:
    definitions: Dict[str, IndexDefinition] = field(default_factory=dict)
    base_values: Dict[str, float] = field(default_factory=dict)  # index_id -> value at first computation (=100)
    history: Dict[str, List[IndexPoint]] = field(default_factory=dict)

    def register(self, definition: IndexDefinition) -> None:
        self.definitions[definition.id] = definition
        self.history.setdefault(definition.id, [])

    def compute(self, as_of: datetime, spot_prices: Dict[str, float]) -> Dict[str, IndexPoint]:
        results: Dict[str, IndexPoint] = {}
        for index_id, defn in self.definitions.items():
            components = {k: spot_prices[k] for k in defn.corridor_keys if k in spot_prices}
            if not components:
                continue
            weighted_sum = sum(components[k] * defn.weight_for(k) for k in components)
            total_weight = sum(defn.weight_for(k) for k in components) or 1.0
            level = weighted_sum / total_weight

            if index_id not in self.base_values:
                self.base_values[index_id] = level
            base = self.base_values[index_id] or 1.0
            index_value = 100.0 * level / base

            point = IndexPoint(as_of=as_of, value=round(index_value, 2), n_components=len(components), components=components)
            self.history.setdefault(index_id, []).append(point)
            results[index_id] = point
        return results

    def latest(self, index_id: str) -> IndexPoint | None:
        h = self.history.get(index_id, [])
        return h[-1] if h else None
