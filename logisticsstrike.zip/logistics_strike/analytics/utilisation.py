"""Capacity utilisation analytics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from logistics_strike.carriers.capacity import CapacityPool


@dataclass
class UtilisationSnapshot:
    pool_id: str
    mode: str
    utilisation: float
    available: float
    total_capacity: float
    opportunity_cost: float


def snapshot_utilisation(pools: Dict[str, CapacityPool]) -> List[UtilisationSnapshot]:
    return [
        UtilisationSnapshot(
            pool_id=p.id,
            mode=p.mode,
            utilisation=round(p.utilisation(), 4),
            available=round(p.available(), 2),
            total_capacity=round(p.total_capacity, 2),
            opportunity_cost=round(p.opportunity_cost(), 2),
        )
        for p in pools.values()
    ]


def average_utilisation_by_mode(pools: Dict[str, CapacityPool]) -> Dict[str, float]:
    by_mode: Dict[str, List[float]] = {}
    for p in pools.values():
        by_mode.setdefault(p.mode, []).append(p.utilisation())
    return {mode: sum(vals) / len(vals) for mode, vals in by_mode.items()}


def idle_capacity_cost(pools: Dict[str, CapacityPool]) -> float:
    """Total economic opportunity cost of unused capacity across all pools."""
    return sum(p.opportunity_cost() for p in pools.values())
