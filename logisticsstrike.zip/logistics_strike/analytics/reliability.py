"""Aggregate reliability analytics.

Rolls up per-shipment/contract on-time performance into portfolio-level
reliability statistics -- what the P&L and risk engines consume to judge
whether the platform's quoted reliability numbers are actually being met.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List

from logistics_strike.contracts.settlement import SettlementResult


@dataclass
class ReliabilityReport:
    n_settlements: int
    n_on_time: int
    on_time_rate: float
    avg_days_late_when_late: float
    total_penalty: float
    total_bonus: float


def build_reliability_report(settlements: Iterable[SettlementResult]) -> ReliabilityReport:
    settlements = list(settlements)
    n = len(settlements)
    if n == 0:
        return ReliabilityReport(0, 0, 0.0, 0.0, 0.0, 0.0)
    on_time = [s for s in settlements if s.on_time]
    late = [s for s in settlements if not s.on_time]
    avg_late = sum(s.days_late for s in late) / len(late) if late else 0.0
    return ReliabilityReport(
        n_settlements=n,
        n_on_time=len(on_time),
        on_time_rate=round(len(on_time) / n, 4),
        avg_days_late_when_late=round(avg_late, 2),
        total_penalty=round(sum(s.penalty for s in settlements), 2),
        total_bonus=round(sum(s.bonus for s in settlements), 2),
    )


def reliability_by_corridor(settlements_by_corridor: Dict[str, List[SettlementResult]]) -> Dict[str, ReliabilityReport]:
    return {k: build_reliability_report(v) for k, v in settlements_by_corridor.items()}
