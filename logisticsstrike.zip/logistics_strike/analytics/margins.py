"""Carrier margin/cost decomposition.

Splits a settled contract's revenue into the cost buckets requirement #28
asks for (fuel, labour, maintenance, capacity cost, port costs, delay cost,
contract settlement) using configurable fractional splits of the
underlying capacity pool's marginal cost, so the platform can show *why* a
carrier's margin on a given lane looks the way it does.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from logistics_strike.contracts.freight_contract import FreightContract
from logistics_strike.contracts.settlement import SettlementResult


@dataclass
class CarrierCostSplit:
    fuel_share: float = 0.32
    labour_share: float = 0.20
    maintenance_share: float = 0.12
    port_share: float = 0.14
    capacity_share: float = 0.10  # depreciation/charter cost of the asset itself
    other_share: float = 0.12

    def normalised(self) -> "CarrierCostSplit":
        total = self.fuel_share + self.labour_share + self.maintenance_share + self.port_share + self.capacity_share + self.other_share
        if total <= 0:
            return CarrierCostSplit()
        f = 1.0 / total
        return CarrierCostSplit(
            self.fuel_share * f, self.labour_share * f, self.maintenance_share * f,
            self.port_share * f, self.capacity_share * f, self.other_share * f,
        )


@dataclass
class CarrierMargin:
    contract_id: str
    revenue: float
    fuel_cost: float
    labour_cost: float
    maintenance_cost: float
    port_cost: float
    capacity_cost: float
    other_cost: float
    delay_cost: float  # penalties paid out, from settlement
    profit: float

    def total_cost(self) -> float:
        return (
            self.fuel_cost + self.labour_cost + self.maintenance_cost
            + self.port_cost + self.capacity_cost + self.other_cost + self.delay_cost
        )

    def margin_pct(self) -> float:
        return self.profit / self.revenue if self.revenue else 0.0


def compute_carrier_margin(
    contract: FreightContract,
    marginal_cost_basis: float,  # total variable cost estimate before revenue, e.g. capacity_pool.marginal_cost_per_unit * volume
    settlement: SettlementResult | None = None,
    split: CarrierCostSplit | None = None,
) -> CarrierMargin:
    split = (split or CarrierCostSplit()).normalised()
    revenue = settlement.base_amount if settlement else contract.notional_value()
    delay_cost = settlement.penalty if settlement else 0.0
    bonus = settlement.bonus if settlement else 0.0

    fuel = marginal_cost_basis * split.fuel_share
    labour = marginal_cost_basis * split.labour_share
    maintenance = marginal_cost_basis * split.maintenance_share
    port = marginal_cost_basis * split.port_share
    capacity = marginal_cost_basis * split.capacity_share
    other = marginal_cost_basis * split.other_share

    total_cost = fuel + labour + maintenance + port + capacity + other + delay_cost
    profit = revenue + bonus - total_cost

    return CarrierMargin(
        contract_id=contract.id,
        revenue=round(revenue, 2),
        fuel_cost=round(fuel, 2),
        labour_cost=round(labour, 2),
        maintenance_cost=round(maintenance, 2),
        port_cost=round(port, 2),
        capacity_cost=round(capacity, 2),
        other_cost=round(other, 2),
        delay_cost=round(delay_cost, 2),
        profit=round(profit, 2),
    )
