"""P&L engine, inventory economics and total landed cost.

Requirement #28 (carrier & shipper P&L), #29 (inventory economics -- a
cheaper/slower shipment trades freight cost for more inventory and working
capital) and #30 (total landed cost -- compare routes on total economic
cost, not freight price alone) all live here because they share the same
underlying idea: freight price is only one line of a much larger economic
ledger, and the "right" route/contract choice depends on the whole ledger.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import List

from scipy.stats import norm

from logistics_strike.analytics.margins import CarrierMargin


# ---------------------------------------------------------------------------
# Carrier-side P&L aggregation (#28)
# ---------------------------------------------------------------------------

@dataclass
class CarrierPnL:
    n_contracts: int
    total_revenue: float
    total_cost: float
    total_profit: float
    average_margin_pct: float


def aggregate_carrier_pnl(margins: List[CarrierMargin]) -> CarrierPnL:
    if not margins:
        return CarrierPnL(0, 0.0, 0.0, 0.0, 0.0)
    revenue = sum(m.revenue for m in margins)
    cost = sum(m.total_cost() for m in margins)
    profit = sum(m.profit for m in margins)
    avg_margin = sum(m.margin_pct() for m in margins) / len(margins)
    return CarrierPnL(len(margins), round(revenue, 2), round(cost, 2), round(profit, 2), round(avg_margin, 4))


# ---------------------------------------------------------------------------
# Shipper-side P&L (#28)
# ---------------------------------------------------------------------------

@dataclass
class ShipperPnL:
    transport_cost: float
    inventory_cost: float
    delay_cost: float
    stockout_cost: float
    contract_premium: float  # e.g. strike premium paid over the naive expected spot

    def total_cost(self) -> float:
        return self.transport_cost + self.inventory_cost + self.delay_cost + self.stockout_cost + self.contract_premium


# ---------------------------------------------------------------------------
# Inventory economics (#29)
# ---------------------------------------------------------------------------

@dataclass
class InventoryEconomics:
    daily_demand_units: float
    demand_std_units: float
    transit_days: float
    transit_std_days: float
    unit_value_usd: float
    holding_cost_rate_annual: float = 0.22  # cost of capital + storage + obsolescence, as a fraction of value/year
    service_level: float = 0.95  # target in-stock probability

    def safety_stock_units(self) -> float:
        """Standard safety-stock formula accounting for uncertainty in both
        demand *and* transit time (the two things a slower/faster/less
        reliable shipment trades off against each other)."""
        z = norm.ppf(self.service_level)
        variance = (
            self.transit_days * self.demand_std_units ** 2
            + self.daily_demand_units ** 2 * self.transit_std_days ** 2
        )
        return z * sqrt(max(0.0, variance))

    def pipeline_inventory_units(self) -> float:
        """Units in transit at any given moment, on average."""
        return self.daily_demand_units * self.transit_days

    def working_capital_usd(self) -> float:
        return (self.pipeline_inventory_units() + self.safety_stock_units()) * self.unit_value_usd

    def carrying_cost_usd_per_day(self) -> float:
        return self.working_capital_usd() * self.holding_cost_rate_annual / 365.0

    def carrying_cost_over_horizon(self, horizon_days: float) -> float:
        return self.carrying_cost_usd_per_day() * horizon_days

    def stockout_probability(self) -> float:
        z = norm.ppf(self.service_level)
        return float(1 - norm.cdf(z))


# ---------------------------------------------------------------------------
# Total landed cost (#30)
# ---------------------------------------------------------------------------

@dataclass
class TotalLandedCost:
    freight: float
    insurance: float
    handling: float
    customs: float
    inventory_carrying_cost: float
    delay_cost: float
    stockout_risk_cost: float

    def total(self) -> float:
        return (
            self.freight + self.insurance + self.handling + self.customs
            + self.inventory_carrying_cost + self.delay_cost + self.stockout_risk_cost
        )

    def as_dict(self) -> dict:
        d = {
            "freight": self.freight,
            "insurance": self.insurance,
            "handling": self.handling,
            "customs": self.customs,
            "inventory_carrying_cost": self.inventory_carrying_cost,
            "delay_cost": self.delay_cost,
            "stockout_risk_cost": self.stockout_risk_cost,
            "total": self.total(),
        }
        return {k: round(v, 2) for k, v in d.items()}


def compute_total_landed_cost(
    freight_price: float,
    declared_value_usd: float,
    inventory: InventoryEconomics,
    horizon_days: float,
    insurance_rate: float = 0.003,
    handling_fee: float = 180.0,
    customs_rate: float = 0.015,
    stockout_cost_per_event: float = 5000.0,
) -> TotalLandedCost:
    insurance = declared_value_usd * insurance_rate
    customs = declared_value_usd * customs_rate
    inventory_cost = inventory.carrying_cost_over_horizon(horizon_days)
    stockout_cost = inventory.stockout_probability() * stockout_cost_per_event
    return TotalLandedCost(
        freight=freight_price,
        insurance=insurance,
        handling=handling_fee,
        customs=customs,
        inventory_carrying_cost=inventory_cost,
        delay_cost=0.0,  # filled in by the caller once actual/expected delay is known
        stockout_risk_cost=stockout_cost,
    )


def compare_routes_by_total_cost(landed_costs: dict) -> str:
    """``landed_costs`` maps a route label to a :class:`TotalLandedCost`.
    Returns the label with the lowest total economic cost -- which, per
    requirement #30, need not be the one with the lowest freight price."""
    return min(landed_costs.items(), key=lambda kv: kv[1].total())[0]
