"""Trader agents.

Traders take directional positions on forward/strike contracts based on
their own (imperfect) forecast of the future spot price versus the market's
quoted strike, tracking realised P&L as contracts settle. This is what
gives the platform's forward/strike curves genuine price discovery rather
than a pure cost-plus calculation -- speculative demand pushes strikes away
from fair value until the edge is arbitraged out.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np


@dataclass
class Position:
    contract_id: str
    corridor_key: str
    direction: str  # "LONG" (bought the strike, benefits if spot rises) or "SHORT"
    volume_units: float
    strike_price: float
    entry_step: int
    realised_pnl: float = 0.0
    closed: bool = False

    def mark_to_market(self, realised_spot: float) -> float:
        payoff_per_unit = (realised_spot - self.strike_price) if self.direction == "LONG" else (self.strike_price - realised_spot)
        return payoff_per_unit * self.volume_units


@dataclass
class TraderAgent:
    id: str
    name: str
    forecast_bias: float = 0.0  # persistent over/under-forecasting tendency, fractional
    forecast_noise: float = 0.05
    risk_limit_units: float = 200.0
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng())
    positions: List[Position] = field(default_factory=list)
    cash_pnl: float = 0.0

    def forecast_future_spot(self, model_expected_future_spot: float) -> float:
        noise = self.rng.normal(self.forecast_bias, self.forecast_noise)
        return model_expected_future_spot * (1.0 + noise)

    def decide_position(
        self,
        contract_id: str,
        corridor_key: str,
        strike_price: float,
        model_expected_future_spot: float,
        max_volume_units: float,
        current_step: int,
        conviction_threshold: float = 0.02,
    ) -> Position | None:
        own_forecast = self.forecast_future_spot(model_expected_future_spot)
        gap = (own_forecast - strike_price) / max(1e-6, strike_price)

        exposure_used = sum(p.volume_units for p in self.positions if not p.closed)
        headroom = max(0.0, self.risk_limit_units - exposure_used)
        if headroom <= 0:
            return None

        if gap > conviction_threshold:
            direction = "LONG"
        elif gap < -conviction_threshold:
            direction = "SHORT"
        else:
            return None

        size = min(headroom, max_volume_units, self.risk_limit_units * min(1.0, abs(gap) * 5))
        if size <= 0:
            return None

        position = Position(
            contract_id=contract_id,
            corridor_key=corridor_key,
            direction=direction,
            volume_units=size,
            strike_price=strike_price,
            entry_step=current_step,
        )
        self.positions.append(position)
        return position

    def settle_position(self, position: Position, realised_spot: float) -> float:
        pnl = position.mark_to_market(realised_spot)
        position.realised_pnl = pnl
        position.closed = True
        self.cash_pnl += pnl
        return pnl

    def total_open_exposure(self) -> float:
        return sum(p.volume_units for p in self.positions if not p.closed)
