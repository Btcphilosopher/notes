"""Broker agents.

Brokers see (a noisy view of) multiple corridors' order books simultaneously
and look for arbitrage: a corridor where the best ask is comfortably below
the best bid net of the broker's own margin, or where a strike price looks
cheap relative to the broker's own forecast of the future spot. Brokers
don't move physical capacity themselves -- they surface/execute the trade
by posting matching orders into both books.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from logistics_strike.markets.order_book import OrderBook


@dataclass
class ArbitrageOpportunity:
    corridor_key: str
    best_bid: float
    best_ask: float
    edge: float  # bid - ask, net of nothing yet
    net_edge: float  # after broker margin


@dataclass
class BrokerAgent:
    id: str
    name: str
    margin_requirement: float = 0.03  # minimum edge (fractional) to act on
    information_noise: float = 0.03
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng())

    def scan_for_arbitrage(self, order_book: OrderBook) -> List[ArbitrageOpportunity]:
        corridor_keys = {o.corridor_key() for o in order_book.open_orders()}
        opportunities = []
        for ck in corridor_keys:
            bid = order_book.best_bid(ck)
            ask = order_book.best_ask(ck)
            if bid is None or ask is None:
                continue
            noisy_bid = bid.limit_price * (1 + self.rng.normal(0, self.information_noise))
            noisy_ask = ask.limit_price * (1 + self.rng.normal(0, self.information_noise))
            edge = noisy_bid - noisy_ask
            net_edge = edge - self.margin_requirement * noisy_ask
            if net_edge > 0:
                opportunities.append(
                    ArbitrageOpportunity(corridor_key=ck, best_bid=noisy_bid, best_ask=noisy_ask, edge=edge, net_edge=net_edge)
                )
        opportunities.sort(key=lambda o: -o.net_edge)
        return opportunities

    def evaluate_strike_vs_forecast(self, strike_price: float, own_forecast_future_spot: float) -> Optional[str]:
        """Simple broker heuristic: recommend BUY_STRIKE if the market's
        strike sits comfortably below the broker's own forecast, SELL_STRIKE
        if comfortably above, else no action."""
        gap = (own_forecast_future_spot - strike_price) / max(1e-6, strike_price)
        if gap > self.margin_requirement:
            return "BUY_STRIKE"
        if gap < -self.margin_requirement:
            return "SELL_STRIKE"
        return None
