"""Shipper agents.

Shippers turn generated demand (:mod:`logistics_strike.agents.demand`) into
buy-side orders. Each shipper has an imperfect, noisy estimate of the "true"
market spot price (not the exact number the pricing engine would compute) --
reflecting requirement #21's "do not give every agent perfect information"
-- and a price sensitivity that determines how aggressively it bids above
or below that estimate.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import List

import numpy as np

from logistics_strike.cargo.shipments import Shipment
from logistics_strike.markets.order_book import Order, OrderSide


@dataclass
class ShipperAgent:
    id: str
    name: str
    price_sensitivity: float = 0.5  # 0 = price-insensitive (pays up), 1 = very sensitive (bids low)
    information_noise: float = 0.08  # std-dev of the shipper's fractional pricing error
    reliability_preference: float = 0.9  # baseline required reliability if the shipment doesn't specify one
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng())

    def perceived_price(self, true_indicative_price: float) -> float:
        noise = self.rng.normal(0, self.information_noise)
        return true_indicative_price * (1.0 + noise)

    def place_order(self, shipment: Shipment, indicative_price: float) -> Order:
        perceived = self.perceived_price(indicative_price)
        # a price-sensitive shipper bids below their perceived fair price;
        # an insensitive one is willing to pay a premium to guarantee capacity
        markup = (0.5 - self.price_sensitivity) * 0.25  # ranges -0.125 (sensitive) .. +0.125 (insensitive)
        limit_price = perceived * (1.0 + markup + 0.15 * shipment.urgency())

        return Order(
            side=OrderSide.BUY,
            participant_id=self.id,
            origin_id=shipment.origin_id,
            destination_id=shipment.destination_id,
            mode="SEA",  # overwritten by caller once a mode/route is chosen
            cargo_units=shipment.cargo.teu_equivalent(),
            execution_window_start=shipment.created_at or shipment.deadline - timedelta(days=30),
            execution_window_end=shipment.deadline,
            limit_price=limit_price,
            min_reliability=shipment.required_reliability or self.reliability_preference,
            created_at=shipment.created_at,
        )

    def react_to_fill_rate(self, fill_rate: float) -> None:
        """Adapt price sensitivity based on how often recent orders filled:
        a shipper that keeps missing capacity becomes less price-sensitive."""
        if fill_rate < 0.5:
            self.price_sensitivity = max(0.0, self.price_sensitivity - 0.05)
        elif fill_rate > 0.9:
            self.price_sensitivity = min(1.0, self.price_sensitivity + 0.02)


DEFAULT_SHIPPERS: List[ShipperAgent] = [
    ShipperAgent("SHIP_GLOBALRETAIL", "Global Retail Group", price_sensitivity=0.6, information_noise=0.06),
    ShipperAgent("SHIP_FASTCOMMERCE", "FastCommerce Inc", price_sensitivity=0.2, information_noise=0.10),
    ShipperAgent("SHIP_INDUSTRIALCO", "Industrial Manufacturing Co", price_sensitivity=0.7, information_noise=0.05),
    ShipperAgent("SHIP_AUTOPARTS", "AutoParts Direct", price_sensitivity=0.35, information_noise=0.09),
]
