"""Demand engine.

Generates freight shipment demand from macro drivers -- a base manufacturing
/retail/e-commerce level, seasonality, an inventory-cycle oscillation, and
an economic-growth trend -- varying by region, commodity (cargo type) and
transport mode. Occasional named "events" (a product launch, a promotional
peak) can be layered on top by the scenario engine.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

import numpy as np

from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.cargo.shipments import Shipment, ShipmentPriority
from logistics_strike.core.state import TransportMode


@dataclass
class DemandLane:
    """A directed origin->destination lane with its own baseline volume."""

    origin_id: str
    destination_id: str
    mode: TransportMode
    base_shipments_per_day: float
    cargo_mix: Dict[CargoType, float]  # probabilities, should sum to ~1
    seasonal_peak_months: Tuple[int, ...] = (9, 10)
    seasonal_multiplier: float = 1.4
    growth_per_year: float = 0.02


@dataclass
class DemandEngine:
    lanes: List[DemandLane] = field(default_factory=list)
    rng: np.random.Generator = field(default_factory=lambda: np.random.default_rng(101))
    inventory_cycle_period_days: float = 45.0
    inventory_cycle_amplitude: float = 0.12
    _day_index: int = 0

    def _seasonal_factor(self, lane: DemandLane, when: datetime) -> float:
        return lane.seasonal_multiplier if when.month in lane.seasonal_peak_months else 1.0

    def _inventory_cycle_factor(self) -> float:
        phase = 2 * np.pi * self._day_index / self.inventory_cycle_period_days
        return 1.0 + self.inventory_cycle_amplitude * np.sin(phase)

    def _growth_factor(self, lane: DemandLane, days_elapsed: int) -> float:
        return (1.0 + lane.growth_per_year) ** (days_elapsed / 365.0)

    def generate(self, when: datetime, days_elapsed: int = 0) -> List[Shipment]:
        shipments: List[Shipment] = []
        for lane in self.lanes:
            expected = (
                lane.base_shipments_per_day
                * self._seasonal_factor(lane, when)
                * self._inventory_cycle_factor()
                * self._growth_factor(lane, days_elapsed)
            )
            n = self.rng.poisson(max(0.0, expected))
            cargo_types = list(lane.cargo_mix.keys())
            probs = np.array(list(lane.cargo_mix.values()))
            probs = probs / probs.sum()

            priorities = list(ShipmentPriority)
            for _ in range(n):
                # index-based choice: numpy's Generator.choice on a list of
                # str-subclassed Enum members stringifies them (via the str
                # MRO) rather than preserving the Enum objects, so we select
                # an index into the plain Python list instead.
                cargo_type = cargo_types[int(self.rng.choice(len(cargo_types), p=probs))]
                weight = float(self.rng.uniform(1000, 26000))
                volume = float(self.rng.uniform(5, 65))
                value = float(self.rng.uniform(8000, 220000))
                priority = priorities[int(self.rng.choice(len(priorities), p=[0.35, 0.40, 0.18, 0.07]))]
                deadline_days = float(self.rng.uniform(10, 60))
                cargo = CargoSpec(
                    cargo_type=cargo_type,
                    weight_kg=weight,
                    volume_m3=volume,
                    declared_value_usd=value,
                    requires_temperature_control=(cargo_type == CargoType.REEFER),
                )
                shipments.append(
                    Shipment(
                        origin_id=lane.origin_id,
                        destination_id=lane.destination_id,
                        cargo=cargo,
                        deadline=when + timedelta(days=deadline_days),
                        priority=priority,
                        required_reliability=float(self.rng.uniform(0.80, 0.98)),
                        created_at=when,
                    )
                )
        self._day_index += 1
        return shipments
