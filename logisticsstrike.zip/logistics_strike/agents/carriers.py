"""Carrier (sell-side) agents.

Wraps a physical carrier's capacity pool with pricing behaviour: quotes SELL
orders at marginal cost plus a margin that rises with utilisation (yield
management), and adapts that margin based on realised profitability and
utilisation each period -- carriers do not know shipper's true willingness
to pay, only their own fill rate and margin history.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List

from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.markets.order_book import Order, OrderSide


@dataclass
class CarrierAgent:
    id: str
    name: str
    capacity_pool: CapacityPool
    target_margin: float = 0.15
    min_margin: float = 0.02
    max_margin: float = 0.55
    risk_appetite: float = 0.5  # 0 = conservative (avoids under-pricing risk), 1 = aggressive

    def quote_price(self) -> float:
        utilisation = self.capacity_pool.utilisation()
        # yield-management curve: margin rises convexly as the pool fills
        dynamic_margin = self.target_margin + (self.max_margin - self.target_margin) * utilisation ** 2
        dynamic_margin = max(self.min_margin, min(self.max_margin, dynamic_margin))
        return self.capacity_pool.marginal_cost_per_unit * (1.0 + dynamic_margin)

    def offer_capacity(
        self, origin_id: str, destination_id: str, mode: str, when: datetime, window_days: float = 21
    ) -> Order:
        price = self.quote_price()
        self.capacity_pool.revenue_potential_per_unit = price
        return Order(
            side=OrderSide.SELL,
            participant_id=self.id,
            origin_id=origin_id,
            destination_id=destination_id,
            mode=mode,
            cargo_units=self.capacity_pool.available(),
            execution_window_start=when,
            execution_window_end=when + timedelta(days=window_days),
            limit_price=price,
            created_at=when,
        )

    def react_to_utilisation(self) -> None:
        """Chase a target utilisation band: too empty -> cut margin to fill
        capacity; too full -> raise margin to capture scarcity value."""
        u = self.capacity_pool.utilisation()
        if u < 0.55:
            self.target_margin = max(self.min_margin, self.target_margin - 0.01)
        elif u > 0.88:
            self.target_margin = min(self.max_margin, self.target_margin + 0.02 * self.risk_appetite + 0.01)


def make_carrier_agents(capacity_pools: List[CapacityPool]) -> List[CarrierAgent]:
    return [
        CarrierAgent(id=f"CARR_{pool.id}", name=pool.id, capacity_pool=pool)
        for pool in capacity_pools
    ]
