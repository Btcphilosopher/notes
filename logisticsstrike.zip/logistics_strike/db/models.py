"""Persistent state: SQLAlchemy ORM models.

Targets PostgreSQL in production (see ``db/session.py`` and
``docker-compose.yml`` for a local Postgres instance), but every model here
is plain SQLAlchemy Core-compatible types so the same schema also runs
against SQLite for tests/CI without a live database. Every pricing result
table carries ``model_version``, ``inputs``, ``parameters``, ``timestamp``
and ``scenario`` columns (requirement #33's closing line) so a stored
price is always reproducible and auditable.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, relationship

MODEL_VERSION = "0.1.0"


class Base(DeclarativeBase):
    pass


class TimestampedPricingMixin:
    """Common auditability columns shared by every pricing-result table."""

    model_version = Column(String(32), nullable=False, default=MODEL_VERSION)
    inputs = Column(JSON, nullable=False, default=dict)
    parameters = Column(JSON, nullable=False, default=dict)
    timestamp = Column(DateTime, nullable=False, default=datetime.utcnow)
    scenario = Column(String(64), nullable=False, default="baseline")


class Location(Base):
    __tablename__ = "locations"
    id = Column(String(16), primary_key=True)
    name = Column(String(128), nullable=False)
    node_type = Column(String(32), nullable=False)
    region = Column(String(32), nullable=False)
    country = Column(String(8), nullable=False)
    lat = Column(Float, nullable=False)
    lon = Column(Float, nullable=False)
    attributes = Column(JSON, default=dict)


class Port(Base):
    __tablename__ = "ports"
    id = Column(String(16), ForeignKey("locations.id"), primary_key=True)
    berths = Column(Integer, nullable=False)
    cranes_per_berth = Column(Integer, nullable=False)
    yard_capacity_teu = Column(Integer, nullable=False)
    vessel_queue = Column(Integer, default=0)
    yard_utilisation = Column(Float, default=0.0)


class Airport(Base):
    __tablename__ = "airports"
    id = Column(String(16), ForeignKey("locations.id"), primary_key=True)
    runway_slots_per_day = Column(Integer, nullable=False)
    cargo_terminal_capacity_tonnes_per_day = Column(Float, nullable=False)
    slot_utilisation = Column(Float, default=0.0)


class RailNode(Base):
    __tablename__ = "rail_nodes"
    id = Column(String(16), ForeignKey("locations.id"), primary_key=True)
    daily_wagon_slots = Column(Integer, nullable=False)
    slot_utilisation = Column(Float, default=0.0)


class Road(Base):
    __tablename__ = "roads"
    id = Column(String(32), primary_key=True)
    origin_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    destination_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    length_km = Column(Float, nullable=False)
    lanes = Column(Integer, nullable=False)
    capacity_daily_traffic = Column(Float, nullable=False)


class Carrier(Base):
    __tablename__ = "carriers"
    id = Column(String(32), primary_key=True)
    name = Column(String(128), nullable=False)
    carrier_type = Column(String(16), nullable=False)  # SHIPPING/AIRLINE/RAIL/TRUCKING
    reliability_rating = Column(Float, default=0.9)
    cost_efficiency = Column(Float, default=1.0)


class Capacity(Base):
    __tablename__ = "capacity"
    id = Column(String(64), primary_key=True)
    carrier_id = Column(String(32), ForeignKey("carriers.id"), nullable=True)
    mode = Column(String(16), nullable=False)
    unit = Column(String(16), nullable=False)
    total_capacity = Column(Float, nullable=False)
    allocated_capacity = Column(Float, default=0.0)
    period_days = Column(Float, default=7.0)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Shipment(Base):
    __tablename__ = "shipments"
    id = Column(String(16), primary_key=True)
    origin_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    destination_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    cargo_type = Column(String(24), nullable=False)
    weight_kg = Column(Float, nullable=False)
    volume_m3 = Column(Float, nullable=False)
    declared_value_usd = Column(Float, nullable=False)
    deadline = Column(DateTime, nullable=False)
    priority = Column(String(16), nullable=False)
    required_reliability = Column(Float, nullable=False)
    status = Column(String(16), nullable=False, default="PENDING")
    created_at = Column(DateTime, default=datetime.utcnow)


class Route(Base):
    __tablename__ = "routes"
    id = Column(String(32), primary_key=True)
    origin_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    destination_id = Column(String(16), ForeignKey("locations.id"), nullable=False)
    mode_sequence = Column(String(64), nullable=False)
    edge_keys = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class SpotPrice(TimestampedPricingMixin, Base):
    __tablename__ = "spot_prices"
    id = Column(Integer, primary_key=True, autoincrement=True)
    corridor_key = Column(String(64), nullable=False, index=True)
    mode = Column(String(16), nullable=False)
    price = Column(Float, nullable=False)
    expected_transit_days = Column(Float, nullable=False)
    transit_std_days = Column(Float, nullable=False)
    reliability = Column(Float, nullable=False)
    components = Column(JSON, nullable=False)


class ForwardCurvePoint(TimestampedPricingMixin, Base):
    __tablename__ = "forward_curves"
    id = Column(Integer, primary_key=True, autoincrement=True)
    corridor_key = Column(String(64), nullable=False, index=True)
    mode = Column(String(16), nullable=False)
    tenor = Column(String(16), nullable=False)
    horizon_date = Column(DateTime, nullable=False)
    expected_spot = Column(Float, nullable=False)
    forward_price = Column(Float, nullable=False)
    volatility_annualised = Column(Float, nullable=False)
    ci_low = Column(Float, nullable=False)
    ci_high = Column(Float, nullable=False)


class StrikePrice(TimestampedPricingMixin, Base):
    __tablename__ = "strike_prices"
    id = Column(Integer, primary_key=True, autoincrement=True)
    corridor_key = Column(String(64), nullable=False, index=True)
    mode = Column(String(16), nullable=False)
    strike_price = Column(Float, nullable=False)
    current_spot = Column(Float, nullable=False)
    required_reliability = Column(Float, nullable=False)
    baseline_reliability = Column(Float, nullable=False)
    components = Column(JSON, nullable=False)
    execution_window_start = Column(DateTime, nullable=False)
    execution_window_end = Column(DateTime, nullable=False)


class Contract(Base):
    __tablename__ = "contracts"
    id = Column(String(16), primary_key=True)
    contract_type = Column(String(24), nullable=False)
    buyer_id = Column(String(32), nullable=False)
    seller_id = Column(String(32), nullable=False)
    origin_id = Column(String(16), nullable=False)
    destination_id = Column(String(16), nullable=False)
    mode = Column(String(16), nullable=False)
    price = Column(Float, nullable=False)
    volume_units = Column(Float, nullable=False)
    execution_window_start = Column(DateTime, nullable=False)
    execution_window_end = Column(DateTime, nullable=False)
    status = Column(String(16), nullable=False, default="PENDING")
    shipment_id = Column(String(16), ForeignKey("shipments.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Order(Base):
    __tablename__ = "orders"
    id = Column(String(16), primary_key=True)
    side = Column(String(4), nullable=False)
    participant_id = Column(String(32), nullable=False)
    origin_id = Column(String(16), nullable=False)
    destination_id = Column(String(16), nullable=False)
    mode = Column(String(16), nullable=False)
    cargo_units = Column(Float, nullable=False)
    limit_price = Column(Float, nullable=False)
    min_reliability = Column(Float, default=0.85)
    status = Column(String(16), default="OPEN")
    filled_units = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class Trade(Base):
    __tablename__ = "trades"
    id = Column(String(16), primary_key=True)
    buy_order_id = Column(String(16), ForeignKey("orders.id"), nullable=False)
    sell_order_id = Column(String(16), ForeignKey("orders.id"), nullable=False)
    matched_units = Column(Float, nullable=False)
    matched_price = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class SimEvent(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_type = Column(String(48), nullable=False, index=True)
    source = Column(String(48))
    payload_repr = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)


class FuelPrice(Base):
    __tablename__ = "fuel_prices"
    id = Column(Integer, primary_key=True, autoincrement=True)
    fuel_type = Column(String(24), nullable=False, index=True)
    price = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Congestion(Base):
    __tablename__ = "congestion"
    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(String(16), nullable=False, index=True)
    score = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Weather(Base):
    __tablename__ = "weather"
    id = Column(Integer, primary_key=True, autoincrement=True)
    region = Column(String(32), nullable=False, index=True)
    severity = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Scenario(Base):
    __tablename__ = "scenarios"
    id = Column(String(48), primary_key=True)
    scenario_type = Column(String(32), nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class RiskResult(Base):
    __tablename__ = "risk_results"
    id = Column(Integer, primary_key=True, autoincrement=True)
    corridor_key = Column(String(64), nullable=False, index=True)
    var = Column(Float, nullable=False)
    cvar = Column(Float, nullable=False)
    expected_loss = Column(Float, nullable=False)
    deadline_failure_probability = Column(Float, nullable=False)
    confidence = Column(Float, nullable=False)
    scenario = Column(String(64), default="baseline")
    timestamp = Column(DateTime, default=datetime.utcnow)
