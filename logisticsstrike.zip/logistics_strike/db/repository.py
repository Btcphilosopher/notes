"""Persistence helpers: turn in-memory pricing results into DB rows.

Every write here stamps ``model_version``, ``inputs``, ``parameters``,
``timestamp`` and ``scenario`` so a stored spot/strike/forward price is
always fully reproducible -- the point of requirement #33's closing
sentence ("Every pricing result should record...").
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, Optional

from sqlalchemy.orm import Session

from logistics_strike.db import models
from logistics_strike.pricing.forward import ForwardCurve
from logistics_strike.pricing.spot import SpotPriceResult
from logistics_strike.pricing.strike import StrikeResult


def save_spot_price(
    session: Session,
    result: SpotPriceResult,
    corridor_key: str,
    scenario: str = "baseline",
    inputs: Optional[Dict] = None,
    parameters: Optional[Dict] = None,
) -> models.SpotPrice:
    row = models.SpotPrice(
        corridor_key=corridor_key,
        mode=result.mode.value,
        price=result.price,
        expected_transit_days=result.expected_transit_days,
        transit_std_days=result.transit_std_days,
        reliability=result.reliability,
        components=result.components.as_dict(),
        inputs=inputs or {"shipment_id": result.shipment_id},
        parameters=parameters or {},
        scenario=scenario,
        timestamp=datetime.utcnow(),
    )
    session.add(row)
    return row


def save_forward_curve(
    session: Session,
    curve: ForwardCurve,
    scenario: str = "baseline",
    parameters: Optional[Dict] = None,
) -> list[models.ForwardCurvePoint]:
    rows = []
    for point in curve.points:
        row = models.ForwardCurvePoint(
            corridor_key=curve.corridor_id,
            mode=curve.mode,
            tenor=point.tenor.value,
            horizon_date=point.horizon_date,
            expected_spot=point.expected_spot,
            forward_price=point.forward_price,
            volatility_annualised=point.volatility_annualised,
            ci_low=point.ci_low,
            ci_high=point.ci_high,
            inputs={"current_spot": curve.current_spot},
            parameters=parameters or {},
            scenario=scenario,
            timestamp=curve.as_of,
        )
        session.add(row)
        rows.append(row)
    return rows


def save_strike_price(
    session: Session,
    result: StrikeResult,
    scenario: str = "baseline",
    parameters: Optional[Dict] = None,
) -> models.StrikePrice:
    row = models.StrikePrice(
        corridor_key=result.corridor_id,
        mode=result.mode,
        strike_price=result.strike_price,
        current_spot=result.current_spot,
        required_reliability=result.required_reliability,
        baseline_reliability=result.baseline_reliability,
        components=result.components.as_dict(),
        execution_window_start=result.execution_window_start,
        execution_window_end=result.execution_window_end,
        inputs={},
        parameters=parameters or {},
        scenario=scenario,
        timestamp=datetime.utcnow(),
    )
    session.add(row)
    return row
