"""Database session management.

Reads ``DATABASE_URL`` from the environment. In production this should
point at PostgreSQL (see ``docker-compose.yml`` for a local instance and
``.env.example`` for the expected connection string shape); it defaults to
a local SQLite file so the platform and its test suite run with zero
external setup.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from logistics_strike.db.models import Base

DEFAULT_SQLITE_URL = "sqlite:///./logistics_strike.db"


def get_database_url() -> str:
    return os.environ.get("DATABASE_URL", DEFAULT_SQLITE_URL)


def make_engine(url: str | None = None):
    url = url or get_database_url()
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    return create_engine(url, connect_args=connect_args, future=True)


_engine = None
_SessionLocal = None


def init_db(url: str | None = None, create_tables: bool = True):
    global _engine, _SessionLocal
    _engine = make_engine(url)
    _SessionLocal = sessionmaker(bind=_engine, autoflush=False, autocommit=False, future=True)
    if create_tables:
        Base.metadata.create_all(_engine)
    return _engine


def get_engine():
    if _engine is None:
        init_db()
    return _engine


@contextmanager
def session_scope() -> Iterator[Session]:
    if _SessionLocal is None:
        init_db()
    session: Session = _SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
