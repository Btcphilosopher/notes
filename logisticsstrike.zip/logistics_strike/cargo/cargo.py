"""Cargo type taxonomy and physical specification."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class CargoType(str, Enum):
    PARCEL = "PARCEL"
    PALLET = "PALLET"
    LCL = "LCL"
    CONTAINER_20FT = "CONTAINER_20FT"
    CONTAINER_40FT = "CONTAINER_40FT"
    REEFER = "REEFER"
    BULK = "BULK"
    HIGH_VALUE = "HIGH_VALUE"
    HAZARDOUS = "HAZARDOUS"


# relative handling-cost multiplier and default TEU-equivalent footprint
CARGO_PROFILE: dict[CargoType, dict[str, float]] = {
    CargoType.PARCEL: {"teu_equiv": 0.02, "handling_multiplier": 1.4},
    CargoType.PALLET: {"teu_equiv": 0.05, "handling_multiplier": 1.15},
    CargoType.LCL: {"teu_equiv": 0.30, "handling_multiplier": 1.25},
    CargoType.CONTAINER_20FT: {"teu_equiv": 1.0, "handling_multiplier": 1.0},
    CargoType.CONTAINER_40FT: {"teu_equiv": 2.0, "handling_multiplier": 1.0},
    CargoType.REEFER: {"teu_equiv": 2.0, "handling_multiplier": 1.6},
    CargoType.BULK: {"teu_equiv": 1.5, "handling_multiplier": 0.7},
    CargoType.HIGH_VALUE: {"teu_equiv": 1.0, "handling_multiplier": 1.5},
    CargoType.HAZARDOUS: {"teu_equiv": 1.0, "handling_multiplier": 1.8},
}


@dataclass
class CargoSpec:
    cargo_type: CargoType
    weight_kg: float
    volume_m3: float
    declared_value_usd: float
    requires_temperature_control: bool = False
    min_temp_c: float | None = None
    max_temp_c: float | None = None
    hazard_class: str | None = None
    fragile: bool = False

    def handling_multiplier(self) -> float:
        m = CARGO_PROFILE[self.cargo_type]["handling_multiplier"]
        if self.fragile:
            m *= 1.1
        if self.requires_temperature_control and self.cargo_type != CargoType.REEFER:
            m *= 1.3
        return m

    def teu_equivalent(self) -> float:
        return CARGO_PROFILE[self.cargo_type]["teu_equiv"]
