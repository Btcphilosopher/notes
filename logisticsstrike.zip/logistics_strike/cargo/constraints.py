"""Handling / compatibility constraints used to validate a shipment against a
candidate route or capacity unit before it can be matched or routed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.core.state import TransportMode


@dataclass
class ConstraintViolation:
    code: str
    message: str


# cargo types that cannot legally/physically move by air in bulk, or at all
AIR_PROHIBITED = {CargoType.BULK}
# cargo types that require temperature-controlled equipment
TEMP_CONTROLLED_TYPES = {CargoType.REEFER}


def validate_cargo_for_mode(cargo: CargoSpec, mode: TransportMode) -> List[ConstraintViolation]:
    violations: List[ConstraintViolation] = []

    if mode == TransportMode.AIR and cargo.cargo_type in AIR_PROHIBITED:
        violations.append(
            ConstraintViolation("MODE_INCOMPATIBLE", f"{cargo.cargo_type.value} cannot move by AIR")
        )

    if cargo.requires_temperature_control and cargo.cargo_type not in TEMP_CONTROLLED_TYPES:
        violations.append(
            ConstraintViolation(
                "TEMP_EQUIPMENT_REQUIRED",
                "Temperature-controlled cargo declared without reefer equipment",
            )
        )

    if cargo.hazard_class and mode == TransportMode.AIR:
        violations.append(
            ConstraintViolation("HAZMAT_AIR_RESTRICTED", f"Hazard class {cargo.hazard_class} restricted on AIR")
        )

    if cargo.weight_kg <= 0 or cargo.volume_m3 <= 0:
        violations.append(ConstraintViolation("INVALID_DIMENSIONS", "Weight and volume must be positive"))

    return violations


def is_feasible(cargo: CargoSpec, mode: TransportMode) -> bool:
    return len(validate_cargo_for_mode(cargo, mode)) == 0
