"""Shipment: a customer's request to move cargo from A to B under stated
requirements. This is the unit that spot/strike pricing, routing and
matching all operate on.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

from logistics_strike.cargo.cargo import CargoSpec

_id_counter = itertools.count(1)


class ShipmentPriority(str, Enum):
    ECONOMY = "ECONOMY"
    STANDARD = "STANDARD"
    EXPRESS = "EXPRESS"
    CRITICAL = "CRITICAL"


class ShipmentStatus(str, Enum):
    PENDING = "PENDING"
    QUOTED = "QUOTED"
    BOOKED = "BOOKED"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED = "DELIVERED"
    DELAYED = "DELAYED"
    CANCELLED = "CANCELLED"


PRIORITY_URGENCY: dict[ShipmentPriority, float] = {
    ShipmentPriority.ECONOMY: 0.0,
    ShipmentPriority.STANDARD: 0.15,
    ShipmentPriority.EXPRESS: 0.45,
    ShipmentPriority.CRITICAL: 0.85,
}


@dataclass
class Shipment:
    origin_id: str
    destination_id: str
    cargo: CargoSpec
    deadline: datetime
    priority: ShipmentPriority = ShipmentPriority.STANDARD
    required_reliability: float = 0.90  # minimum acceptable P(on-time)
    created_at: Optional[datetime] = None
    id: str = field(default_factory=lambda: f"SHP-{next(_id_counter):07d}")
    status: ShipmentStatus = ShipmentStatus.PENDING
    shipper_id: Optional[str] = None
    assigned_route_id: Optional[str] = None
    assigned_contract_id: Optional[str] = None
    actual_delivery: Optional[datetime] = None

    def urgency(self) -> float:
        return PRIORITY_URGENCY[self.priority]

    def days_to_deadline(self, now: datetime) -> float:
        return (self.deadline - now).total_seconds() / 86400.0

    def is_overdue(self, now: datetime) -> bool:
        return self.status not in (ShipmentStatus.DELIVERED, ShipmentStatus.CANCELLED) and now > self.deadline
