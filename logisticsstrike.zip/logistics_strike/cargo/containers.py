"""Physical container types and instances."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ContainerType(str, Enum):
    DRY_20FT = "DRY_20FT"
    DRY_40FT = "DRY_40FT"
    DRY_40FT_HC = "DRY_40FT_HC"
    REEFER_20FT = "REEFER_20FT"
    REEFER_40FT = "REEFER_40FT"
    OPEN_TOP = "OPEN_TOP"
    FLAT_RACK = "FLAT_RACK"


CONTAINER_SPECS: dict[ContainerType, dict[str, float]] = {
    ContainerType.DRY_20FT: {"teu": 1.0, "max_payload_kg": 28_200, "volume_m3": 33.2},
    ContainerType.DRY_40FT: {"teu": 2.0, "max_payload_kg": 28_800, "volume_m3": 67.7},
    ContainerType.DRY_40FT_HC: {"teu": 2.0, "max_payload_kg": 28_600, "volume_m3": 76.4},
    ContainerType.REEFER_20FT: {"teu": 1.0, "max_payload_kg": 27_400, "volume_m3": 28.3},
    ContainerType.REEFER_40FT: {"teu": 2.0, "max_payload_kg": 29_000, "volume_m3": 59.3},
    ContainerType.OPEN_TOP: {"teu": 2.0, "max_payload_kg": 28_100, "volume_m3": 65.0},
    ContainerType.FLAT_RACK: {"teu": 2.0, "max_payload_kg": 39_500, "volume_m3": 0.0},
}


@dataclass
class Container:
    id: str
    container_type: ContainerType
    owner_carrier_id: str
    current_location_id: str | None = None
    payload_kg: float = 0.0
    is_laden: bool = False

    def max_payload_kg(self) -> float:
        return CONTAINER_SPECS[self.container_type]["max_payload_kg"]

    def volume_m3(self) -> float:
        return CONTAINER_SPECS[self.container_type]["volume_m3"]

    def teu(self) -> float:
        return CONTAINER_SPECS[self.container_type]["teu"]

    def is_overloaded(self) -> bool:
        return self.payload_kg > self.max_payload_kg()
