"""Top-level simulation driver.

Thin wrapper over :class:`~logistics_strike.core.engine.Engine` that runs a
fixed number of timesteps and collects the per-step metrics snapshot engine
already produces, so callers (CLI, API, notebooks, tests) don't need to know
about the internal loop mechanics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from logistics_strike.core.engine import Engine


@dataclass
class Simulation:
    engine: Engine
    history: List[Dict] = field(default_factory=list)

    def run(self, n_steps: int, on_step: Optional[Callable[[int, Dict], None]] = None) -> List[Dict]:
        for _ in range(n_steps):
            snapshot = self.engine.step()
            self.history.append(snapshot)
            if on_step:
                on_step(self.engine.clock.step_index, snapshot)
        return self.history

    def latest(self) -> Optional[Dict]:
        return self.history[-1] if self.history else None

    def reset(self) -> None:
        self.history.clear()
        self.engine.clock.reset()
