"""Global state registry and the shared vocabulary of enums used across every
subsystem.

``GlobalState`` is a plain in-memory registry (not an ORM model) that the
:class:`~logistics_strike.core.engine.Engine` mutates each timestep. It is
intentionally dumb -- it holds references to the graph, capacity pools,
shipments, orders, contracts and the latest pricing results so that any
subsystem can read the current world without threading a dozen parameters
through every function call.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List

if TYPE_CHECKING:
    from logistics_strike.network.multimodal_graph import MultimodalGraph
    from logistics_strike.markets.order_book import OrderBook


class TransportMode(str, Enum):
    SEA = "SEA"
    AIR = "AIR"
    RAIL = "RAIL"
    ROAD = "ROAD"
    MULTIMODAL = "MULTIMODAL"


class NodeType(str, Enum):
    PORT = "PORT"
    AIRPORT = "AIRPORT"
    RAIL_TERMINAL = "RAIL_TERMINAL"
    TRUCK_DEPOT = "TRUCK_DEPOT"
    WAREHOUSE = "WAREHOUSE"
    DISTRIBUTION_CENTRE = "DISTRIBUTION_CENTRE"
    BORDER_CROSSING = "BORDER_CROSSING"
    HUB = "HUB"


class Region(str, Enum):
    NORTH_ASIA = "NORTH_ASIA"
    SOUTHEAST_ASIA = "SOUTHEAST_ASIA"
    SOUTH_ASIA = "SOUTH_ASIA"
    NORTH_EUROPE = "NORTH_EUROPE"
    MEDITERRANEAN = "MEDITERRANEAN"
    NORTH_AMERICA_EAST = "NORTH_AMERICA_EAST"
    NORTH_AMERICA_WEST = "NORTH_AMERICA_WEST"
    MIDDLE_EAST = "MIDDLE_EAST"
    LATIN_AMERICA = "LATIN_AMERICA"
    AFRICA = "AFRICA"
    OCEANIA = "OCEANIA"


@dataclass
class GlobalState:
    """Mutable snapshot of everything the simulation knows right now."""

    graph: "MultimodalGraph | None" = None
    order_book: "OrderBook | None" = None

    # registries keyed by id
    carriers: Dict[str, Any] = field(default_factory=dict)
    capacity_pools: Dict[str, Any] = field(default_factory=dict)
    shipments: Dict[str, Any] = field(default_factory=dict)
    contracts: Dict[str, Any] = field(default_factory=dict)

    # latest pricing surfaces, keyed by corridor id ("PORT_A->PORT_B", mode)
    spot_prices: Dict[str, Any] = field(default_factory=dict)
    forward_curves: Dict[str, Any] = field(default_factory=dict)
    strike_prices: Dict[str, Any] = field(default_factory=dict)

    # market conditions
    fuel_prices: Dict[str, float] = field(default_factory=dict)
    congestion: Dict[str, float] = field(default_factory=dict)
    weather: Dict[str, Any] = field(default_factory=dict)
    active_disruptions: Dict[str, Any] = field(default_factory=dict)

    # analytics outputs
    indices: Dict[str, Any] = field(default_factory=dict)
    risk_results: Dict[str, Any] = field(default_factory=dict)
    pnl: Dict[str, Any] = field(default_factory=dict)

    # bookkeeping
    scenario: str = "baseline"
    metrics_history: List[Dict[str, Any]] = field(default_factory=list)

    def corridor_key(self, origin: str, destination: str, mode: TransportMode) -> str:
        return f"{origin}->{destination}:{mode.value}"
