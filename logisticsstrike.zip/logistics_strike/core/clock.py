"""Simulation clock.

The whole platform advances in discrete timesteps. ``SimClock`` is the single
source of truth for "what time is it in the simulation" and is threaded
through every subsystem so that pricing, congestion, and risk calculations
are always evaluated as of a consistent instant.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta


@dataclass
class SimClock:
    """Discrete-step simulation clock.

    Parameters
    ----------
    start:
        Wall-clock instant the simulation begins at.
    step_size:
        Duration advanced by each call to :meth:`tick`.
    """

    start: datetime = field(default_factory=lambda: datetime(2026, 1, 1))
    step_size: timedelta = field(default_factory=lambda: timedelta(days=1))
    _now: datetime = field(init=False, repr=False)
    _step_index: int = field(init=False, default=0, repr=False)

    def __post_init__(self) -> None:
        self._now = self.start

    @property
    def now(self) -> datetime:
        return self._now

    @property
    def step_index(self) -> int:
        return self._step_index

    def tick(self) -> datetime:
        """Advance the clock by one step and return the new time."""
        self._now = self._now + self.step_size
        self._step_index += 1
        return self._now

    def horizon(self, n_steps: int) -> datetime:
        """Return the timestamp ``n_steps`` into the future without advancing."""
        return self._now + self.step_size * n_steps

    def days_between(self, other: datetime) -> float:
        return (other - self._now).total_seconds() / 86400.0

    def reset(self) -> None:
        self._now = self.start
        self._step_index = 0

    def __str__(self) -> str:  # pragma: no cover - convenience only
        return f"t={self._step_index} ({self._now.isoformat()})"
