"""Lightweight in-process event bus.

Subsystems publish events (a disruption fired, a contract settled, a match
occurred) and other subsystems -- notably analytics and the market feedback
loop -- subscribe to react to them. Kept intentionally simple: synchronous,
in-memory, no external broker. This is what closes the
``MARKET FEEDBACK -> GLOBAL LOGISTICS STATE`` loop described in the platform
design.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, DefaultDict, List


class EventType(str, Enum):
    DEMAND_GENERATED = "demand_generated"
    CAPACITY_UPDATED = "capacity_updated"
    WEATHER_UPDATED = "weather_updated"
    FUEL_UPDATED = "fuel_updated"
    CONGESTION_UPDATED = "congestion_updated"
    SPOT_PRICED = "spot_priced"
    FORWARD_UPDATED = "forward_updated"
    STRIKE_PRICED = "strike_priced"
    ORDER_SUBMITTED = "order_submitted"
    ORDER_MATCHED = "order_matched"
    ROUTE_OPTIMISED = "route_optimised"
    TRANSIT_STARTED = "transit_started"
    TRANSIT_COMPLETED = "transit_completed"
    DISRUPTION_TRIGGERED = "disruption_triggered"
    DISRUPTION_RESOLVED = "disruption_resolved"
    CONTRACT_CREATED = "contract_created"
    CONTRACT_SETTLED = "contract_settled"
    CONTRACT_BREACHED = "contract_breached"
    METRICS_RECORDED = "metrics_recorded"


@dataclass
class Event:
    type: EventType
    payload: Any
    timestamp: datetime
    source: str = ""


Handler = Callable[[Event], None]


@dataclass
class EventBus:
    _subscribers: DefaultDict[EventType, List[Handler]] = field(
        default_factory=lambda: defaultdict(list)
    )
    _history: List[Event] = field(default_factory=list)
    record_history: bool = True

    def subscribe(self, event_type: EventType, handler: Handler) -> None:
        self._subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: EventType, handler: Handler) -> None:
        if handler in self._subscribers[event_type]:
            self._subscribers[event_type].remove(handler)

    def publish(self, event: Event) -> None:
        if self.record_history:
            self._history.append(event)
        for handler in list(self._subscribers.get(event.type, [])):
            handler(event)

    def emit(self, type: EventType, payload: Any, timestamp: datetime, source: str = "") -> None:
        self.publish(Event(type=type, payload=payload, timestamp=timestamp, source=source))

    def history(self, event_type: EventType | None = None) -> List[Event]:
        if event_type is None:
            return list(self._history)
        return [e for e in self._history if e.type == event_type]

    def clear_history(self) -> None:
        self._history.clear()
