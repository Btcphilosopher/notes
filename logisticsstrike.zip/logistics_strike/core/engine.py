"""The simulation engine: wires every subsystem together and executes the
platform's fundamental loop, one timestep at a time.

    GLOBAL LOGISTICS STATE -> CAPACITY -> DEMAND -> ROUTING -> SPOT PRICE
        -> FORWARD EXPECTATIONS -> STRIKE PRICE -> CONTRACT/ALLOCATION
        -> ACTUAL EXECUTION -> MARKET FEEDBACK

which is realised concretely as::

    generate_freight_demand()
    update_global_capacity()
    update_weather()
    update_fuel_prices()
    update_port_and_network_congestion()
    calculate_spot_prices()
    update_forward_expectations()
    calculate_strike_prices()
    update_order_books()
    match_capacity()
    optimise_routes()
    simulate_transit()
    apply_disruptions()
    settle_contracts()
    update_market_state()
    record_metrics()

Construction is intentionally verbose (every subsystem is passed in
explicitly) rather than hiding it behind defaults, so a caller can swap any
one piece -- a different volatility model, a different route engine -- and
see exactly what it plugs into. :mod:`logistics_strike.simulation.world`
provides a convenience builder (`build_default_world`) that assembles a
ready-to-run ``Engine`` with a plausible starter dataset.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Dict, List, Optional, Tuple

from logistics_strike.agents.brokers import BrokerAgent
from logistics_strike.agents.carriers import CarrierAgent
from logistics_strike.agents.demand import DemandEngine
from logistics_strike.agents.shippers import ShipperAgent
from logistics_strike.agents.traders import TraderAgent
from logistics_strike.cargo.cargo import CargoSpec, CargoType
from logistics_strike.cargo.shipments import Shipment, ShipmentStatus
from logistics_strike.carriers.capacity import CapacityPool
from logistics_strike.contracts.freight_contract import ContractStatus
from logistics_strike.contracts.settlement import SettlementEngine
from logistics_strike.core.clock import SimClock
from logistics_strike.core.events import Event, EventBus, EventType
from logistics_strike.core.state import GlobalState, TransportMode
from logistics_strike.network.multimodal_graph import MultimodalGraph
from logistics_strike.pricing.congestion import CongestionModel
from logistics_strike.pricing.forward import ForwardCurveEngine, Tenor
from logistics_strike.pricing.fuel import FuelPriceEngine
from logistics_strike.pricing.spot import MODE_FUEL_TYPE, SpotPriceEngine
from logistics_strike.pricing.strike import StrikeEngine
from logistics_strike.pricing.volatility import VolatilityModel, VolatilityTracker
from logistics_strike.risk.delay import DelayModel
from logistics_strike.risk.disruption import DisruptionEngine
from logistics_strike.risk.geopolitical import GeopoliticalRiskEngine
from logistics_strike.risk.weather import WeatherEngine
from logistics_strike.markets.matching import MatchingEngine
from logistics_strike.markets.order_book import Order, OrderBook, OrderSide
from logistics_strike.routing.capacity import reserve_route_capacity
from logistics_strike.routing.optimisation import RouteObjectiveWeights, score_routes
from logistics_strike.routing.route_engine import RouteEngine

TrackedLane = Tuple[str, str, TransportMode]


@dataclass
class InTransitShipment:
    shipment: Shipment
    route_edge_keys: List[str]
    departure_step: int
    arrival_step: int
    contract_id: Optional[str] = None


@dataclass
class Engine:
    clock: SimClock
    graph: MultimodalGraph
    congestion_model: CongestionModel
    fuel_engine: FuelPriceEngine
    weather_engine: WeatherEngine
    geo_engine: GeopoliticalRiskEngine
    disruption_engine: DisruptionEngine
    demand_engine: DemandEngine
    route_engine: RouteEngine
    spot_engine: SpotPriceEngine
    forward_engine: ForwardCurveEngine
    strike_engine: StrikeEngine
    order_book: OrderBook
    matching_engine: MatchingEngine
    settlement_engine: SettlementEngine
    capacity_pools: Dict[str, CapacityPool]
    shippers: List[ShipperAgent]
    carrier_agents: List[CarrierAgent]
    brokers: List[BrokerAgent] = field(default_factory=list)
    traders: List[TraderAgent] = field(default_factory=list)
    tracked_lanes: List[TrackedLane] = field(default_factory=list)
    reference_cargo_factory: Optional[callable] = None
    event_bus: EventBus = field(default_factory=EventBus)
    state: GlobalState = field(default_factory=GlobalState)

    vol_trackers: Dict[str, VolatilityTracker] = field(default_factory=dict)
    in_transit: List[InTransitShipment] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.state.graph = self.graph
        self.state.order_book = self.order_book
        for pool_id, pool in self.capacity_pools.items():
            self.state.capacity_pools[pool_id] = pool

    def _reference_cargo(self) -> CargoSpec:
        if self.reference_cargo_factory:
            return self.reference_cargo_factory()
        return CargoSpec(
            cargo_type=CargoType.CONTAINER_40FT,
            weight_kg=22_000,
            volume_m3=67.0,
            declared_value_usd=60_000,
        )

    # -- the loop ---------------------------------------------------------
    def step(self) -> Dict:
        now = self.clock.tick()
        step_index = self.clock.step_index

        self._generate_freight_demand(now, step_index)
        self._update_global_capacity(step_index)
        self._update_weather(now)
        self._update_fuel_prices()
        self._update_port_and_network_congestion(step_index)
        self._calculate_spot_prices(now)
        self._update_forward_expectations(now)
        self._calculate_strike_prices(now)
        self._update_order_books(now)
        matches = self._match_capacity(now)
        self._optimise_routes(now, matches)
        arrivals = self._simulate_transit(step_index)
        self._apply_disruptions(step_index)
        settlements = self._settle_contracts(arrivals)
        self._update_market_state(now)
        metrics = self._record_metrics(now, step_index, matches, settlements)
        return metrics

    # -- individual phases --------------------------------------------------
    def _generate_freight_demand(self, now, step_index: int) -> None:
        shipments = self.demand_engine.generate(now, days_elapsed=step_index)
        for s in shipments:
            self.state.shipments[s.id] = s
        self._pending_shipments = shipments
        self.event_bus.emit(EventType.DEMAND_GENERATED, shipments, now, source="demand_engine")

    def _update_global_capacity(self, step_index: int) -> None:
        if step_index % 7 == 0:
            for pool in self.capacity_pools.values():
                pool.reset_period()
        self.event_bus.emit(EventType.CAPACITY_UPDATED, dict(self.capacity_pools), self.clock.now, source="capacity")

    def _update_weather(self, now) -> None:
        severity = self.weather_engine.step(now.month)
        self.state.weather = severity
        self.event_bus.emit(EventType.WEATHER_UPDATED, severity, now, source="weather_engine")

    def _update_fuel_prices(self) -> None:
        prices = self.fuel_engine.step(dt_days=self.clock.step_size.days or 1)
        self.state.fuel_prices = {k.value: v for k, v in prices.items()}
        self.event_bus.emit(EventType.FUEL_UPDATED, self.state.fuel_prices, self.clock.now, source="fuel_engine")

    def _update_port_and_network_congestion(self, step_index: int) -> None:
        self.congestion_model.recompute()
        self.disruption_engine.apply_effects(
            step_index, self.graph, self.congestion_model, self.capacity_pools, self.fuel_engine
        )
        self.congestion_model.apply_to_graph(self.graph)
        self.geo_engine.step()
        for edge in self.graph.edges():
            regions = [self.graph.node(edge.origin).region, self.graph.node(edge.destination).region]
            edge.risk_score = max(edge.risk_score * 0.5, self.geo_engine.route_risk(regions, []))
        self.event_bus.emit(EventType.CONGESTION_UPDATED, dict(self.congestion_model.node_scores), self.clock.now)

    def _corridor_edges(self, origin: str, destination: str, mode: TransportMode):
        edges = self.graph.edges_between(origin, destination)
        edges = [e for e in edges if e.mode == mode]
        return edges

    def lane_route(self, origin: str, destination: str, mode: TransportMode):
        direct = self._corridor_edges(origin, destination, mode)
        if direct:
            return [direct[0]]
        paths = self.route_engine.find_candidate_paths(origin, destination)
        for p in paths:
            if all(e.mode == mode for e in p):
                return p
        return paths[0] if paths else None

    def _calculate_spot_prices(self, now) -> None:
        cargo = self._reference_cargo()
        for origin, destination, mode in self.tracked_lanes:
            route = self.lane_route(origin, destination, mode)
            if not route:
                continue
            ref_shipment = Shipment(origin_id=origin, destination_id=destination, cargo=cargo, deadline=now + timedelta(days=45))
            result = self.spot_engine.compute_spot(ref_shipment, route, self.capacity_pools)
            key = self.state.corridor_key(origin, destination, mode)
            self.state.spot_prices[key] = result
            tracker = self.vol_trackers.setdefault(key, VolatilityTracker(name=key))
            tracker.push(result.price)
        self.event_bus.emit(EventType.SPOT_PRICED, dict(self.state.spot_prices), now)

    def _trend_per_day(self, key: str) -> float:
        tracker = self.vol_trackers.get(key)
        if not tracker or len(tracker.values) < 5:
            return 0.0
        recent = tracker.values[-10:]
        return float((recent[-1] / recent[0]) ** (1 / max(1, len(recent) - 1)) - 1)

    def _update_forward_expectations(self, now) -> None:
        for origin, destination, mode in self.tracked_lanes:
            key = self.state.corridor_key(origin, destination, mode)
            if key not in self.state.spot_prices:
                continue
            spot_result = self.state.spot_prices[key]
            tracker = self.vol_trackers[key]
            curve = self.forward_engine.build_curve(
                corridor_id=key,
                mode=mode.value,
                as_of=now,
                current_spot=spot_result.price,
                spot_history=tracker.values,
                trend_per_day=max(-0.01, min(0.01, self._trend_per_day(key))),
            )
            self.state.forward_curves[key] = curve
        self.event_bus.emit(EventType.FORWARD_UPDATED, dict(self.state.forward_curves), now)

    def capacity_scarcity_forecast(self, route) -> float:
        scarcities = [self.capacity_pools[e.key].scarcity() for e in route if e.key in self.capacity_pools]
        return sum(scarcities) / len(scarcities) if scarcities else 0.4

    def congestion_forecast(self, route) -> float:
        return sum(e.congestion for e in route) / len(route) if route else 0.2

    def _calculate_strike_prices(self, now) -> None:
        for origin, destination, mode in self.tracked_lanes:
            key = self.state.corridor_key(origin, destination, mode)
            if key not in self.state.forward_curves:
                continue
            curve = self.state.forward_curves[key]
            route = self.lane_route(origin, destination, mode)
            spot_result = self.state.spot_prices[key]
            fuel_type = MODE_FUEL_TYPE[mode]
            fuel_share = route[0].fuel_share if route else 0.3
            fuel_vol = self.fuel_engine.params[fuel_type].volatility / self.fuel_engine.params[fuel_type].long_run_mean

            monthly_point = curve.point(Tenor.MONTHLY)
            strike_result = self.strike_engine.compute_strike(
                corridor_id=key,
                mode=mode.value,
                forward_point=monthly_point,
                current_spot=spot_result.price,
                capacity_scarcity_forecast=self.capacity_scarcity_forecast(route),
                congestion_forecast=self.congestion_forecast(route),
                fuel_share=fuel_share,
                fuel_volatility_horizon=fuel_vol * (monthly_point.horizon_days / 365.0) ** 0.5,
                required_reliability=0.95,
                # the route's own priced reliability (from the spot engine)
                # is the consistent baseline to compare a shipper's required
                # reliability against -- see pricing/spot.py's reliability
                # figure, which is what a quote would actually display.
                baseline_reliability=spot_result.reliability,
            )
            self.state.strike_prices[key] = strike_result
        self.event_bus.emit(EventType.STRIKE_PRICED, dict(self.state.strike_prices), now)

    def _update_order_books(self, now) -> None:
        self.order_book.purge_expired(now)
        for shipment in getattr(self, "_pending_shipments", []):
            key = self.state.corridor_key(shipment.origin_id, shipment.destination_id, TransportMode.SEA)
            spot_result = self.state.spot_prices.get(key)
            indicative = spot_result.price if spot_result else shipment.cargo.declared_value_usd * 0.02
            shipper = self.shippers[hash(shipment.id) % len(self.shippers)] if self.shippers else None
            if shipper is None:
                continue
            order = shipper.place_order(shipment, indicative)
            order.mode = TransportMode.SEA.value
            order.created_at = now
            self.order_book.submit(order)

        for agent in self.carrier_agents:
            agent.react_to_utilisation()
            if not self.tracked_lanes:
                continue
            origin, destination, mode = self.tracked_lanes[hash(agent.id) % len(self.tracked_lanes)]
            offer = agent.offer_capacity(origin, destination, mode.value, now)
            self.order_book.submit(offer)

        self.event_bus.emit(EventType.ORDER_SUBMITTED, None, now)

    def _match_capacity(self, now):
        matches = self.matching_engine.match_all(self.order_book, now)
        for m in matches:
            contract = self.matching_engine.match_to_contract(m, max_transit_days=35)
            contract.created_at = now
            contract.activate()
            self.state.contracts[contract.id] = contract
            self.event_bus.emit(EventType.CONTRACT_CREATED, contract, now)
        self.event_bus.emit(EventType.ORDER_MATCHED, matches, now)
        return matches

    def _optimise_routes(self, now, matches) -> None:
        for contract in list(self.state.contracts.values()):
            if contract.status != ContractStatus.ACTIVE or contract.shipment_id:
                continue
            try:
                mode = TransportMode(contract.mode)
            except ValueError:
                mode = TransportMode.SEA
            route = self.lane_route(contract.origin_id, contract.destination_id, mode)
            if not route:
                continue
            cargo = self._reference_cargo()
            shipment = Shipment(
                origin_id=contract.origin_id,
                destination_id=contract.destination_id,
                cargo=cargo,
                deadline=contract.execution_window_end,
                shipper_id=contract.buyer_id,
            )
            if not reserve_route_capacity(route, shipment, self.capacity_pools):
                continue
            shipment.status = ShipmentStatus.BOOKED
            shipment.assigned_contract_id = contract.id
            contract.shipment_id = shipment.id
            self.state.shipments[shipment.id] = shipment

            transit_days = sum(e.base_transit_days * (1 + 0.4 * e.congestion) for e in route)
            delay_model = DelayModel(transit_days, max(0.5, transit_days * 0.12))
            actual_days = float(delay_model.sample(1)[0])
            departure_step = self.clock.step_index
            arrival_step = departure_step + max(1, round(actual_days / max(1, self.clock.step_size.days)))

            self.in_transit.append(
                InTransitShipment(
                    shipment=shipment,
                    route_edge_keys=[e.key for e in route],
                    departure_step=departure_step,
                    arrival_step=arrival_step,
                    contract_id=contract.id,
                )
            )
            shipment.status = ShipmentStatus.IN_TRANSIT
            self.event_bus.emit(EventType.TRANSIT_STARTED, shipment, now)
        self.event_bus.emit(EventType.ROUTE_OPTIMISED, None, now)

    def _simulate_transit(self, step_index: int) -> List[InTransitShipment]:
        arrived = [t for t in self.in_transit if t.arrival_step <= step_index]
        self.in_transit = [t for t in self.in_transit if t.arrival_step > step_index]
        for t in arrived:
            t.shipment.status = ShipmentStatus.DELIVERED
            t.shipment.actual_delivery = self.clock.now
            for key in t.route_edge_keys:
                pool = self.capacity_pools.get(key)
                if pool:
                    pool.release(t.shipment.cargo.teu_equivalent())
            self.event_bus.emit(EventType.TRANSIT_COMPLETED, t.shipment, self.clock.now)
        return arrived

    def _apply_disruptions(self, step_index: int) -> None:
        resolved = self.disruption_engine.step(step_index)
        for d in resolved:
            self.event_bus.emit(EventType.DISRUPTION_RESOLVED, d, self.clock.now)
        self.state.active_disruptions = dict(self.disruption_engine.active)

    def _settle_contracts(self, arrivals: List[InTransitShipment]):
        settlements = []
        for t in arrivals:
            contract = self.state.contracts.get(t.contract_id) if t.contract_id else None
            if not contract:
                continue
            actual_days = (t.arrival_step - t.departure_step) * max(1, self.clock.step_size.days)
            settlement = self.settlement_engine.settle(contract, actual_transit_days=actual_days)
            contract.status = settlement.status
            settlements.append(settlement)
            evt_type = EventType.CONTRACT_SETTLED if settlement.on_time else EventType.CONTRACT_BREACHED
            self.event_bus.emit(evt_type, settlement, self.clock.now)
        return settlements

    def _update_market_state(self, now) -> None:
        for trader in self.traders:
            for key, strike_result in self.state.strike_prices.items():
                curve = self.state.forward_curves.get(key)
                if not curve:
                    continue
                trader.decide_position(
                    contract_id=f"SYN-{key}-{self.clock.step_index}",
                    corridor_key=key,
                    strike_price=strike_result.strike_price,
                    model_expected_future_spot=curve.point(Tenor.MONTHLY).expected_spot,
                    max_volume_units=20.0,
                    current_step=self.clock.step_index,
                )

    def _record_metrics(self, now, step_index: int, matches, settlements) -> Dict:
        snapshot = {
            "step": step_index,
            "timestamp": now.isoformat(),
            "n_shipments_generated": len(getattr(self, "_pending_shipments", [])),
            "n_matches": len(matches),
            "n_contracts": len(self.state.contracts),
            "n_in_transit": len(self.in_transit),
            "n_settlements": len(settlements),
            "spot_prices": {k: v.price for k, v in self.state.spot_prices.items()},
            "strike_prices": {k: v.strike_price for k, v in self.state.strike_prices.items()},
            "fuel_prices": dict(self.state.fuel_prices),
            "avg_utilisation": (
                sum(p.utilisation() for p in self.capacity_pools.values()) / len(self.capacity_pools)
                if self.capacity_pools
                else 0.0
            ),
            "active_disruptions": len(self.disruption_engine.active),
        }
        self.state.metrics_history.append(snapshot)
        self.event_bus.emit(EventType.METRICS_RECORDED, snapshot, now)
        return snapshot
