from logistics_strike.core.clock import SimClock
from logistics_strike.core.events import Event, EventBus, EventType
from logistics_strike.core.state import GlobalState, TransportMode, NodeType

__all__ = [
    "SimClock",
    "Event",
    "EventBus",
    "EventType",
    "GlobalState",
    "TransportMode",
    "NodeType",
    "Engine",
    "Simulation",
]


def __getattr__(name):
    # Engine/Simulation are imported lazily to avoid a heavy import chain
    # (agents/routing/pricing/...) whenever a caller only needs the light
    # core primitives above (e.g. GlobalState, SimClock) for typing.
    if name == "Engine":
        from logistics_strike.core.engine import Engine

        return Engine
    if name == "Simulation":
        from logistics_strike.core.simulation import Simulation

        return Simulation
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
