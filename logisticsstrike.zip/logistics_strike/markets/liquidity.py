"""Market liquidity metrics.

Bid-ask spread and order-book depth per corridor, used by
:mod:`logistics_strike.pricing.strike` to scale the liquidity premium: a
thin market (wide spread, shallow depth) should command a bigger premium
for locking in a forward commitment than a deep, liquid one.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from logistics_strike.markets.order_book import OrderBook


@dataclass
class LiquidityMetrics:
    corridor_key: str
    spread: Optional[float]
    depth_units: float
    n_open_orders: int
    depth_score: float  # 0 (illiquid) - 1 (deep)


@dataclass
class LiquidityEngine:
    depth_reference_units: float = 500.0  # depth considered "fully liquid"

    def measure(self, order_book: OrderBook, corridor_key: str) -> LiquidityMetrics:
        spread = order_book.spread(corridor_key)
        depth = order_book.depth(corridor_key)
        n = len(order_book.open_orders(corridor_key))
        depth_score = max(0.0, min(1.0, depth / self.depth_reference_units))
        return LiquidityMetrics(
            corridor_key=corridor_key,
            spread=spread,
            depth_units=depth,
            n_open_orders=n,
            depth_score=depth_score,
        )

    def measure_all(self, order_book: OrderBook) -> Dict[str, LiquidityMetrics]:
        keys = {o.corridor_key() for o in order_book.open_orders()}
        return {k: self.measure(order_book, k) for k in keys}
