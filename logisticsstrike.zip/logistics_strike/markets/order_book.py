"""Freight order book.

Buy-side participants (manufacturers, retailers, importers, exporters,
logistics buyers) post demand orders; sell-side participants (shipping
lines, airlines, rail operators, trucking companies, 3PLs) post capacity
offers. Orders are scoped to a corridor+mode so the book can be matched
independently per market (see :mod:`logistics_strike.markets.matching`).
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

_id_counter = itertools.count(1)


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderStatus(str, Enum):
    OPEN = "OPEN"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"


@dataclass
class Order:
    side: OrderSide
    participant_id: str
    origin_id: str
    destination_id: str
    mode: str
    cargo_units: float  # TEU-equivalent
    execution_window_start: datetime
    execution_window_end: datetime
    limit_price: float  # max acceptable for BUY, min acceptable for SELL
    min_reliability: float = 0.85
    id: str = field(default_factory=lambda: f"ORD-{next(_id_counter):07d}")
    status: OrderStatus = OrderStatus.OPEN
    filled_units: float = 0.0
    created_at: Optional[datetime] = None

    def corridor_key(self) -> str:
        return f"{self.origin_id}->{self.destination_id}:{self.mode}"

    def remaining_units(self) -> float:
        return max(0.0, self.cargo_units - self.filled_units)

    def is_marketable_against(self, other: "Order") -> bool:
        """Price/side/corridor/reliability compatibility check."""
        if self.side == other.side:
            return False
        if self.corridor_key() != other.corridor_key():
            return False
        buy, sell = (self, other) if self.side == OrderSide.BUY else (other, self)
        if buy.limit_price < sell.limit_price:
            return False
        if buy.min_reliability > 1.0:
            return False
        window_overlap = (
            buy.execution_window_start <= sell.execution_window_end
            and sell.execution_window_start <= buy.execution_window_end
        )
        return window_overlap


@dataclass
class OrderBook:
    orders: Dict[str, Order] = field(default_factory=dict)

    def submit(self, order: Order) -> Order:
        self.orders[order.id] = order
        return order

    def cancel(self, order_id: str) -> None:
        if order_id in self.orders:
            self.orders[order_id].status = OrderStatus.CANCELLED

    def open_orders(self, corridor_key: Optional[str] = None, side: Optional[OrderSide] = None) -> List[Order]:
        out = [o for o in self.orders.values() if o.status in (OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED)]
        if corridor_key:
            out = [o for o in out if o.corridor_key() == corridor_key]
        if side:
            out = [o for o in out if o.side == side]
        return out

    def best_bid(self, corridor_key: str) -> Optional[Order]:
        bids = self.open_orders(corridor_key, OrderSide.BUY)
        return max(bids, key=lambda o: o.limit_price, default=None)

    def best_ask(self, corridor_key: str) -> Optional[Order]:
        asks = self.open_orders(corridor_key, OrderSide.SELL)
        return min(asks, key=lambda o: o.limit_price, default=None)

    def spread(self, corridor_key: str) -> Optional[float]:
        bid, ask = self.best_bid(corridor_key), self.best_ask(corridor_key)
        if bid is None or ask is None:
            return None
        return ask.limit_price - bid.limit_price

    def depth(self, corridor_key: str) -> float:
        return sum(o.remaining_units() for o in self.open_orders(corridor_key))

    def purge_expired(self, now: datetime) -> None:
        for o in self.orders.values():
            if o.status in (OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED) and o.execution_window_end < now:
                o.status = OrderStatus.EXPIRED
