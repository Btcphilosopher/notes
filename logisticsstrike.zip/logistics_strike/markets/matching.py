"""Matching engine: pairs freight demand with capacity supply.

Runs a price/time-priority continuous double auction per corridor: sort
resting buy orders by descending limit price, sell orders by ascending
limit price, and match while the best bid clears the best ask, trading at
the mid-price of the two limits (a standard, defensible convention when
order arrival time isn't the deciding tie-break). Each match can be turned
directly into a :class:`~logistics_strike.contracts.freight_contract.FreightContract`.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from logistics_strike.contracts.freight_contract import SLA, ContractType, FreightContract
from logistics_strike.markets.order_book import Order, OrderBook, OrderSide, OrderStatus

_match_id_counter = itertools.count(1)


@dataclass
class MatchResult:
    id: str
    buy_order: Order
    sell_order: Order
    matched_units: float
    matched_price: float
    timestamp: datetime


@dataclass
class MatchingEngine:
    def match_corridor(self, order_book: OrderBook, corridor_key: str, now: datetime) -> List[MatchResult]:
        buys = sorted(
            order_book.open_orders(corridor_key, OrderSide.BUY),
            key=lambda o: (-o.limit_price, o.created_at or now),
        )
        sells = sorted(
            order_book.open_orders(corridor_key, OrderSide.SELL),
            key=lambda o: (o.limit_price, o.created_at or now),
        )

        matches: List[MatchResult] = []
        bi, si = 0, 0
        while bi < len(buys) and si < len(sells):
            buy, sell = buys[bi], sells[si]

            if not buy.is_marketable_against(sell):
                # advance whichever side cannot possibly clear further orders
                if buy.limit_price < sell.limit_price:
                    break
                si += 1
                continue

            tradable_units = min(buy.remaining_units(), sell.remaining_units())
            if tradable_units <= 0:
                if buy.remaining_units() <= 0:
                    bi += 1
                else:
                    si += 1
                continue

            matched_price = (buy.limit_price + sell.limit_price) / 2.0

            buy.filled_units += tradable_units
            sell.filled_units += tradable_units
            buy.status = OrderStatus.FILLED if buy.remaining_units() <= 1e-9 else OrderStatus.PARTIALLY_FILLED
            sell.status = OrderStatus.FILLED if sell.remaining_units() <= 1e-9 else OrderStatus.PARTIALLY_FILLED

            matches.append(
                MatchResult(
                    id=f"MTCH-{next(_match_id_counter):07d}",
                    buy_order=buy,
                    sell_order=sell,
                    matched_units=tradable_units,
                    matched_price=matched_price,
                    timestamp=now,
                )
            )

            if buy.remaining_units() <= 1e-9:
                bi += 1
            if sell.remaining_units() <= 1e-9:
                si += 1

        return matches

    def match_all(self, order_book: OrderBook, now: datetime) -> List[MatchResult]:
        corridor_keys = {o.corridor_key() for o in order_book.open_orders()}
        matches: List[MatchResult] = []
        for ck in corridor_keys:
            matches.extend(self.match_corridor(order_book, ck, now))
        return matches

    @staticmethod
    def match_to_contract(match: MatchResult, max_transit_days: float) -> FreightContract:
        sla = SLA(max_transit_days=max_transit_days, min_reliability=match.buy_order.min_reliability)
        return FreightContract(
            contract_type=ContractType.SPOT,
            buyer_id=match.buy_order.participant_id,
            seller_id=match.sell_order.participant_id,
            origin_id=match.buy_order.origin_id,
            destination_id=match.buy_order.destination_id,
            mode=match.buy_order.mode,
            price=match.matched_price,
            volume_units=match.matched_units,
            execution_window_start=max(match.buy_order.execution_window_start, match.sell_order.execution_window_start),
            execution_window_end=min(match.buy_order.execution_window_end, match.sell_order.execution_window_end),
            sla=sla,
            created_at=match.timestamp,
        )
