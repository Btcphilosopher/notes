"""Capacity auctions.

Complements the continuous order book with a periodic uniform-price sealed
-bid auction -- the standard mechanism for allocating a fixed block of
scarce capacity (e.g. a single sailing's remaining slots, or a peak-season
allocation round) fairly and efficiently: every winner pays the same
market-clearing price, set by the highest losing (or lowest winning) bid.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from logistics_strike.markets.order_book import Order


@dataclass
class AuctionAllocation:
    order_id: str
    participant_id: str
    allocated_units: float
    clearing_price: float


@dataclass
class AuctionResult:
    total_capacity: float
    clearing_price: float
    allocations: List[AuctionAllocation] = field(default_factory=list)
    unmet_demand: float = 0.0


@dataclass
class UniformPriceAuction:
    def run(self, bids: List[Order], available_capacity: float) -> AuctionResult:
        """``bids`` are BUY orders (participants bidding for capacity).
        Ranks by descending limit price and allocates until capacity is
        exhausted; the clearing price is the lowest accepted bid (i.e. the
        marginal winner's price), and every winner pays that same price."""
        ranked = sorted(bids, key=lambda o: -o.limit_price)
        remaining = available_capacity
        allocations: List[AuctionAllocation] = []
        clearing_price = 0.0

        for order in ranked:
            if remaining <= 1e-9:
                break
            take = min(order.remaining_units(), remaining)
            if take <= 0:
                continue
            allocations.append(
                AuctionAllocation(
                    order_id=order.id,
                    participant_id=order.participant_id,
                    allocated_units=take,
                    clearing_price=0.0,  # backfilled below
                )
            )
            clearing_price = order.limit_price
            remaining -= take

        for a in allocations:
            a.clearing_price = clearing_price

        unmet = sum(o.remaining_units() for o in bids) - sum(a.allocated_units for a in allocations)

        return AuctionResult(
            total_capacity=available_capacity,
            clearing_price=clearing_price,
            allocations=allocations,
            unmet_demand=max(0.0, unmet),
        )
