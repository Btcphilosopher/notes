"""Strike contract economics (requirement #19).

A strike is not simply "the expected future spot": both sides are giving up
something to eliminate uncertainty, and the value of that certainty is
priced explicitly here using a mean-variance certainty-equivalent framework
rather than assuming a risk-neutral world where the strike would collapse
to the expected future spot.

    buyer's uncertain-exposure cost   = expected_spot + risk_aversion_buyer * variance
    buyer's strike-contract cost      = strike_price
    buyer_value                        = uncertain-exposure cost - strike cost
                                          (positive => the strike is worth taking)

    seller's uncertain-exposure revenue = expected_spot - risk_aversion_seller * variance
    seller's strike-contract revenue    = strike_price
    seller_value                         = strike revenue - uncertain-exposure revenue

Both sides can have positive value simultaneously -- that surplus is exactly
what a strike contract is for: it does not require the strike to sit at the
expected future spot, only that each party's certainty-equivalent improves.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import erf, sqrt


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def _lognormal_quantile(mean: float, vol: float, t_years: float, q: float) -> float:
    """Quantile of a lognormal distribution parameterised so its mean equals
    ``mean`` at time ``t_years`` under volatility ``vol`` (annualised)."""
    from scipy.stats import norm

    sigma = max(1e-9, vol * sqrt(max(t_years, 1e-9)))
    mu = _safe_log(mean) - 0.5 * sigma ** 2
    z = norm.ppf(q)
    return float(_safe_exp(mu + sigma * z))


def _safe_log(x: float) -> float:
    from math import log

    return log(max(x, 1e-9))


def _safe_exp(x: float) -> float:
    from math import exp

    return exp(x)


@dataclass
class StrikeContractEconomics:
    strike_price: float
    expected_future_spot: float
    volume_units: float
    volatility_annualised: float
    horizon_years: float
    execution_probability: float  # P(shipment executes within SLA) -- from reliability model
    # NOTE: these multiply a variance expressed in currency^2 (typically
    # 1e5-1e6 for realistic freight prices/vols), so they are calibrated to
    # be small -- ~0.001 keeps the resulting risk premium to a single-digit
    # percentage of the shipment's notional value, not a multiple of it.
    risk_aversion_buyer: float = 0.0015
    risk_aversion_seller: float = 0.0012

    def _variance(self) -> float:
        sigma = self.volatility_annualised * sqrt(max(self.horizon_years, 1e-9))
        return (self.expected_future_spot * sigma) ** 2

    def expected_payoff_buyer(self) -> float:
        """Risk-neutral expected payoff per the raw price difference alone
        (excludes the certainty value -- see ``buyer_value``)."""
        return (self.expected_future_spot - self.strike_price) * self.volume_units

    def expected_payoff_seller(self) -> float:
        return -self.expected_payoff_buyer()

    def downside(self, confidence: float = 0.10) -> float:
        """Buyer payoff at the low-percentile realised spot (bad outcome for
        a buyer who is long the strike, e.g. spot collapses below strike)."""
        low_spot = _lognormal_quantile(self.expected_future_spot, self.volatility_annualised, self.horizon_years, confidence)
        return (low_spot - self.strike_price) * self.volume_units

    def upside(self, confidence: float = 0.90) -> float:
        high_spot = _lognormal_quantile(self.expected_future_spot, self.volatility_annualised, self.horizon_years, confidence)
        return (high_spot - self.strike_price) * self.volume_units

    def buyer_value(self) -> float:
        variance = self._variance()
        uncertain_exposure_cost = self.expected_future_spot + self.risk_aversion_buyer * variance
        strike_cost = self.strike_price
        raw_value = (uncertain_exposure_cost - strike_cost) * self.volume_units
        # scale by execution probability: a strike that is unlikely to
        # actually execute (capacity/route risk) delivers less certain value
        return raw_value * self.execution_probability

    def seller_value(self) -> float:
        variance = self._variance()
        uncertain_exposure_revenue = self.expected_future_spot - self.risk_aversion_seller * variance
        strike_revenue = self.strike_price
        return (strike_revenue - uncertain_exposure_revenue) * self.volume_units * self.execution_probability

    def summary(self) -> dict:
        return {
            "strike_price": round(self.strike_price, 2),
            "expected_future_spot": round(self.expected_future_spot, 2),
            "expected_payoff_buyer": round(self.expected_payoff_buyer(), 2),
            "expected_payoff_seller": round(self.expected_payoff_seller(), 2),
            "downside_p10": round(self.downside(0.10), 2),
            "upside_p90": round(self.upside(0.90), 2),
            "buyer_value": round(self.buyer_value(), 2),
            "seller_value": round(self.seller_value(), 2),
            "execution_probability": round(self.execution_probability, 4),
        }


# ---------------------------------------------------------------------------
# Logistics options (requirement #20): a shipper pays a premium today for the
# *right, not the obligation*, to secure capacity later at a fixed strike --
# unlike the strike contract above, which is a firm commitment on both sides.
# Priced with Black-76 (the standard model for options on a forward/futures
# price, which is exactly what a future freight spot price is here).
# ---------------------------------------------------------------------------

from enum import Enum


class OptionType(str, Enum):
    CAPACITY_CALL = "CAPACITY_CALL"  # right to buy capacity at the strike
    CAPACITY_PUT = "CAPACITY_PUT"  # right to sell/release booked capacity at the strike
    PRIORITY_DELIVERY = "PRIORITY_DELIVERY"  # right to bump into a priority slot at the strike
    GUARANTEED_SLOT = "GUARANTEED_SLOT"  # right to claim a reserved slot at the strike


@dataclass
class LogisticsOption:
    option_type: OptionType
    strike: float
    current_spot: float
    volatility_annualised: float
    horizon_years: float
    volume_units: float
    capacity_availability_forecast: float = 1.0  # 0-1, scarcity dampens a call's realistic exercise value

    def _d1_d2(self) -> tuple[float, float]:
        sigma = max(1e-9, self.volatility_annualised)
        t = max(self.horizon_years, 1e-9)
        d1 = (_safe_log(self.current_spot / self.strike) + 0.5 * sigma ** 2 * t) / (sigma * sqrt(t))
        d2 = d1 - sigma * sqrt(t)
        return d1, d2

    def probability_of_exercise(self) -> float:
        """P(the option finishes in the money), i.e. N(d2) for a call and
        N(-d2) for a put, dampened by expected capacity availability -- an
        in-the-money call is worthless if there is physically no slot to
        exercise it into."""
        d1, d2 = self._d1_d2()
        if self.option_type in (OptionType.CAPACITY_CALL, OptionType.PRIORITY_DELIVERY, OptionType.GUARANTEED_SLOT):
            p = _norm_cdf(d2)
        else:
            p = _norm_cdf(-d2)
        return max(0.0, min(1.0, p * self.capacity_availability_forecast))

    def fair_premium(self) -> float:
        """Black-76 premium per unit of volume, times volume."""
        d1, d2 = self._d1_d2()
        is_call = self.option_type in (OptionType.CAPACITY_CALL, OptionType.PRIORITY_DELIVERY, OptionType.GUARANTEED_SLOT)
        if is_call:
            per_unit = self.current_spot * _norm_cdf(d1) - self.strike * _norm_cdf(d2)
        else:
            per_unit = self.strike * _norm_cdf(-d2) - self.current_spot * _norm_cdf(-d1)
        per_unit = max(0.0, per_unit) * self.capacity_availability_forecast
        return per_unit * self.volume_units

    def intrinsic_value(self) -> float:
        is_call = self.option_type in (OptionType.CAPACITY_CALL, OptionType.PRIORITY_DELIVERY, OptionType.GUARANTEED_SLOT)
        per_unit = max(0.0, self.current_spot - self.strike) if is_call else max(0.0, self.strike - self.current_spot)
        return per_unit * self.volume_units

    def time_value(self) -> float:
        return max(0.0, self.fair_premium() - self.intrinsic_value())

    def summary(self) -> dict:
        return {
            "option_type": self.option_type.value,
            "strike": round(self.strike, 2),
            "current_spot": round(self.current_spot, 2),
            "fair_premium": round(self.fair_premium(), 2),
            "intrinsic_value": round(self.intrinsic_value(), 2),
            "time_value": round(self.time_value(), 2),
            "probability_of_exercise": round(self.probability_of_exercise(), 4),
            "capacity_availability_forecast": round(self.capacity_availability_forecast, 4),
        }
