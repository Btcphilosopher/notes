"""Base freight contract model.

Every contract type (spot, forward, strike, fixed-rate, index-linked,
capacity reservation) shares the same economic envelope: price, volume,
route, mode, execution window, SLA, reliability requirement, settlement
terms, penalties and termination conditions. Type-specific economics
(buyer/seller value, payoff, optionality) live in
:mod:`logistics_strike.contracts.forward_contract` and
:mod:`logistics_strike.contracts.strike_contract`.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

_id_counter = itertools.count(1)


class ContractType(str, Enum):
    SPOT = "SPOT"
    FORWARD = "FORWARD"
    STRIKE = "STRIKE"
    FIXED_RATE = "FIXED_RATE"
    INDEX_LINKED = "INDEX_LINKED"
    CAPACITY_RESERVATION = "CAPACITY_RESERVATION"


class ContractStatus(str, Enum):
    PENDING = "PENDING"
    ACTIVE = "ACTIVE"
    FULFILLED = "FULFILLED"
    BREACHED = "BREACHED"
    SETTLED = "SETTLED"
    TERMINATED = "TERMINATED"


@dataclass
class SLA:
    max_transit_days: float
    min_reliability: float
    on_time_bonus_pct: float = 0.0
    late_penalty_pct_per_day: float = 0.02
    max_penalty_pct: float = 0.30


@dataclass
class FreightContract:
    contract_type: ContractType
    buyer_id: str
    seller_id: str
    origin_id: str
    destination_id: str
    mode: str
    price: float
    volume_units: float  # TEU-equivalent
    execution_window_start: datetime
    execution_window_end: datetime
    sla: SLA
    index_reference: Optional[str] = None  # for INDEX_LINKED contracts
    index_spread: float = 0.0
    strike_price: Optional[float] = None  # for STRIKE contracts
    id: str = field(default_factory=lambda: f"CTR-{next(_id_counter):07d}")
    status: ContractStatus = ContractStatus.PENDING
    created_at: Optional[datetime] = None
    shipment_id: Optional[str] = None
    termination_notice_days: int = 14

    def notional_value(self) -> float:
        return self.price * self.volume_units

    def is_within_window(self, when: datetime) -> bool:
        return self.execution_window_start <= when <= self.execution_window_end

    def activate(self) -> None:
        self.status = ContractStatus.ACTIVE

    def terminate(self, reason: str = "") -> None:
        self.status = ContractStatus.TERMINATED
