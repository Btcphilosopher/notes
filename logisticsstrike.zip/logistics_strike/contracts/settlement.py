"""Contract settlement engine.

Settles a contract against what actually happened (actual transit time,
actual reliability outcome) versus what the SLA promised, applying late
penalties / on-time bonuses and producing a final cash settlement amount.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from logistics_strike.contracts.freight_contract import ContractStatus, FreightContract


@dataclass
class SettlementResult:
    contract_id: str
    base_amount: float
    penalty: float
    bonus: float
    final_amount: float
    on_time: bool
    actual_transit_days: float
    days_late: float
    status: ContractStatus


@dataclass
class SettlementEngine:
    def settle(
        self,
        contract: FreightContract,
        actual_transit_days: float,
        index_price_at_settlement: Optional[float] = None,
    ) -> SettlementResult:
        base_amount = contract.notional_value()

        if contract.contract_type.value == "INDEX_LINKED" and index_price_at_settlement is not None:
            effective_price = index_price_at_settlement + contract.index_spread
            base_amount = effective_price * contract.volume_units

        days_late = max(0.0, actual_transit_days - contract.sla.max_transit_days)
        on_time = days_late <= 0.0

        penalty = 0.0
        bonus = 0.0
        if on_time and contract.sla.on_time_bonus_pct > 0:
            bonus = base_amount * contract.sla.on_time_bonus_pct
        elif not on_time:
            penalty_rate = min(
                contract.sla.max_penalty_pct,
                days_late * contract.sla.late_penalty_pct_per_day,
            )
            penalty = base_amount * penalty_rate

        final_amount = base_amount - penalty + bonus
        status = ContractStatus.SETTLED if on_time else ContractStatus.BREACHED

        return SettlementResult(
            contract_id=contract.id,
            base_amount=round(base_amount, 2),
            penalty=round(penalty, 2),
            bonus=round(bonus, 2),
            final_amount=round(final_amount, 2),
            on_time=on_time,
            actual_transit_days=actual_transit_days,
            days_late=round(days_late, 2),
            status=status,
        )
