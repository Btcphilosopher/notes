"""Forward contract economics.

A forward locks in a price today for delivery in a future window, without
the optionality of a strike contract (see ``strike_contract.py``): both
sides are obligated to transact at the forward price regardless of where
the spot price ends up.
"""

from __future__ import annotations

from dataclasses import dataclass

from logistics_strike.contracts.freight_contract import ContractType, FreightContract


@dataclass
class ForwardContractEconomics:
    contract: FreightContract
    forward_price: float

    def buyer_payoff(self, realised_spot_at_execution: float) -> float:
        """Value to the buyer of having locked in ``forward_price`` instead
        of paying the realised spot at execution, per unit of volume."""
        return (realised_spot_at_execution - self.forward_price) * self.contract.volume_units

    def seller_payoff(self, realised_spot_at_execution: float) -> float:
        return -self.buyer_payoff(realised_spot_at_execution)

    def breakeven_spot(self) -> float:
        return self.forward_price


def make_forward_contract(
    buyer_id: str,
    seller_id: str,
    origin_id: str,
    destination_id: str,
    mode: str,
    forward_price: float,
    volume_units: float,
    execution_window_start,
    execution_window_end,
    sla,
) -> FreightContract:
    return FreightContract(
        contract_type=ContractType.FORWARD,
        buyer_id=buyer_id,
        seller_id=seller_id,
        origin_id=origin_id,
        destination_id=destination_id,
        mode=mode,
        price=forward_price,
        volume_units=volume_units,
        execution_window_start=execution_window_start,
        execution_window_end=execution_window_end,
        sla=sla,
    )
