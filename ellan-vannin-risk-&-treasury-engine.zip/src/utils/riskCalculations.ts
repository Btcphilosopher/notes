/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortfolioAsset, KPIMetrics, Counterparty, FXExposure, InfraProject, StressScenario, CashFlowItem, SimulationResult } from '../types';
import { CORRELATION_MATRIX } from '../data/mockRiskData';

/**
 * Calculates the portfolio weighted expected return
 */
export function calculateWeightedReturn(assets: PortfolioAsset[]): number {
  const totalValue = assets.reduce((sum, a) => sum + a.value, 0);
  if (totalValue === 0) return 0;
  return assets.reduce((sum, a) => sum + a.expectedReturn * (a.value / totalValue), 0);
}

/**
 * Calculates portfolio volatility using the weights, individual volatilities, and correlation matrix
 */
export function calculatePortfolioVolatility(assets: PortfolioAsset[]): number {
  const totalValue = assets.reduce((sum, a) => sum + a.value, 0);
  if (totalValue === 0) return 0;

  const w = assets.map(a => a.value / totalValue);
  const sigma = assets.map(a => a.volatility);
  const names = assets.map(a => a.type);

  let variance = 0;
  for (let i = 0; i < assets.length; i++) {
    for (let j = 0; j < assets.length; j++) {
      const nameI = names[i];
      const nameJ = names[j];
      const correlation = CORRELATION_MATRIX[nameI]?.[nameJ] ?? (i === j ? 1 : 0);
      variance += w[i] * w[j] * sigma[i] * sigma[j] * correlation;
    }
  }

  return Math.sqrt(variance);
}

/**
 * Calculates portfolio systematic beta relative to the market benchmark
 */
export function calculatePortfolioBeta(assets: PortfolioAsset[]): number {
  const totalValue = assets.reduce((sum, a) => sum + a.value, 0);
  if (totalValue === 0) return 0;
  return assets.reduce((sum, a) => sum + a.beta * (a.value / totalValue), 0);
}

/**
 * Z-score lookup for VaR confidence intervals
 */
export function getZScore(confidence: number): number {
  if (confidence >= 0.99) return 2.3263; // 99%
  if (confidence >= 0.95) return 1.6449; // 95%
  if (confidence >= 0.90) return 1.2816; // 90%
  return 1.6449;
}

/**
 * Calculates daily VaR (Parametric)
 */
export function calculateParametricVaR(
  volatility: number,
  aum: number,
  confidence: number
): number {
  const dailyVol = volatility / Math.sqrt(252);
  const z = getZScore(confidence);
  return z * dailyVol * aum;
}

/**
 * Calculates Expected Shortfall (ES) for a normal distribution
 */
export function calculateExpectedShortfall(
  volatility: number,
  aum: number,
  confidence: number
): number {
  const dailyVol = volatility / Math.sqrt(252);
  const z = getZScore(confidence);
  const pdf = Math.exp(-0.5 * z * z) / Math.sqrt(2 * Math.PI);
  const alpha = 1 - confidence;
  const esPct = dailyVol * (pdf / alpha);
  return esPct * aum;
}

/**
 * Computes the complete risk KPI values, applying any adjustments from the active scenario
 */
export function calculateKPIs(
  baseAssets: PortfolioAsset[],
  baseSettings: { interestRateBase: number; varConfidence: number },
  activeScenario: StressScenario | null
): KPIMetrics {
  // Copy and adjust assets based on stress scenarios
  const assets = baseAssets.map(asset => {
    let multiplier = 1;
    if (activeScenario) {
      if (asset.type === 'Equities') multiplier += activeScenario.equityImpact;
      else if (asset.type === 'Bonds') multiplier += activeScenario.bondImpact;
      else if (asset.type === 'Property') multiplier += activeScenario.propertyImpact;
      else if (asset.type === 'Infrastructure') multiplier += activeScenario.infraImpact;
      else if (asset.type === 'Bitcoin') multiplier += activeScenario.bitcoinImpact;
      else if (asset.type === 'Gold') multiplier += activeScenario.goldImpact;
      else multiplier += (activeScenario.equityImpact * 0.3); // alternatives
    }
    return {
      ...asset,
      value: Math.max(0, asset.value * multiplier)
    };
  });

  const aum = assets.reduce((sum, a) => sum + a.value, 0);
  const cashAvailable = assets.find(a => a.type === 'Cash')?.value ?? 0;

  // Expected portfolio return
  let expectedReturn = calculateWeightedReturn(assets);
  let volatility = calculatePortfolioVolatility(assets);

  if (activeScenario) {
    // Stress scenarios increase market volatility
    const volMultiplier = activeScenario.category === 'Market' ? 1.4 : activeScenario.category === 'Macro' ? 1.25 : 1.1;
    volatility = Math.min(0.8, volatility * volMultiplier);
    expectedReturn = Math.max(-0.25, expectedReturn - (activeScenario.category === 'Macro' ? 0.04 : 0.02));
  }

  const varConfidence = baseSettings.varConfidence;
  const varDaily = calculateParametricVaR(volatility, aum, varConfidence);
  const expectedShortfall = calculateExpectedShortfall(volatility, aum, varConfidence);

  const netTreasuryPosition = cashAvailable + (assets.find(a => a.type === 'Bonds')?.value ?? 0) * 0.4;
  const liquidityRatio = cashAvailable / 500000000; // illustrative denominator: current liabilities (~500M)

  // Debt metrics (illustrative baseline GBP 1.5B)
  let debtOutstanding = 1500000000;
  if (activeScenario) {
    debtOutstanding += activeScenario.constructionCostIncrease * 150000000; // construction overruns funded by debt
  }
  const interestCoverageRatio = Math.max(1.1, (aum * expectedReturn) / (debtOutstanding * baseSettings.interestRateBase));

  // Determine Traffic Light risk rating
  let riskRating: 'Low' | 'Moderate' | 'High' = 'Low';
  const varPct = varDaily / aum;
  if (varPct > 0.045 || activeScenario || volatility > 0.22) {
    riskRating = 'High';
  } else if (varPct > 0.025 || volatility > 0.12) {
    riskRating = 'Moderate';
  }

  // Basel metrics
  const lcr = Math.max(0.6, (cashAvailable + (assets.find(a => a.type === 'Gold')?.value ?? 0) * 0.8) / 450000000);
  const nsfr = Math.max(0.7, (aum * 0.85) / (debtOutstanding * 0.90));

  return {
    aum,
    cashAvailable,
    liquidityRatio,
    netTreasuryPosition,
    expectedReturn,
    volatility,
    varDaily,
    expectedShortfall,
    debtOutstanding,
    interestCoverageRatio,
    riskRating,
    lcr,
    nsfr
  };
}

/**
 * Runs a high-fidelity client-side Monte Carlo simulation of future AUM paths
 */
export function runMonteCarlo(
  initialAum: number,
  expectedReturn: number,
  volatility: number,
  steps: number = 36, // months
  numSimulations: number = 2000, // optimized for UI performance
  inflationRate: number = 0.028,
  targetReturn: number = 0.075
): SimulationResult {
  const dt = 1 / 12; // monthly steps
  const mu = expectedReturn - 0.5 * volatility * volatility;
  const paths: number[][] = Array.from({ length: numSimulations }, () => []);

  // Run paths
  for (let sim = 0; sim < numSimulations; sim++) {
    let currentVal = initialAum;
    for (let step = 0; step < steps; step++) {
      // Box-Muller transform for standard normal random variable
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random() || 0.0001;
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      const dReturn = Math.exp(mu * dt + volatility * Math.sqrt(dt) * z);
      currentVal = currentVal * dReturn;
      // Subtract monthly inflation erosion and small operating expenses (0.2% annually)
      currentVal = currentVal * (1 - (inflationRate + 0.002) / 12);
      paths[sim].push(currentVal);
    }
  }

  // Extract percentiles per step
  const p10: number[] = [];
  const p25: number[] = [];
  const p50: number[] = [];
  const p75: number[] = [];
  const p90: number[] = [];

  for (let step = 0; step < steps; step++) {
    const valuesAtStep = paths.map(p => p[step]).sort((a, b) => a - b);
    p10.push(valuesAtStep[Math.floor(numSimulations * 0.10)]);
    p25.push(valuesAtStep[Math.floor(numSimulations * 0.25)]);
    p50.push(valuesAtStep[Math.floor(numSimulations * 0.50)]);
    p75.push(valuesAtStep[Math.floor(numSimulations * 0.75)]);
    p90.push(valuesAtStep[Math.floor(numSimulations * 0.90)]);
  }

  // Statistics at end step
  const endValues = paths.map(p => p[steps - 1]).sort((a, b) => a - b);
  const lossTrials = endValues.filter(val => val < initialAum).length;
  const targetEndValue = initialAum * Math.pow(1 + targetReturn, steps / 12);
  const targetMetTrials = endValues.filter(val => val >= targetEndValue).length;

  const meanEndValue = endValues.reduce((sum, v) => sum + v, 0) / numSimulations;
  const confidenceInterval: [number, number] = [
    endValues[Math.floor(numSimulations * 0.05)],
    endValues[Math.floor(numSimulations * 0.95)]
  ];

  return {
    percentiles: { p10, p25, p50, p75, p90 },
    probabilityOfLoss: lossTrials / numSimulations,
    probabilityOfTarget: targetMetTrials / numSimulations,
    confidenceInterval,
    meanEndValue
  };
}

/**
 * Models the Yield Curve based on central bank base rate
 */
export function generateYieldCurve(
  baseRate: number,
  shock: 'none' | 'parallel' | 'steepening' | 'flattening' = 'none',
  bps: number = 100
): { maturity: string; rate: number; shockedRate: number }[] {
  const maturities = [
    { label: '3M', term: 0.25 },
    { label: '6M', term: 0.5 },
    { label: '1Y', term: 1.0 },
    { label: '2Y', term: 2.0 },
    { label: '5Y', term: 5.0 },
    { label: '10Y', term: 10.0 },
    { label: '20Y', term: 20.0 },
    { label: '30Y', term: 30.0 }
  ];

  const shift = bps / 10000; // bps to decimals

  return maturities.map(m => {
    // Model standard upward sloping yield curve using Nelson-Siegel style shape
    // Short rates are anchored near baseRate, long rates have term premium
    const termPremium = 0.02 * (1 - Math.exp(-m.term / 8));
    const rate = baseRate + termPremium - 0.005 * Math.exp(-m.term / 2);

    let shockedRate = rate;
    if (shock === 'parallel') {
      shockedRate += shift;
    } else if (shock === 'steepening') {
      // Long rates rise more, short rates anchor
      const scale = m.term / 30; // 0 to 1
      shockedRate += shift * scale;
    } else if (shock === 'flattening') {
      // Short rates rise, long rates fall or stay flat
      const scale = 1 - (m.term / 30); // 1 to 0
      shockedRate += shift * scale;
    }

    return {
      maturity: m.label,
      rate: Number((rate * 100).toFixed(4)),
      shockedRate: Number((shockedRate * 100).toFixed(4))
    };
  });
}

/**
 * Calculates Duration and Convexity sensitivities for Bonds and Infrastructure
 */
export function calculateSensitivities(
  metrics: KPIMetrics,
  bps: number
): { rateShiftPct: number; valueLossGBP: number; newAum: number } {
  // Bonds: duration ~ 6.5 years, convexity ~ 55
  // Infrastructure: duration ~ 11 years, convexity ~ 110
  const bondVal = metrics.aum * 0.234;
  const infraVal = metrics.aum * 0.197;

  const shift = bps / 10000;

  // Duration impact: -D * dY
  // Convexity impact: 0.5 * C * (dY)^2
  const bondLoss = -6.5 * shift * bondVal + 0.5 * 55 * Math.pow(shift, 2) * bondVal;
  const infraLoss = -11.0 * shift * infraVal + 0.5 * 110 * Math.pow(shift, 2) * infraVal;

  const totalLoss = bondLoss + infraLoss;
  return {
    rateShiftPct: bps / 100,
    valueLossGBP: -totalLoss,
    newAum: metrics.aum + totalLoss
  };
}

/**
 * Generates monthly projected Cash Flows
 */
export function generateCashFlowForecast(
  aum: number,
  expectedReturn: number,
  activeScenario: StressScenario | null
): CashFlowItem[] {
  const months = ['Aug 26', 'Sep 26', 'Oct 26', 'Nov 26', 'Dec 26', 'Jan 27', 'Feb 27', 'Mar 27', 'Apr 27', 'May 27', 'Jun 27', 'Jul 27'];
  let cum = 870000000; // start with CashAvailable

  // Baseline monthly returns, capital calls, dividends, debt drawdown
  let ocfBase = 22000000; // Operating cash flow inflows (dividends, yields)
  let icfBase = -35000000; // Investments (capital calls, project funding)
  let fcfBase = 12000000; // Financing (bond proceeds, bank drawdown)

  if (activeScenario) {
    if (activeScenario.id === 'scen-01' || activeScenario.id === 'scen-04') {
      ocfBase *= 0.5; // Recession drops yield dividends
      icfBase *= 1.3; // Distressed capital calls rise
      fcfBase *= 0.6; // Liquidity constraints
    } else if (activeScenario.id === 'scen-11') {
      icfBase *= 1.4; // Infrastructure delays cost more
    }
  }

  return months.map((m, idx) => {
    // Add seasonal fluctuations
    const seasonality = Math.sin((idx / 12) * 2 * Math.PI) * 10000000;
    const operating = ocfBase + (idx * 500000) + (seasonality * 0.3);
    const investment = icfBase - (idx * 800000) + (seasonality * 0.5);
    const financing = fcfBase + (idx % 3 === 0 ? 30000000 : -2000000);

    const net = operating + investment + financing;
    cum += net;

    return {
      period: m,
      operating: Math.round(operating),
      investment: Math.round(investment),
      financing: Math.round(financing),
      net: Math.round(net),
      cumulative: Math.round(cum)
    };
  });
}
