/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PortfolioAsset, Counterparty, FXExposure, InfraProject, StressScenario, Alert, AppSettings } from '../types';

export const INITIAL_SETTINGS: AppSettings = {
  interestRateBase: 0.0525, // 5.25% (BoE)
  targetReturn: 0.075,      // 7.5% annual
  inflationRate: 0.028,     // 2.8%
  hedgingPolicyGBP: 0.75,   // 75% FX hedged
  varConfidence: 0.99,      // 99% VaR
  activeTheme: 'dark',
  simulateRealTimeFeeds: true,
  role: 'Chief Investment Officer'
};

export const INITIAL_ASSETS: PortfolioAsset[] = [
  { type: 'Equities', value: 1550000000, allocation: 0.165, volatility: 0.18, expectedReturn: 0.09, beta: 1.15 },
  { type: 'Bonds', value: 2200000000, allocation: 0.234, volatility: 0.06, expectedReturn: 0.045, beta: 0.15 },
  { type: 'Property', value: 850000000, allocation: 0.090, volatility: 0.12, expectedReturn: 0.065, beta: 0.45 },
  { type: 'Infrastructure', value: 1850000000, allocation: 0.197, volatility: 0.08, expectedReturn: 0.115, beta: 0.30 },
  { type: 'Private Equity', value: 1200000000, allocation: 0.128, volatility: 0.24, expectedReturn: 0.13, beta: 1.40 },
  { type: 'Bitcoin', value: 380000000, allocation: 0.040, volatility: 0.55, expectedReturn: 0.35, beta: 1.85 },
  { type: 'Gold', value: 420000000, allocation: 0.045, volatility: 0.14, expectedReturn: 0.05, beta: -0.05 },
  { type: 'Cash', value: 870000000, allocation: 0.093, volatility: 0.01, expectedReturn: 0.0525, beta: 0.00 },
  { type: 'Alternatives', value: 80000000, allocation: 0.008, volatility: 0.16, expectedReturn: 0.08, beta: 0.60 }
];

export const INITIAL_COUNTERPARTIES: Counterparty[] = [
  { id: 'cp-01', name: 'Barclays Bank Plc', rating: 'A', exposure: 245000000, limit: 300000000, pd: 0.0035, lgd: 0.40, expectedLoss: 343000 },
  { id: 'cp-02', name: 'Lloyds Banking Group', rating: 'A', exposure: 180000000, limit: 250000000, pd: 0.0028, lgd: 0.40, expectedLoss: 201600 },
  { id: 'cp-03', name: 'J.P. Morgan Securities', rating: 'AA', exposure: 320000000, limit: 400000000, pd: 0.0008, lgd: 0.35, expectedLoss: 89600 },
  { id: 'cp-04', name: 'Goldman Sachs International', rating: 'AA', exposure: 290000000, limit: 350000000, pd: 0.0012, lgd: 0.35, expectedLoss: 121800 },
  { id: 'cp-05', name: 'HSBC Bank Plc', rating: 'AA', exposure: 410000000, limit: 500000000, pd: 0.0006, lgd: 0.40, expectedLoss: 98400 },
  { id: 'cp-06', name: 'BNP Paribas S.A.', rating: 'A', exposure: 150000000, limit: 200000000, pd: 0.0032, lgd: 0.45, expectedLoss: 216000 },
  { id: 'cp-07', name: 'UBS AG Group', rating: 'A', exposure: 220000000, limit: 250000000, pd: 0.0025, lgd: 0.40, expectedLoss: 220000 },
  { id: 'cp-08', name: 'Citibank N.A. London', rating: 'A', exposure: 135000000, limit: 200000000, pd: 0.0018, lgd: 0.38, expectedLoss: 92340 }
];

export const INITIAL_FX_EXPOSURES: FXExposure[] = [
  { currency: 'GBP', holdings: 4850000000, rate: 1.0000, costBasis: 1.0000, valueGBP: 4850000000, gainLossGBP: 0, hedgingRatio: 1.00, sensitivity: 0 },
  { currency: 'USD', holdings: 2850000000, rate: 1.2850, costBasis: 1.2420, valueGBP: 2217898833, gainLossGBP: 74218320, hedgingRatio: 0.80, sensitivity: -44357976 },
  { currency: 'EUR', holdings: 1100000000, rate: 1.1820, costBasis: 1.1550, valueGBP: 930626058, gainLossGBP: 21250420, hedgingRatio: 0.70, sensitivity: -27918781 },
  { currency: 'CHF', holdings: 350000000, rate: 1.1340, costBasis: 1.1120, valueGBP: 308641975, gainLossGBP: 6112930, hedgingRatio: 0.60, sensitivity: -12345679 },
  { currency: 'JPY', holdings: 55000000000, rate: 198.50, costBasis: 192.10, valueGBP: 277078086, gainLossGBP: 9193400, hedgingRatio: 0.50, sensitivity: -13853904 },
  { currency: 'CAD', holdings: 250000000, rate: 1.7630, costBasis: 1.7310, valueGBP: 141803744, gainLossGBP: 2623100, hedgingRatio: 0.40, sensitivity: -8508225 },
  { currency: 'AUD', holdings: 180000000, rate: 1.9420, costBasis: 1.8950, valueGBP: 92687951, gainLossGBP: 2241500, hedgingRatio: 0.30, sensitivity: -6488157 },
  { currency: 'BTC', holdings: 7200, rate: 0.000021, costBasis: 38500, valueGBP: 380000000, gainLossGBP: 102800000, hedgingRatio: 0.00, sensitivity: -38000000 }
];

export const INITIAL_INFRA_PROJECTS: InfraProject[] = [
  { id: 'inf-01', name: 'Snaefell Railway Modernisation & Extension', category: 'Railway', constructionRisk: 15, politicalRisk: 5, regulatoryRisk: 10, operatingRisk: 12, revenueRisk: 18, demandRisk: 15, baselineIRR: 0.095, currentIRR: 0.098, cost: 180000000, revenue: 21500000, score: 92 },
  { id: 'inf-02', name: 'Douglas Deepwater Port Terminal & Quay Expansion', category: 'Port', constructionRisk: 35, politicalRisk: 12, regulatoryRisk: 22, operatingRisk: 15, revenueRisk: 14, demandRisk: 10, baselineIRR: 0.112, currentIRR: 0.108, cost: 310000000, revenue: 39500000, score: 81 },
  { id: 'inf-03', name: 'Glenfaba Biomass & Clean Natural Gas Peak Plants', category: 'Power Station', constructionRisk: 42, politicalRisk: 18, regulatoryRisk: 35, operatingRisk: 28, revenueRisk: 25, demandRisk: 12, baselineIRR: 0.125, currentIRR: 0.119, cost: 240000000, revenue: 32000000, score: 76 },
  { id: 'inf-04', name: 'Isle of Man Offshore Wind Farm Phase II (Ramsey)', category: 'Wind Farm', constructionRisk: 55, politicalRisk: 8, regulatoryRisk: 40, operatingRisk: 32, revenueRisk: 20, demandRisk: 5, baselineIRR: 0.142, currentIRR: 0.138, cost: 450000000, revenue: 64000000, score: 79 },
  { id: 'inf-05', name: 'Sulby Valley Managed Commercial Forestry & Carbon Sink', category: 'Forestry', constructionRisk: 10, politicalRisk: 5, regulatoryRisk: 15, operatingRisk: 10, revenueRisk: 22, demandRisk: 25, baselineIRR: 0.078, currentIRR: 0.079, cost: 95000000, revenue: 8200000, score: 88 },
  { id: 'inf-06', name: 'North Douglas Sustainable Eco-Housing Complex', category: 'Housing', constructionRisk: 25, politicalRisk: 15, regulatoryRisk: 20, operatingRisk: 18, revenueRisk: 15, demandRisk: 8, baselineIRR: 0.105, currentIRR: 0.106, cost: 160000000, revenue: 19800000, score: 85 },
  { id: 'inf-07', name: 'Jurby Tier-IV Hyperscale Sustainable Data Centre', category: 'Data Centre', constructionRisk: 30, politicalRisk: 5, regulatoryRisk: 12, operatingRisk: 20, revenueRisk: 18, demandRisk: 15, baselineIRR: 0.155, currentIRR: 0.158, cost: 280000000, revenue: 44000000, score: 91 },
  { id: 'inf-08', name: 'Castletown Seawater Desalination Plant & Distribution Grid', category: 'Water', constructionRisk: 48, politicalRisk: 10, regulatoryRisk: 28, operatingRisk: 25, revenueRisk: 12, demandRisk: 5, baselineIRR: 0.088, currentIRR: 0.084, cost: 135000000, revenue: 13200000, score: 78 },
  { id: 'inf-09', name: 'Snaefell Mountain Course Hybrid Safety Super-Highway', category: 'Road', constructionRisk: 20, politicalRisk: 8, regulatoryRisk: 15, operatingRisk: 14, revenueRisk: 35, demandRisk: 40, baselineIRR: 0.082, currentIRR: 0.079, cost: 100000000, revenue: 9500000, score: 83 }
];

export const INST_STRESS_SCENARIOS: StressScenario[] = [
  {
    id: 'scen-01',
    name: 'Global Recession',
    description: 'Severe multi-year global contraction, central banks slash rates, equities plummet, alternatives and infrastructure suffer from lack of demand.',
    category: 'Macro',
    equityImpact: -0.30,
    bondImpact: 0.08, // flight to safety
    propertyImpact: -0.20,
    infraImpact: -0.12,
    bitcoinImpact: -0.55,
    goldImpact: 0.15,
    yieldShiftBps: -150,
    fxShock: 0.05,
    constructionCostIncrease: -0.05, // deflation
    operationalCostIncrease: -0.02
  },
  {
    id: 'scen-02',
    name: 'High Stagflation',
    description: 'Supply chain friction and resource shortage. Inflation spikes to 9%, bond prices drop due to rate hikes, gold and commodities rally.',
    category: 'Macro',
    equityImpact: -0.15,
    bondImpact: -0.12,
    propertyImpact: 0.05, // real estate keeps value
    infraImpact: 0.02, // inflation-linked revenue
    bitcoinImpact: 0.15, // digital gold hedge
    goldImpact: 0.30,
    yieldShiftBps: 250,
    fxShock: -0.05,
    constructionCostIncrease: 0.25,
    operationalCostIncrease: 0.18
  },
  {
    id: 'scen-03',
    name: 'Interest Rate Shock (+350bps)',
    description: 'Sovereign inflation alarm triggers 350 basis points rate hike by BoE, Fed, and ECB. Drastic drop in long duration bond prices, debt-servicing stress.',
    category: 'Market',
    equityImpact: -0.18,
    bondImpact: -0.15,
    propertyImpact: -0.15,
    infraImpact: -0.08,
    bitcoinImpact: -0.30,
    goldImpact: -0.05,
    yieldShiftBps: 350,
    fxShock: 0.08,
    constructionCostIncrease: 0.08,
    operationalCostIncrease: 0.05
  },
  {
    id: 'scen-04',
    name: 'Equity Market Crash (-35%)',
    description: 'Idiosyncratic tech-bubble bursting and global stock market rout. Panic sell-off across global exchanges, high-volatility regime.',
    category: 'Market',
    equityImpact: -0.35,
    bondImpact: 0.04,
    propertyImpact: -0.08,
    infraImpact: -0.05,
    bitcoinImpact: -0.40,
    goldImpact: 0.08,
    yieldShiftBps: -50,
    fxShock: 0.02,
    constructionCostIncrease: 0.00,
    operationalCostIncrease: 0.00
  },
  {
    id: 'scen-05',
    name: 'Sovereign Property Crash',
    description: 'Commercial real estate crisis triggers commercial defaults. Land values drop, infrastructure yield curves steepen, private equity devaluations.',
    category: 'Market',
    equityImpact: -0.10,
    bondImpact: 0.02,
    propertyImpact: -0.30,
    infraImpact: -0.05,
    bitcoinImpact: -0.05,
    goldImpact: 0.05,
    yieldShiftBps: -25,
    fxShock: -0.02,
    constructionCostIncrease: -0.10,
    operationalCostIncrease: -0.04
  },
  {
    id: 'scen-06',
    name: 'Energy Crisis & Utility Gridlock',
    description: 'Severe geopolitical tension results in a 100% surge in electricity prices. High stress on operations, but windfall gains for Laxey offshore wind farm.',
    category: 'Macro',
    equityImpact: -0.12,
    bondImpact: -0.04,
    propertyImpact: -0.05,
    infraImpact: 0.15, // wind and power stations yield surges
    bitcoinImpact: -0.20, // high mining energy costs
    goldImpact: 0.10,
    yieldShiftBps: 75,
    fxShock: 0.00,
    constructionCostIncrease: 0.15,
    operationalCostIncrease: 0.35
  },
  {
    id: 'scen-07',
    name: 'Currency Crisis (Sterling Devaluation)',
    description: 'UK fiscal crisis triggers massive flight of capital. GBP devalues by 20% against USD/EUR. Foreign assets gain in sterling terms, extreme hedging pressure.',
    category: 'Macro',
    equityImpact: -0.05,
    bondImpact: -0.08,
    propertyImpact: 0.10, // nominal value rises
    infraImpact: 0.05,
    bitcoinImpact: 0.35, // BTC rallies in GBP
    goldImpact: 0.25,
    yieldShiftBps: 180,
    fxShock: -0.20, // GBP drops
    constructionCostIncrease: 0.20, // imported materials spike
    operationalCostIncrease: 0.12
  },
  {
    id: 'scen-08',
    name: 'Commodity Spike & Resource Rush',
    description: 'Supply disruption of critical resources. Gold jumps to $3,000/oz. Construction costs spike across all railway, road and port projects.',
    category: 'Macro',
    equityImpact: -0.08,
    bondImpact: -0.05,
    propertyImpact: 0.05,
    infraImpact: -0.02,
    bitcoinImpact: 0.10,
    goldImpact: 0.40,
    yieldShiftBps: 50,
    fxShock: -0.01,
    constructionCostIncrease: 0.30,
    operationalCostIncrease: 0.15
  },
  {
    id: 'scen-09',
    name: 'Bitcoin Bull Market (Hyper-adoption)',
    description: 'Institutional hyper-adoption of digital assets. Spot ETF inflows double, BTC surges 150%, Ellan Vannin Bitcoin treasury exceeds cash holdings.',
    category: 'Crypto',
    equityImpact: 0.05,
    bondImpact: -0.01,
    propertyImpact: 0.00,
    infraImpact: 0.02,
    bitcoinImpact: 1.50,
    goldImpact: -0.10,
    yieldShiftBps: 15,
    fxShock: 0.05,
    constructionCostIncrease: 0.02,
    operationalCostIncrease: 0.02
  },
  {
    id: 'scen-10',
    name: 'Bitcoin Bear Market (Crypto Winter)',
    description: 'Severe regulatory crackdown on off-shore custody. DeFi liquidity dried up, BTC crashes 75%, testing cold storage and cash reserves.',
    category: 'Crypto',
    equityImpact: -0.03,
    bondImpact: 0.01,
    propertyImpact: 0.00,
    infraImpact: 0.00,
    bitcoinImpact: -0.75,
    goldImpact: 0.03,
    yieldShiftBps: -10,
    fxShock: -0.02,
    constructionCostIncrease: 0.00,
    operationalCostIncrease: 0.00
  },
  {
    id: 'scen-11',
    name: 'Sovereign Infrastructure Delay',
    description: 'Extreme delays in Port Douglas and Jurby Data Centre due to environmental licensing and resource shortages. Costs spike 20%, immediate IRR deterioration.',
    category: 'Idiosyncratic',
    equityImpact: -0.02,
    bondImpact: 0.00,
    propertyImpact: -0.02,
    infraImpact: -0.15, // infra valuation devalued
    bitcoinImpact: 0.00,
    goldImpact: 0.02,
    yieldShiftBps: 10,
    fxShock: -0.01,
    constructionCostIncrease: 0.20,
    operationalCostIncrease: 0.10
  }
];

export const INITIAL_ALERTS: Alert[] = [
  { id: 'al-01', timestamp: '2026-07-23 09:12:04', category: 'Risk Limit', message: 'Daily parametric VaR (99% confidence) reached 3.42%, approaching soft limit of 3.50%.', severity: 'Moderate', resolved: false },
  { id: 'al-02', timestamp: '2026-07-23 11:45:12', category: 'Currency', message: 'USD Net Exposure increased past £2.2B following options contract rollover.', severity: 'Low', resolved: false },
  { id: 'al-03', timestamp: '2026-07-22 14:02:55', category: 'Operations', message: 'Douglas Deepwater Port construction cost index rose by 4.2% due to steel import tariffs.', severity: 'Moderate', resolved: false },
  { id: 'al-04', timestamp: '2026-07-20 08:30:00', category: 'Counterparty', message: 'Barclays Bank Plc credit rating outlook revised to Negative by S&P; monitoring risk concentration.', severity: 'Low', resolved: false }
];

export const CORRELATION_MATRIX: Record<string, Record<string, number>> = {
  'Equities': { 'Equities': 1.00, 'Bonds': 0.12, 'Property': 0.38, 'Infrastructure': 0.28, 'Private Equity': 0.78, 'Bitcoin': 0.45, 'Gold': 0.05, 'Cash': 0.00, 'Alternatives': 0.35 },
  'Bonds': { 'Equities': 0.12, 'Bonds': 1.00, 'Property': 0.05, 'Infrastructure': 0.15, 'Private Equity': 0.08, 'Bitcoin': -0.10, 'Gold': 0.22, 'Cash': 0.15, 'Alternatives': 0.10 },
  'Property': { 'Equities': 0.38, 'Bonds': 0.05, 'Property': 1.00, 'Infrastructure': 0.45, 'Private Equity': 0.42, 'Bitcoin': 0.15, 'Gold': 0.12, 'Cash': 0.00, 'Alternatives': 0.25 },
  'Infrastructure': { 'Equities': 0.28, 'Bonds': 0.15, 'Property': 0.45, 'Infrastructure': 1.00, 'Private Equity': 0.32, 'Bitcoin': 0.10, 'Gold': 0.18, 'Cash': 0.05, 'Alternatives': 0.20 },
  'Private Equity': { 'Equities': 0.78, 'Bonds': 0.08, 'Property': 0.42, 'Infrastructure': 0.32, 'Private Equity': 1.00, 'Bitcoin': 0.50, 'Gold': 0.02, 'Cash': 0.00, 'Alternatives': 0.40 },
  'Bitcoin': { 'Equities': 0.45, 'Bonds': -0.10, 'Property': 0.15, 'Infrastructure': 0.10, 'Private Equity': 0.50, 'Bitcoin': 1.00, 'Gold': 0.15, 'Cash': -0.05, 'Alternatives': 0.22 },
  'Gold': { 'Equities': 0.05, 'Bonds': 0.22, 'Property': 0.12, 'Infrastructure': 0.18, 'Private Equity': 0.02, 'Bitcoin': 0.15, 'Gold': 1.00, 'Cash': 0.05, 'Alternatives': 0.18 },
  'Cash': { 'Equities': 0.00, 'Bonds': 0.15, 'Property': 0.00, 'Infrastructure': 0.05, 'Private Equity': 0.00, 'Bitcoin': -0.05, 'Gold': 0.05, 'Cash': 1.00, 'Alternatives': 0.00 },
  'Alternatives': { 'Equities': 0.35, 'Bonds': 0.10, 'Property': 0.25, 'Infrastructure': 0.20, 'Private Equity': 0.40, 'Bitcoin': 0.22, 'Gold': 0.18, 'Cash': 0.00, 'Alternatives': 1.00 }
};

export const BASELINE_CASH_RUNWAY_MONTHS = 18.5;
export const DEBT_FACILITIES_LIST = [
  { id: 'debt-01', type: 'Sovereign-Backed Bond', amount: 450000000, rate: 0.0425, issueDate: '2022-04-15', maturityDate: '2032-04-15', coverageRatio: 3.8 },
  { id: 'debt-02', type: 'Syndicated Green Infrastructure Facility', amount: 650000000, rate: 0.0485, issueDate: '2023-09-30', maturityDate: '2029-09-30', coverageRatio: 4.2 },
  { id: 'debt-03', type: 'Institutional Revolving Credit (RCF)', amount: 250000000, rate: 0.0575, issueDate: '2024-01-10', maturityDate: '2027-01-10', coverageRatio: 2.9 },
  { id: 'debt-04', type: 'Liquidity Bridge Backstop', amount: 150000000, rate: 0.0625, issueDate: '2025-06-01', maturityDate: '2026-12-31', coverageRatio: 5.1 }
];
