/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { KPIMetrics, AppSettings, StressScenario, Alert, PortfolioAsset, Counterparty, FXExposure, InfraProject } from '../../types';
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, AreaChart, Area } from 'recharts';
import { Play, Sliders, TrendingUp, AlertTriangle, RefreshCw, FileText, Download, CheckCircle, Terminal, Cpu, Database, Network, ChevronRight, Check } from 'lucide-react';

interface ViewProps {
  metrics: KPIMetrics;
  settings: AppSettings;
  assets: PortfolioAsset[];
  counterparties: Counterparty[];
  fxExposures: FXExposure[];
  infraProjects: InfraProject[];
  alerts: Alert[];
  activeScenario: StressScenario | null;
  onUpdateSettings: (s: AppSettings) => void;
  onSelectScenario: (scen: StressScenario | null) => void;
  onResolveAlert: (id: string) => void;
}

export function DashboardView({ metrics, settings, assets, alerts, activeScenario, onSelectScenario }: ViewProps) {
  const [ratesFeed, setRatesFeed] = useState<any[]>([]);
  const [isLoadingFeed, setIsLoadingFeed] = useState<boolean>(false);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const fetchRatesFeed = async () => {
    setIsLoadingFeed(true);
    try {
      const response = await fetch('/api/feeds/rates');
      const data = await response.json();
      setRatesFeed(data.feeds || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingFeed(false);
    }
  };

  useEffect(() => {
    fetchRatesFeed();
  }, []);

  return (
    <div className="space-y-6" id="dashboard-view">
      <div className="flex justify-between items-center border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Executive Executive Command Centre</h2>
          <p className="text-xs text-slate-400">Institutional overview of capital reserves, risk matrices, and sovereign treasury limits.</p>
        </div>
        <button
          onClick={fetchRatesFeed}
          disabled={isLoadingFeed}
          className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded text-xs text-slate-300 hover:text-slate-100 transition-colors flex items-center gap-1.5 font-semibold"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFeed ? 'animate-spin' : ''}`} />
          Sync Market Feeds
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">AUM Capital Scale</span>
            <div className="text-2xl font-bold font-mono text-slate-100 mt-2">{formatGBP(metrics.aum)}</div>
            <p className="text-[10px] text-slate-500 mt-1">Aggregated multi-asset custody positions.</p>
          </div>
          <div className="text-[10px] text-emerald-400 font-bold mt-4 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active Hedge Target Compliance
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Ex-Ante Volatility</span>
            <div className="text-2xl font-bold font-mono text-slate-100 mt-2">{(metrics.volatility * 100).toFixed(2)}%</div>
            <p className="text-[10px] text-slate-500 mt-1">Sovereign target margin: &lt; 15.0%</p>
          </div>
          <div className="text-[10px] text-slate-400 mt-4">
            Systematic Beta: <span className="font-bold text-sky-400">0.42 ex-ante benchmark</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Active Alarms Log</span>
            <div className="text-2xl font-bold font-mono text-amber-400 mt-2">{alerts.filter(a => !a.resolved).length} Unresolved</div>
            <p className="text-[10px] text-slate-500 mt-1">Risk limits and liquidity checks.</p>
          </div>
          <div className="text-[10px] text-slate-400 mt-4">
            Severity level: <span className="font-bold text-amber-500 uppercase">Moderate Threshold</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Central Bank Policy & Market Spot Feeds</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ratesFeed.map((feed, idx) => (
              <div key={idx} className="bg-slate-950 p-3 rounded border border-slate-850 flex justify-between items-center text-xs">
                <div>
                  <div className="font-semibold text-slate-300">{feed.name}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{feed.status} Feed</div>
                </div>
                <div className="text-right font-mono">
                  <div className="font-bold text-slate-100">{feed.name.includes('Rate') || feed.name.includes('EUR') || feed.name.includes('USD') ? `${(feed.rate * 100).toFixed(2)}%` : feed.rate.toLocaleString()}</div>
                  <div className={`text-[10px] font-bold ${feed.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {feed.change >= 0 ? '+' : ''}{feed.change}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Sovereign Risk Level Indicator</h3>
            <div className="flex items-center gap-3 bg-slate-950 p-4 rounded border border-slate-850 mt-2">
              <span className={`w-4.5 h-4.5 rounded-full ${
                metrics.riskRating === 'Low' ? 'bg-emerald-500' : metrics.riskRating === 'Moderate' ? 'bg-amber-500' : 'bg-rose-500'
              }`} />
              <div>
                <div className="font-bold text-sm text-slate-100 uppercase">{metrics.riskRating} Risk Designate</div>
                <p className="text-[10px] text-slate-500 mt-0.5">Compliant with Bank of England stability standards.</p>
              </div>
            </div>
          </div>
          <p className="text-[10px] text-slate-400 mt-4 leading-relaxed bg-slate-950/40 p-2.5 rounded border border-slate-850">
            <strong>Active Stress Vector:</strong> {activeScenario ? activeScenario.name : 'None. Balance sheet is resting at baseline standard valuation.'}
          </p>
        </div>
      </div>
    </div>
  );
}

export function AlertsView({ alerts, onResolveAlert }: ViewProps) {
  const formatTime = (ts: string) => ts;

  return (
    <div className="space-y-6" id="alerts-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">RTE Alerts System</h2>
        <p className="text-xs text-slate-400">Centralized monitor for Basel liquidity metrics breaches, rating downgrades, and portfolio overruns.</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Active Real-Time Alerts</h3>
          <span className="text-[10px] text-slate-500">Auto-refresh active</span>
        </div>
        <div className="divide-y divide-slate-850">
          {alerts.map((al) => (
            <div key={al.id} className={`p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${al.resolved ? 'opacity-40' : ''}`}>
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 text-[9px] font-bold rounded uppercase tracking-wider border ${
                    al.severity === 'High' ? 'bg-rose-950/50 border-rose-900 text-rose-400' : 'bg-amber-950/30 border-amber-900 text-amber-400'
                  }`}>
                    {al.severity} Severity
                  </span>
                  <span className="text-[10px] text-slate-500 font-semibold font-mono">{formatTime(al.timestamp)}</span>
                </div>
                <div className="text-xs font-semibold text-slate-200">{al.message}</div>
              </div>
              <div className="shrink-0 flex items-center gap-2">
                {!al.resolved ? (
                  <button
                    onClick={() => onResolveAlert(al.id)}
                    className="bg-slate-950 border border-slate-800 px-3 py-1 rounded text-[10px] text-emerald-400 font-bold hover:text-emerald-300 transition-colors"
                  >
                    Resolve Alert
                  </button>
                ) : (
                  <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500" /> Resolved
                  </span>
                )}
              </div>
            </div>
          ))}
          {alerts.length === 0 && (
            <div className="p-6 text-center text-xs text-slate-500">Zero active alerts reported on balance sheet.</div>
          )}
        </div>
      </div>
    </div>
  );
}

export function ReportsView({ metrics, activeScenario, assets, counterparties, fxExposures }: ViewProps) {
  const [selectedSection, setSelectedSection] = useState<string>('Executive Summary');
  const [commentary, setCommentary] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const generateAIOpinion = async () => {
    setIsGenerating(true);
    setCommentary('');
    try {
      const response = await fetch('/api/gemini/commentary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          metrics,
          activeScenario,
          sectionName: selectedSection,
          assets,
          counterparties,
          fxExposures
        })
      });
      const data = await response.json();
      setCommentary(data.commentary || 'No commentary returned.');
    } catch (e: any) {
      setCommentary(`Error generating commentary: ${e.message || 'Server unavailable.'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    generateAIOpinion();
  }, [selectedSection, activeScenario]);

  return (
    <div className="space-y-6" id="reports-view">
      <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Board Risk & Treasury Report Generator</h2>
          <p className="text-xs text-slate-400">Generate, customize, and export institutional-grade commentaries and quantitative summaries.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => window.print()}
            className="bg-sky-900/40 text-sky-400 border border-sky-800 px-4 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Export PDF Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-1.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 p-2 border-b border-slate-850">Report Sub-sections</h3>
          {['Executive Summary', 'Treasury & Liquidity', 'MSCI Portfolio Risk', 'Counterparty Credit', 'Sovereign Gilt Yields'].map((sect) => (
            <button
              key={sect}
              onClick={() => setSelectedSection(sect)}
              className={`w-full text-left px-3 py-2 text-xs rounded transition-all ${
                selectedSection === sect
                  ? 'bg-sky-950/40 border border-sky-800 text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {sect}
            </button>
          ))}
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg space-y-4">
            <div className="flex justify-between items-center border-b border-slate-850 pb-3">
              <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-sky-400" /> Quantitative Report Section Commentary
              </h3>
              <button
                onClick={generateAIOpinion}
                disabled={isGenerating}
                className="text-xs text-sky-400 font-bold hover:text-sky-300 flex items-center gap-1 transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${isGenerating ? 'animate-spin' : ''}`} /> Re-Generate
              </button>
            </div>

            {isGenerating ? (
              <div className="py-20 text-center text-xs text-slate-500 space-y-2">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto text-sky-400 mb-2" />
                <span>Generating senior board commentary using Gemini-3.6-flash...</span>
              </div>
            ) : (
              <div className="text-slate-300 text-xs leading-relaxed space-y-4 font-sans whitespace-pre-line border border-slate-850 p-4 rounded bg-slate-950/40">
                {commentary}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function RShinyCodeHubView() {
  const [selectedFile, setSelectedFile] = useState<string>('app.R');

  const files: Record<string, string> = {
    'app.R': `# ==========================================
# Ellan Vannin Wealth Management
# Risk & Treasury Engine (RTE)
# Primary Entry Point: app.R
# ==========================================

library(shiny)
library(shinydashboard)
library(bslib)
library(plotly)
library(ggplot2)
library(DT)
library(reactable)
library(dplyr)
library(tidyr)
library(data.table)
library(PerformanceAnalytics)
library(tidyquant)
library(quantmod)
library(TTR)
library(forecast)
library(lubridate)
library(scales)

# Source configuration & modular engines
source("R/config.R")
source("R/dashboard.R")
source("R/treasury_engine.R")
source("R/risk_engine.R")
source("R/liquidity_engine.R")
source("R/market_risk.R")
source("R/credit_risk.R")
source("R/interest_rate_risk.R")
source("R/currency_risk.R")
source("R/stress_testing.R")
source("R/monte_carlo.R")

# Run primary R Shiny Dashboard
shinyApp(ui, server)`,

    'R/config.R': `# ==========================================
# Configuration & Constants: config.R
# ==========================================

default_settings <- function() {
  list(
    interestRateBase = 0.0525,
    targetReturn = 0.0750,
    inflationRate = 0.0280,
    varConfidence = 0.99
  )
}

default_assets <- function() {
  data.frame(
    type = c('Equities', 'Bonds', 'Property', 'Infrastructure', 'Private Equity', 'Bitcoin', 'Gold', 'Cash', 'Alternatives'),
    value = c(1550000000, 2200000000, 850000000, 1850000000, 1200000000, 380000000, 420000000, 870000000, 80000000),
    volatility = c(0.18, 0.06, 0.12, 0.08, 0.24, 0.55, 0.14, 0.01, 0.16)
  )
}`,

    'R/treasury_engine.R': `# ==========================================
# Treasury Forecast Engine: treasury_engine.R
# ==========================================

calculate_cash_runway <- function(cash, monthly_burn) {
  if (monthly_burn <= 0) return(99)
  return(cash / monthly_burn)
}

forecast_treasury <- function(initial_position, periods = 12) {
  # Build projection of cash equivalents
  dt <- data.table(
    Period = 1:periods,
    GovtBonds = initial_position * 0.4,
    Cash = initial_position * 0.6
  )
  return(dt)
}`,

    'R/risk_engine.R': `# ==========================================
# Portfolio Statistics Engine: risk_engine.R
# ==========================================

calculate_portfolio_volatility <- function(weights, sigmas, correlation_matrix) {
  # Volatility of multi-asset portfolio: sqrt(w' * Sigma * w)
  covariance <- diag(sigmas) %*% correlation_matrix %*% diag(sigmas)
  variance <- t(weights) %*% covariance %*% weights
  return(sqrt(as.numeric(variance)))
}`
  };

  return (
    <div className="space-y-6" id="rshiny-codehub">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100 font-sans">R Shiny Code Hub</h2>
        <p className="text-xs text-slate-400 font-sans">Browse, copy, and export production-ready R code files and independent R engine modules.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-1.5 font-sans">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 p-2 border-b border-slate-850 flex items-center gap-1.5">
            <Database className="w-4 h-4 text-sky-400" /> R Directory Tree
          </h3>
          {Object.keys(files).map((fName) => (
            <button
              key={fName}
              onClick={() => setSelectedFile(fName)}
              className={`w-full text-left px-3 py-2 text-xs rounded transition-all flex items-center gap-2 ${
                selectedFile === fName
                  ? 'bg-sky-950/40 border border-sky-800 text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Terminal className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">{fName}</span>
            </button>
          ))}
        </div>

        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-lg overflow-hidden flex flex-col h-[500px]">
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex justify-between items-center text-xs font-sans">
            <span className="font-mono text-slate-400">{selectedFile}</span>
            <button
              onClick={() => navigator.clipboard.writeText(files[selectedFile])}
              className="text-sky-400 font-bold hover:text-sky-300 text-[10px] uppercase border border-slate-800 px-2.5 py-0.5 rounded bg-slate-950"
            >
              Copy Code
            </button>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-300 overflow-auto flex-1 leading-relaxed whitespace-pre bg-slate-950">
            <code>{files[selectedFile]}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}

export function SettingsView({ settings, onUpdateSettings }: ViewProps) {
  const [role, setRole] = useState<'Risk Officer' | 'Treasurer' | 'Chief Investment Officer' | 'Administrator'>(settings.role);
  const [varConf, setVarConf] = useState<number>(settings.varConfidence);
  const [targetRet, setTargetRet] = useState<number>(settings.targetReturn);

  const handleSaveSettings = () => {
    onUpdateSettings({
      ...settings,
      role,
      varConfidence: varConf,
      targetReturn: targetRet
    });
  };

  return (
    <div className="space-y-6" id="settings-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">System Parameters & Role Settings</h2>
        <p className="text-xs text-slate-400">Configure global macroeconomic assumptions, simulation boundaries, and access privileges.</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-6 rounded-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Authorized User Role</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded p-2 font-semibold"
            >
              <option value="Risk Officer">Risk Officer (Ex-Ante Portfolio Risk focus)</option>
              <option value="Treasurer">Treasurer (Liquidity & Cashflows focus)</option>
              <option value="Chief Investment Officer">Chief Investment Officer (Macro Strategy focus)</option>
              <option value="Administrator">System Administrator</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Target Portfolio Return (Annualized)</label>
            <select
              value={targetRet}
              onChange={(e) => setTargetRet(parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded p-2 font-semibold"
            >
              <option value={0.065}>6.50% (Sovereign conservative)</option>
              <option value={0.075}>7.50% (Standard board target)</option>
              <option value={0.090}>9.00% (Aggressive multi-asset)</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Value-at-Risk Confidence Interval</label>
            <select
              value={varConf}
              onChange={(e) => setVarConf(parseFloat(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded p-2 font-semibold"
            >
              <option value={0.95}>95.0% Confidence (Standard Margin)</option>
              <option value={0.99}>99.0% Confidence (Basel III Standard)</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Real-time Feed Simulation</label>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400 font-medium">Automatic background price ticks</span>
              <span className="text-emerald-400 font-bold uppercase text-[10px]">Active</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleSaveSettings}
          className="bg-sky-900/60 text-sky-400 border border-sky-850 hover:bg-sky-850/80 px-5 py-2 rounded text-xs font-bold transition-all"
        >
          Save Assumptions & Access Role
        </button>
      </div>
    </div>
  );
}
