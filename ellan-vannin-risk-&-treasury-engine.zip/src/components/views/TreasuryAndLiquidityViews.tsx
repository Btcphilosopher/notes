/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KPIMetrics, AppSettings, CashFlowItem } from '../../types';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { DEBT_FACILITIES_LIST } from '../../data/mockRiskData';
import { generateCashFlowForecast } from '../../utils/riskCalculations';
import { Lock, HelpCircle, Shield, TrendingUp, AlertTriangle } from 'lucide-react';

interface ViewProps {
  metrics: KPIMetrics;
  settings: AppSettings;
  cashFlows: CashFlowItem[];
}

export function TreasuryView({ metrics, settings, cashFlows }: ViewProps) {
  const [forecastHorizon, setForecastHorizon] = useState<'monthly' | 'quarterly' | 'annual'>('monthly');

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="treasury-view-container">
      <div className="flex justify-between items-center border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Treasury Control Panel</h2>
          <p className="text-xs text-slate-400">Manage cash equivalents, liquidity buffers, and committed debt schedules.</p>
        </div>
        <div className="flex gap-2">
          {['monthly', 'quarterly', 'annual'].map((hor) => (
            <button
              key={hor}
              onClick={() => setForecastHorizon(hor as any)}
              className={`px-3 py-1 text-xs font-semibold rounded uppercase transition-colors ${
                forecastHorizon === hor
                  ? 'bg-sky-900/40 text-sky-400 border border-sky-800'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {hor}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Liquidity Buffer</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">{formatGBP(metrics.netTreasuryPosition)}</div>
          <p className="text-[10px] text-slate-500 mt-2">Cash + 40% Govt Bonds hair-cut</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Cash Runway</div>
          <div className="text-xl font-bold text-amber-400 mt-1">18.5 Months</div>
          <p className="text-[10px] text-slate-500 mt-2">Based on current capital calls rate</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">LCR Ratio</div>
          <div className="text-xl font-bold text-sky-400 mt-1">{(metrics.lcr).toFixed(2)}x</div>
          <p className="text-[10px] text-slate-500 mt-2">Basel III standard (Limit &gt; 1.0x)</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">Sovereign Cost of Debt</div>
          <div className="text-xl font-bold text-slate-100 mt-1">{(settings.interestRateBase * 100).toFixed(2)}%</div>
          <p className="text-[10px] text-slate-500 mt-2">Linked to Bank of England policy</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-sky-400" />
            Treasury Cash Forecast Timeline (Sterling)
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={cashFlows} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCash" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="period" stroke="#64748b" fontSize={10} />
                <YAxis
                  stroke="#64748b"
                  fontSize={10}
                  tickFormatter={(val) => `£${(val / 1e6).toFixed(0)}M`}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  labelStyle={{ color: '#94a3b8', fontSize: '11px', fontWeight: 'bold' }}
                  itemStyle={{ color: '#e2e8f0', fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), 'Buffer Balance']}
                />
                <Area type="monotone" dataKey="cumulative" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorCash)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
          <h3 className="text-sm font-semibold text-slate-300">Debt & Interest Coverage</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs text-slate-400">Total Outstanding Debt</span>
              <span className="text-sm font-bold text-slate-200">{formatGBP(metrics.debtOutstanding)}</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs text-slate-400">Interest Coverage Ratio (ICR)</span>
              <span className={`text-sm font-bold ${metrics.interestCoverageRatio > 3 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {metrics.interestCoverageRatio.toFixed(2)}x
              </span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs text-slate-400">Net Treasury Position</span>
              <span className="text-sm font-bold text-slate-200">{formatGBP(metrics.netTreasuryPosition)}</span>
            </div>
            <div className="flex justify-between items-center pb-2">
              <span className="text-xs text-slate-400">Emergency Credit Fac.</span>
              <span className="text-xs font-semibold bg-emerald-950/40 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900">
                £500M Available
              </span>
            </div>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-300 block mb-1">Maturity Matching Policy</strong>
                EVM maintains a strict matching duration alignment where infrastructure equity duration (average 11.2 years) is hedged via long-dated sovereign matching facilities.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Debt & Credit Facility Schedule</h3>
          <span className="text-[10px] text-slate-500">Last Synced: Just now</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-2.5">Facility Type</th>
                <th className="px-4 py-2.5">Principal Amount</th>
                <th className="px-4 py-2.5">Coupon/Rate</th>
                <th className="px-4 py-2.5">Issue Date</th>
                <th className="px-4 py-2.5">Maturity Date</th>
                <th className="px-4 py-2.5">Coverage Ratio</th>
                <th className="px-4 py-2.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {DEBT_FACILITIES_LIST.map((fac) => (
                <tr key={fac.id} className="hover:bg-slate-950/40">
                  <td className="px-4 py-3 font-semibold text-slate-200">{fac.type}</td>
                  <td className="px-4 py-3 font-mono text-slate-300">{formatGBP(fac.amount)}</td>
                  <td className="px-4 py-3 font-mono text-slate-300">{(fac.rate * 100).toFixed(2)}%</td>
                  <td className="px-4 py-3 text-slate-400">{fac.issueDate}</td>
                  <td className="px-4 py-3 text-slate-400">{fac.maturityDate}</td>
                  <td className="px-4 py-3 font-mono text-slate-300">{fac.coverageRatio.toFixed(1)}x</td>
                  <td className="px-4 py-3">
                    <span className="bg-emerald-950/40 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900/60 font-semibold text-[10px]">
                      Committed
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function LiquidityView({ metrics, settings, cashFlows }: ViewProps) {
  const [fundingGapState, setFundingGapState] = useState<'normal' | 'emergency'>('normal');

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="liquidity-view-container">
      <div className="flex justify-between items-center border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Liquidity Coverage Module</h2>
          <p className="text-xs text-slate-400">Basel III regulatory ratios, liquidity timelines, and cashflow waterfall modeling.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFundingGapState(fundingGapState === 'normal' ? 'emergency' : 'normal')}
            className={`px-3 py-1.5 text-xs font-semibold rounded border transition-colors flex items-center gap-1.5 ${
              fundingGapState === 'emergency'
                ? 'bg-rose-950/50 text-rose-400 border-rose-800 hover:bg-rose-950'
                : 'bg-amber-950/30 text-amber-400 border-amber-900 hover:bg-amber-950/50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            {fundingGapState === 'emergency' ? 'De-activate Emergency Buffer' : 'Simulate Emergency Liquidity Call'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h4 className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Basel III Liquidity Coverage (LCR)</h4>
            <div className="text-2xl font-bold text-emerald-400 mt-2">{(metrics.lcr).toFixed(2)}x</div>
            <p className="text-[10px] text-slate-500 mt-2">High Quality Liquid Assets / Net Outflows over 30 Days stress horizon.</p>
          </div>
          <div className="w-full bg-slate-950 rounded-full h-1.5 mt-4">
            <div
              className="bg-emerald-500 h-1.5 rounded-full"
              style={{ width: `${Math.min(100, (metrics.lcr / 2.5) * 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h4 className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Net Stable Funding Ratio (NSFR)</h4>
            <div className="text-2xl font-bold text-sky-400 mt-2">{(metrics.nsfr).toFixed(2)}x</div>
            <p className="text-[10px] text-slate-500 mt-2">Available Stable Funding / Required Stable Funding over 1 Year horizon.</p>
          </div>
          <div className="w-full bg-slate-950 rounded-full h-1.5 mt-4">
            <div
              className="bg-sky-500 h-1.5 rounded-full"
              style={{ width: `${Math.min(100, (metrics.nsfr / 2.0) * 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h4 className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Funding Gap Outlook</h4>
            <div className="text-2xl font-bold text-slate-100 mt-2">
              {fundingGapState === 'emergency' ? '-£250.0M' : 'Fully Funded'}
            </div>
            <p className="text-[10px] text-slate-500 mt-2">Maximum peak cumulative funding deficits over 12-Month horizon.</p>
          </div>
          <div className="mt-4 flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${fundingGapState === 'emergency' ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500'}`} />
            <span className="text-[10px] text-slate-400">
              {fundingGapState === 'emergency' ? 'Breach Risk: Action Required' : 'LCR Target Compliant'}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Cashflow Waterfall (Current Quarter Inflows & Outflows)</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { name: 'Beginning Cash', value: metrics.cashAvailable, fill: '#64748b' },
                  { name: 'Operating Inflows', value: 185000000, fill: '#10b981' },
                  { name: 'Debt Drawdowns', value: 120000000, fill: '#0ea5e9' },
                  { name: 'Capital Calls', value: -220000000, fill: '#ef4444' },
                  { name: 'Debt Servicing', value: -45000000, fill: '#f43f5e' },
                  { name: 'Ending Buffer', value: metrics.cashAvailable + 185000000 + 120000000 - 220000000 - 45000000, fill: '#10b981' }
                ]}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={9} />
                <YAxis stroke="#64748b" fontSize={9} tickFormatter={(val) => `£${(val / 1e6).toFixed(0)}M`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ color: '#f8fafc', fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), 'Value']}
                />
                <Bar dataKey="value" fill="#38bdf8" radius={[4, 4, 0, 0]}>
                  {
                    [
                      { fill: '#475569' },
                      { fill: '#059669' },
                      { fill: '#0284c7' },
                      { fill: '#dc2626' },
                      { fill: '#be123c' },
                      { fill: '#059669' }
                    ].map((entry, index) => (
                      <rect key={`rect-${index}`} fill={entry.fill} />
                    ))
                  }
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Available Emergency Liquidity</h3>
            <div className="space-y-4">
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Bank of England Discount Window</span>
                  <span className="text-emerald-400 font-bold">£500.0M</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Pre-approved collateral swaps with AAA UK Gilts</div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Committed Syndicated RCF</span>
                  <span className="text-emerald-400 font-bold">£250.0M</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Revolving Credit facility (drawn: £0)</div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Govt Bond Liquidation (T+1)</span>
                  <span className="text-amber-400 font-bold">£880.0M</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Sterling high-grade liquid bonds matching</div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800 text-[10px] text-slate-400">
            <strong>LCR Limit Statement:</strong> The Board of Directors mandates a Minimum LCR ratio of 1.25x. Any drop below 1.10x triggers an automatic Emergency Capital Committee Call.
          </div>
        </div>
      </div>
    </div>
  );
}

export function CashFlowView({ metrics, settings, cashFlows }: ViewProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="cashflow-view-container">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Sovereign Cash Flow Engine</h2>
        <p className="text-xs text-slate-400">Forecast and analyze operating yields, infrastructure capital calls, and financing debt services.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Cash Flow Projections Breakdown (12 Months Forward)</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cashFlows} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="period" stroke="#64748b" fontSize={9} />
                <YAxis stroke="#64748b" fontSize={9} tickFormatter={(val) => `£${(val / 1e6).toFixed(0)}M`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ color: '#f8fafc', fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), '']}
                />
                <Legend wrapperStyle={{ fontSize: '10px', color: '#64748b' }} />
                <Bar dataKey="operating" name="Operating Inflows" fill="#10b981" stackId="stack" />
                <Bar dataKey="investment" name="Investment Outflows" fill="#f43f5e" stackId="stack" />
                <Bar dataKey="financing" name="Financing Cash" fill="#0ea5e9" stackId="stack" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
          <h3 className="text-sm font-semibold text-slate-300">Forward Projections Ledger</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            EVM models its rolling cash requirements with specific capital call buffers to prevent liquidation of illiquid infrastructure positions.
          </p>
          <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 text-xs">
              <span className="text-slate-400">Average Monthly Operating Yield</span>
              <span className="text-emerald-400 font-mono font-bold">+£24.5M</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 text-xs">
              <span className="text-slate-400">Average Monthly Capital Calls</span>
              <span className="text-rose-400 font-mono font-bold">-£38.2M</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 text-xs">
              <span className="text-slate-400">Net Monthly Financing Cash</span>
              <span className="text-sky-400 font-mono font-bold">+£11.8M</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-semibold">Average Net Monthly Burn</span>
              <span className="text-amber-400 font-mono font-bold">-£1.9M</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 text-[10px] text-slate-400">
            <strong>Forecast Horizon Note:</strong> Capital call commitments are fully funded for Snaefell Railway extension, Ramsey Offshore Wind Farm, and Jurby Data Center for the upcoming 12 months.
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Forecast Cash Flow Ledger (Sterling)</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-2.5">Forecast Period</th>
                <th className="px-4 py-2.5">Operating Cash Flow</th>
                <th className="px-4 py-2.5">Investment Cash Flow</th>
                <th className="px-4 py-2.5">Financing Cash Flow</th>
                <th className="px-4 py-2.5">Net Monthly Flow</th>
                <th className="px-4 py-2.5">Cumulative Cash Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {cashFlows.slice(0, 6).map((flow, idx) => (
                <tr key={idx} className="hover:bg-slate-950/40 text-slate-300">
                  <td className="px-4 py-3 font-sans font-semibold text-slate-400">{flow.period}</td>
                  <td className="px-4 py-3 text-emerald-400">+{formatGBP(flow.operating)}</td>
                  <td className="px-4 py-3 text-rose-400">{formatGBP(flow.investment)}</td>
                  <td className="px-4 py-3 text-sky-400">+{formatGBP(flow.financing)}</td>
                  <td className={`px-4 py-3 font-bold ${flow.net >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {flow.net >= 0 ? '+' : ''}{formatGBP(flow.net)}
                  </td>
                  <td className="px-4 py-3 font-bold text-slate-100">{formatGBP(flow.cumulative)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
