/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { KPIMetrics, AppSettings, InfraProject } from '../../types';
import { Shield, TrendingDown, RefreshCw, Cpu, Activity, Info, Landmark, HardHat, ShieldAlert, Award } from 'lucide-react';

interface ViewProps {
  metrics: KPIMetrics;
  settings: AppSettings;
  infraProjects: InfraProject[];
}

export function InfrastructureView({ metrics, settings, infraProjects }: ViewProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="infrastructure-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100 font-sans">Sovereign Infrastructure Risk Module</h2>
        <p className="text-xs text-slate-400 font-sans">Monitor construction schedules, political risk matrices, regulatory compliance, and risk-adjusted IRR indices.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Total Allocated capital</span>
            <div className="text-2xl font-bold font-mono text-slate-200 mt-1">£1.85 Billion</div>
            <p className="text-[10px] text-slate-500 mt-1">Strategic greenfield & brownfield projects</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Weighted ex-ante IRR</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">11.62%</div>
            <p className="text-[10px] text-slate-500 mt-1">Risk-adjusted return hurdle met</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Operating status</span>
            <div className="text-2xl font-bold font-mono text-slate-100 mt-1">9 Projects</div>
            <p className="text-[10px] text-slate-500 mt-1">All facilities within safety compliance</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {infraProjects.map((proj) => {
          // Scorecard background depending on overall health score
          let ratingColor = 'text-emerald-400 border border-emerald-900 bg-emerald-950/10';
          if (proj.score < 80) {
            ratingColor = 'text-amber-400 border border-amber-900 bg-amber-950/15';
          }

          return (
            <div key={proj.id} className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex justify-between items-start gap-2">
                  <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5 font-sans">
                    <Landmark className="w-3.5 h-3.5 text-sky-400" /> {proj.category}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-sans ${ratingColor}`}>
                    Score: {proj.score}/100
                  </span>
                </div>
                <h3 className="text-sm font-semibold text-slate-200 mt-2 font-sans line-clamp-1">{proj.name}</h3>
                <div className="text-[11px] text-slate-500 mt-1">Cost basis: {formatGBP(proj.cost)}</div>
              </div>

              <div className="space-y-2 border-t border-slate-850 pt-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Construction Risk</span>
                  <span className={`font-mono font-bold ${proj.constructionRisk > 40 ? 'text-rose-400' : 'text-slate-300'}`}>{proj.constructionRisk}/100</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Political/Regulatory Risk</span>
                  <span className="text-slate-300 font-mono font-bold">{Math.max(proj.politicalRisk, proj.regulatoryRisk)}/100</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Revenue/Demand Risk</span>
                  <span className="text-slate-300 font-mono font-bold">{Math.max(proj.revenueRisk, proj.demandRisk)}/100</span>
                </div>
                <div className="flex justify-between items-center text-xs pt-1.5 border-t border-slate-850/40">
                  <span className="text-slate-400 font-bold uppercase text-[9px]">Weighted IRR</span>
                  <span className="text-emerald-400 font-mono font-bold">{(proj.currentIRR * 100).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
