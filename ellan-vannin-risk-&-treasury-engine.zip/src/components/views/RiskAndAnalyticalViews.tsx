/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KPIMetrics, AppSettings, PortfolioAsset, Counterparty, FXExposure } from '../../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar } from 'recharts';
import { CORRELATION_MATRIX } from '../../data/mockRiskData';
import { generateYieldCurve } from '../../utils/riskCalculations';
import { Shield, TrendingDown, RefreshCw, Cpu, Activity, Info, TrendingUp, Compass, Flame } from 'lucide-react';

interface ViewProps {
  metrics: KPIMetrics;
  settings: AppSettings;
  assets: PortfolioAsset[];
  counterparties: Counterparty[];
  fxExposures: FXExposure[];
}

// Colors for the Portfolio Pie Chart
const COLORS = [
  '#0f172a', // Dark Navy
  '#1e293b', // Navy Blue
  '#334155', // Slate Grey
  '#14532d', // Forest Green
  '#15803d', // Green Accent
  '#0284c7', // Sky Blue
  '#0369a1', // Medium Blue
  '#ca8a04', // Deep Gold/Amber
  '#be123c'  // Red Crimson
];

const ASSET_COLORS: Record<string, string> = {
  'Equities': '#3b82f6',
  'Bonds': '#10b981',
  'Property': '#f59e0b',
  'Infrastructure': '#06b6d4',
  'Private Equity': '#8b5cf6',
  'Bitcoin': '#f97316',
  'Gold': '#eab308',
  'Cash': '#64748b',
  'Alternatives': '#ec4899'
};

export function PortfolioRiskView({ metrics, settings, assets }: ViewProps) {
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);

  const totalValue = assets.reduce((sum, a) => sum + a.value, 0);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const chartData = assets.map(a => ({
    name: a.type,
    value: a.value,
    percentage: (a.value / totalValue) * 100
  }));

  return (
    <div className="space-y-6" id="portfolio-risk-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Portfolio Risk & Multi-Asset Allocation</h2>
        <p className="text-xs text-slate-400">Barra-style risk attribution, tracking error, systematic beta, and covariance analysis.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Capital Allocation (Donut Attribution)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={ASSET_COLORS[entry.name] || COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ color: '#f8fafc', fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), 'Allocation']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 mt-2">
            {assets.map((asset) => (
              <div key={asset.type} className="flex items-center gap-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: ASSET_COLORS[asset.type] }} />
                <span>{asset.type} ({((asset.value / totalValue) * 100).toFixed(1)}%)</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-4">MSCI Barra Performance Risk Ratios</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Ex-Ante Volatility</div>
                <div className="text-lg font-mono font-bold text-slate-100 mt-1">{((metrics.volatility) * 100).toFixed(2)}%</div>
                <div className="text-[9px] text-slate-500 mt-1">Attributed systematic risk</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Ex-Post Sharpe Ratio</div>
                <div className="text-lg font-mono font-bold text-emerald-400 mt-1">
                  {((metrics.expectedReturn - settings.interestRateBase) / Math.max(0.01, metrics.volatility)).toFixed(2)}
                </div>
                <div className="text-[9px] text-slate-500 mt-1">Risk-adjusted return ratio</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Sortino Ratio</div>
                <div className="text-lg font-mono font-bold text-emerald-400 mt-1">
                  {((metrics.expectedReturn - settings.interestRateBase) / Math.max(0.01, metrics.volatility * 0.75)).toFixed(2)}
                </div>
                <div className="text-[9px] text-slate-500 mt-1">Downside variance adjustment</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Systematic Beta</div>
                <div className="text-lg font-mono font-bold text-sky-400 mt-1">
                  {assets.reduce((sum, a) => sum + a.beta * (a.value / totalValue), 0).toFixed(2)}
                </div>
                <div className="text-[9px] text-slate-500 mt-1">Benchmark: FTSE 100 / MSCI World</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Treynor Ratio</div>
                <div className="text-lg font-mono font-bold text-slate-100 mt-1">
                  {((metrics.expectedReturn - settings.interestRateBase) / Math.max(0.01, assets.reduce((sum, a) => sum + a.beta * (a.value / totalValue), 0))).toFixed(3)}
                </div>
                <div className="text-[9px] text-slate-500 mt-1">Attributed systemic beta gain</div>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">Max Downside Drawdown</div>
                <div className="text-lg font-mono font-bold text-rose-400 mt-1">-14.20%</div>
                <div className="text-[9px] text-slate-500 mt-1">Historical 3-year peak-to-trough</div>
              </div>
            </div>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[11px] text-slate-400 leading-relaxed mt-4">
            <strong>Calmar Ratio:</strong> EVM active Calmar stands at <strong>{(metrics.expectedReturn / 0.142).toFixed(2)}</strong>, establishing an institutional risk profile matching sovereign wealth frameworks.
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Institutional Cross-Asset Correlation Matrix</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-3 py-2 text-left font-sans">Asset Category</th>
                {assets.map((a) => (
                  <th key={a.type} className="px-2 py-2 text-[10px]">{a.type.substring(0, 7)}.</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {assets.map((rowAsset) => (
                <tr key={rowAsset.type} className="hover:bg-slate-950/40">
                  <td className="px-3 py-2.5 text-left font-sans font-semibold text-slate-300">{rowAsset.type}</td>
                  {assets.map((colAsset) => {
                    const corr = CORRELATION_MATRIX[rowAsset.type]?.[colAsset.type] ?? (rowAsset.type === colAsset.type ? 1 : 0);
                    let colorClass = 'text-slate-400';
                    let bgClass = 'bg-slate-950/20';

                    if (corr === 1.0) {
                      colorClass = 'text-slate-100 font-bold';
                      bgClass = 'bg-slate-800/40';
                    } else if (corr > 0.5) {
                      colorClass = 'text-amber-400 font-semibold';
                      bgClass = 'bg-amber-950/15';
                    } else if (corr < 0) {
                      colorClass = 'text-sky-400 font-semibold';
                      bgClass = 'bg-sky-950/20';
                    }

                    return (
                      <td key={colAsset.type} className={`px-2 py-2.5 border-l border-slate-850/40 ${bgClass} ${colorClass}`}>
                        {corr.toFixed(2)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function MarketRiskView({ metrics, settings, assets }: ViewProps) {
  const [varTab, setVarTab] = useState<'daily' | 'historical' | 'parametric'>('parametric');

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const aum = metrics.aum;
  const confidence = settings.varConfidence;

  // Mocking VaR outputs for comparative dashboards
  const parametricVaR = metrics.varDaily;
  const historicalVaR = metrics.varDaily * 1.08;
  const monteCarloVaR = metrics.varDaily * 0.96;

  return (
    <div className="space-y-6" id="market-risk-view">
      <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Market Risk Analytics (Value-at-Risk)</h2>
          <p className="text-xs text-slate-400">Quantify ex-ante downside boundaries using Parametric, Historical, and Monte Carlo VaR models.</p>
        </div>
        <div className="flex bg-slate-950 p-1 rounded border border-slate-800">
          {(['parametric', 'historical', 'daily'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setVarTab(t)}
              className={`px-3 py-1 text-[10px] uppercase font-bold rounded transition-colors ${
                varTab === t ? 'bg-slate-800 text-sky-400' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {t === 'daily' ? 'Monte Carlo' : t}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Parametric VaR ({(confidence * 100).toFixed(0)}%)</span>
            <div className="text-2xl font-bold font-mono text-slate-100 mt-2">{formatGBP(parametricVaR)}</div>
            <p className="text-[10px] text-slate-500 mt-1">Variance-covariance normal distribution modeling.</p>
          </div>
          <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-3 mt-4">
            Risk Contribution: <span className="font-bold text-slate-200">{((parametricVaR / aum) * 100).toFixed(2)}% of capital</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Historical Simulation VaR</span>
            <div className="text-2xl font-bold font-mono text-slate-100 mt-2">{formatGBP(historicalVaR)}</div>
            <p className="text-[10px] text-slate-500 mt-1">Calculated directly from past 250 daily returns series.</p>
          </div>
          <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-3 mt-4">
            Historical Outlier Envelope: <span className="font-bold text-amber-400">Extreme Tail Deviation</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Expected Shortfall (ES)</span>
            <div className="text-2xl font-bold font-mono text-rose-400 mt-2">{formatGBP(metrics.expectedShortfall)}</div>
            <p className="text-[10px] text-slate-500 mt-1">Average expected loss in the worst {((1 - confidence) * 100).toFixed(0)}% of tail outcomes.</p>
          </div>
          <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-3 mt-4">
            Conditional Tail Expectation: <span className="font-bold text-rose-500">Maximum Tail Risk</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Downside Risk Contribution by Asset Class</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={assets.map((a) => {
                  // Compute standalone risk contributions
                  const standVaR = a.value * (a.volatility / Math.sqrt(252)) * 2.33;
                  return {
                    name: a.type,
                    value: standVaR,
                    esValue: standVaR * 1.25
                  };
                })}
                margin={{ top: 20, right: 30, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={9} />
                <YAxis stroke="#64748b" fontSize={9} tickFormatter={(val) => `£${(val / 1e6).toFixed(0)}M`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), 'Risk Contribution']}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar name="Standalone VaR Contribution" dataKey="value" fill="#3b82f6" />
                <Bar name="Tail Expected Shortfall" dataKey="esValue" fill="#f43f5e" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Model Parameters</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Confidence Interval</span>
                <span className="text-slate-100 font-mono font-bold">{(confidence * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Holding Period</span>
                <span className="text-slate-100 font-mono font-bold">1 Day</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Historical Series</span>
                <span className="text-slate-100 font-mono font-bold">250 trading days</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2">
                <span className="text-slate-400">Marginal risk scaling</span>
                <span className="text-emerald-400 font-semibold">Active</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[10px] text-slate-400 mt-4">
            <span className="text-amber-400 font-semibold flex items-center gap-1.5 mb-1">
              <Flame className="w-3.5 h-3.5" /> Tail Risk Notice
            </span>
            Under non-normal student-t fat tails, actual loss levels may exceed historical limits. Daily expected shortfall represents our primary threshold.
          </div>
        </div>
      </div>
    </div>
  );
}

export function CreditRiskView({ metrics, counterparties }: ViewProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="credit-risk-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Credit Risk & Counterparty Limits</h2>
        <p className="text-xs text-slate-400">Monitor probability of default (PD), loss given default (LGD), and counterparty credit limit utilization.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Total Credit Exposure</div>
          <div className="text-xl font-bold text-slate-200 mt-1">£1.96 Billion</div>
          <div className="text-[10px] text-slate-500 mt-1">Aggregated counterparty books</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Expected Loss (Annualized)</div>
          <div className="text-xl font-bold text-rose-400 mt-1">£1.37 Million</div>
          <div className="text-[10px] text-slate-500 mt-1">Derived from PD * LGD * EAD</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Average Counterparty LGD</div>
          <div className="text-xl font-bold text-slate-100 mt-1">38.25%</div>
          <div className="text-[10px] text-slate-500 mt-1">Collateral adjusted</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Credit Limit Breaches</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">0 Active</div>
          <div className="text-[10px] text-slate-500 mt-1">All counterparts within hard cap</div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Counterparty Registry & Utilization Heatmap</h3>
          <span className="text-[10px] text-slate-500">AAA to B sovereign rating scale</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-2.5">Institution Name</th>
                <th className="px-4 py-2.5">Credit Rating</th>
                <th className="px-4 py-2.5">Active Exposure</th>
                <th className="px-4 py-2.5">Credit Limit</th>
                <th className="px-4 py-2.5">PD (%)</th>
                <th className="px-4 py-2.5">LGD (%)</th>
                <th className="px-4 py-2.5">Expected Loss</th>
                <th className="px-4 py-2.5">Limit Utilization</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {counterparties.map((cp) => {
                const util = (cp.exposure / cp.limit) * 100;
                let utilColor = 'bg-emerald-500/10 text-emerald-400 border border-emerald-900';
                if (util > 85) {
                  utilColor = 'bg-rose-950/50 text-rose-400 border border-rose-900';
                } else if (util > 65) {
                  utilColor = 'bg-amber-950/30 text-amber-400 border border-amber-900';
                }

                return (
                  <tr key={cp.id} className="hover:bg-slate-950/40 text-slate-300">
                    <td className="px-4 py-3 font-sans font-semibold text-slate-200">{cp.name}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 font-bold rounded text-[10px] ${
                        cp.rating === 'AA' ? 'bg-slate-800 text-sky-400 border border-slate-700' : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}>
                        {cp.rating}
                      </span>
                    </td>
                    <td className="px-4 py-3">{formatGBP(cp.exposure)}</td>
                    <td className="px-4 py-3 text-slate-400">{formatGBP(cp.limit)}</td>
                    <td className="px-4 py-3">{(cp.pd * 100).toFixed(4)}%</td>
                    <td className="px-4 py-3">{(cp.lgd * 100).toFixed(1)}%</td>
                    <td className="px-4 py-3 text-rose-400 font-semibold">{formatGBP(cp.expectedLoss)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-slate-950 rounded-full h-1.5 shrink-0">
                          <div
                            className={`h-1.5 rounded-full ${util > 85 ? 'bg-rose-500' : util > 65 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                            style={{ width: `${util}%` }}
                          />
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${utilColor}`}>{util.toFixed(1)}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function InterestRateRiskView({ metrics, settings }: ViewProps) {
  const [bpsShift, setBpsShift] = useState<number>(100);
  const [curveShock, setCurveShock] = useState<'none' | 'parallel' | 'steepening' | 'flattening'>('parallel');

  const curveData = generateYieldCurve(settings.interestRateBase, curveShock, bpsShift);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const aum = metrics.aum;
  // Calculate duration metrics
  const bondsValue = aum * 0.234;
  const infraValue = aum * 0.197;
  const totalDurationValue = bondsValue + infraValue;

  const portfolioDuration = (bondsValue * 6.5 + infraValue * 11) / totalDurationValue;
  const portfolioConvexity = (bondsValue * 55 + infraValue * 110) / totalDurationValue;

  const rateShiftDecimal = bpsShift / 10000;
  const durationLoss = -portfolioDuration * rateShiftDecimal * totalDurationValue;
  const convexityGain = 0.5 * portfolioConvexity * Math.pow(rateShiftDecimal, 2) * totalDurationValue;
  const netValueChange = durationLoss + convexityGain;

  return (
    <div className="space-y-6" id="interest-rate-risk-view">
      <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Interest Rate Risk & Yield Curve Shocks</h2>
          <p className="text-xs text-slate-400">Examine bond portfolio sensitivity using Modified Duration, Convexity, and curve deformation shocks.</p>
        </div>
        <div className="flex gap-2 bg-slate-950 p-1 rounded border border-slate-800">
          {(['parallel', 'steepening', 'flattening'] as const).map((sh) => (
            <button
              key={sh}
              onClick={() => setCurveShock(sh)}
              className={`px-3 py-1 text-[10px] uppercase font-bold rounded transition-colors ${
                curveShock === sh ? 'bg-slate-800 text-sky-400' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {sh}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-semibold text-slate-300">Sovereign Gilt Yield Curve (GBP Maturing Term Structure)</h3>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Shift Size:</span>
              <input
                type="number"
                value={bpsShift}
                onChange={(e) => setBpsShift(Math.max(-500, Math.min(500, parseInt(e.target.value) || 0)))}
                className="w-16 bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-xs text-slate-200 text-center font-mono font-bold"
              />
              <span className="text-xs text-slate-500">bps</span>
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curveData} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="maturity" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} tickFormatter={(val) => `${val}%`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ fontSize: '11px' }}
                  formatter={(val: any) => [`${val}%`, '']}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Line name="Baseline Yield Curve" type="monotone" dataKey="rate" stroke="#64748b" strokeWidth={1.5} dot />
                <Line name={`Shocked Yield Curve (${curveShock})`} type="monotone" dataKey="shockedRate" stroke="#38bdf8" strokeWidth={2.5} dot />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Duration & Convexity Sensitivity</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Portfolio Modified Duration</span>
                  <span className="text-slate-100 font-mono font-bold">{portfolioDuration.toFixed(2)} Years</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1 mt-1.5">
                  <div className="bg-sky-500 h-1 rounded-full" style={{ width: '75%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Ex-Ante Convexity Factor</span>
                  <span className="text-slate-100 font-mono font-bold">{portfolioConvexity.toFixed(1)}</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1 mt-1.5">
                  <div className="bg-emerald-500 h-1 rounded-full" style={{ width: '60%' }} />
                </div>
              </div>

              <div className="border-t border-slate-800 pt-3 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Duration Impact Loss</span>
                  <span className="text-rose-400 font-mono font-semibold">{formatGBP(-durationLoss)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Convexity Smoothing Gain</span>
                  <span className="text-emerald-400 font-mono font-semibold">+{formatGBP(convexityGain)}</span>
                </div>
                <div className="flex justify-between items-center border-t border-slate-850 pt-2 font-bold">
                  <span className="text-slate-300">Net Value Sensitivity</span>
                  <span className={netValueChange >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {netValueChange >= 0 ? '+' : ''}{formatGBP(netValueChange)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[10px] text-slate-400 leading-relaxed mt-4">
            <strong>Hedging Rule:</strong> EVM automatically offsets parallel yield shifts past +/- 150bps by deploying interest-rate interest rate futures to align our net duration within board mandates.
          </div>
        </div>
      </div>
    </div>
  );
}

export function CurrencyRiskView({ metrics, fxExposures }: ViewProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="currency-risk-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Sovereign Currency Exposure (FX Module)</h2>
        <p className="text-xs text-slate-400">Track net currency asset exposures, historical FX hedging ratios, and sterling sensitivity indices.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Foreign Currency Net Exposure Breakdown (GBP Equivalent)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={fxExposures} margin={{ top: 10, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="currency" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} tickFormatter={(val) => `£${(val / 1e6).toFixed(0)}M`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ fontSize: '11px' }}
                  formatter={(val: any) => [formatGBP(val), 'Net Exposure']}
                />
                <Bar dataKey="valueGBP" fill="#0ea5e9" radius={[4, 4, 0, 0]}>
                  {fxExposures.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.currency === 'GBP' ? '#64748b' : entry.currency === 'BTC' ? '#f97316' : '#3b82f6'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">FX Gain/Loss Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Net FX Portfolio Gains</span>
                <span className="text-emerald-400 font-mono font-bold">+£116.3M</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Board Hedging Mandate</span>
                <span className="text-slate-100 font-mono font-bold">75.0% Target</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Active Hedging Average</span>
                <span className="text-emerald-400 font-mono font-bold">72.4% Achieved</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">GBP Appreciation Stress (10%)</span>
                <span className="text-rose-400 font-semibold font-mono">-£118.4M Impact</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[10px] text-slate-400 leading-relaxed mt-4">
            <strong>Hedging Rule:</strong> FX forward contracts are rolled on a quarterly rolling cycle matching the cash inflows of underlying properties and overseas wind farm assets.
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Sterling FX Exposure Ledger</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-2.5 font-sans">Currency</th>
                <th className="px-4 py-2.5 font-sans">Foreign Holdings</th>
                <th className="px-4 py-2.5">Exchange Rate</th>
                <th className="px-4 py-2.5">GBP Equivalent Value</th>
                <th className="px-4 py-2.5">Inception Gain/Loss</th>
                <th className="px-4 py-2.5">Active Hedge Ratio</th>
                <th className="px-4 py-2.5">10% GBP Shock Sensitivity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {fxExposures.map((fx) => (
                <tr key={fx.currency} className="hover:bg-slate-950/40">
                  <td className="px-4 py-3 font-sans font-semibold text-slate-200">{fx.currency}</td>
                  <td className="px-4 py-3">{fx.holdings.toLocaleString()}</td>
                  <td className="px-4 py-3">{fx.rate.toFixed(4)}</td>
                  <td className="px-4 py-3 font-semibold text-slate-100">{formatGBP(fx.valueGBP)}</td>
                  <td className={`px-4 py-3 ${fx.gainLossGBP >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {fx.gainLossGBP >= 0 ? '+' : ''}{formatGBP(fx.gainLossGBP)}
                  </td>
                  <td className="px-4 py-3 font-sans font-semibold">
                    <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-[10px]">
                      {(fx.hedgingRatio * 100).toFixed(0)}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-rose-400 font-semibold">{formatGBP(fx.sensitivity)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function BitcoinTreasuryView({ metrics }: ViewProps) {
  const [selectedBtcModel, setSelectedBtcModel] = useState<'normal' | 'halving' | 'regulation'>('normal');

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const aum = metrics.aum;
  const btcAllocationPct = (380000000 / aum) * 100;

  return (
    <div className="space-y-6" id="bitcoin-treasury-view">
      <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Bitcoin Corporate Treasury (RTE Module)</h2>
          <p className="text-xs text-slate-400">Monitor digital asset allocation, cold storage security parameters, and tail risk contributions.</p>
        </div>
        <div className="flex bg-slate-950 p-1 rounded border border-slate-800">
          {(['normal', 'halving', 'regulation'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setSelectedBtcModel(m)}
              className={`px-3 py-1 text-[10px] uppercase font-bold rounded transition-colors ${
                selectedBtcModel === m ? 'bg-slate-800 text-orange-400' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {m === 'normal' ? 'Baseline' : m === 'halving' ? 'Halving Cycle' : 'Regulatory'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Active Bitcoin Holdings</div>
          <div className="text-xl font-bold text-orange-400 mt-1">7,200 BTC</div>
          <div className="text-[10px] text-slate-500 mt-1">Secured via multi-sig cold vault</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Sterling Market Value</div>
          <div className="text-xl font-bold text-slate-100 mt-1">£380.0 Million</div>
          <div className="text-[10px] text-slate-500 mt-1">GBP Equivalent (spot value)</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Portfolio Allocation</div>
          <div className="text-xl font-bold text-slate-100 mt-1">{btcAllocationPct.toFixed(2)}%</div>
          <div className="text-[10px] text-slate-500 mt-1">Board limit: 5.0% maximum</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-semibold">Inception Cost Basis</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">£38,500 / BTC</div>
          <div className="text-[10px] text-slate-500 mt-1">Cumulative average acquisition cost</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
          <h3 className="text-sm font-semibold text-slate-300 mb-4">Historical Bitcoin Drawdown Stress Horizon</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={[
                  { day: 'T-30', price: 62500, baseline: 38500 },
                  { day: 'T-25', price: 59000, baseline: 38500 },
                  { day: 'T-20', price: 61200, baseline: 38500 },
                  { day: 'T-15', price: 57400, baseline: 38500 },
                  { day: 'T-10', price: 63800, baseline: 38500 },
                  { day: 'T-5', price: 65100, baseline: 38500 },
                  { day: 'Current', price: 64200, baseline: 38500 }
                ]}
                margin={{ top: 10, right: 30, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="day" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} tickFormatter={(val) => `£${val}`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                  itemStyle={{ fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Line name="Bitcoin Spot Price (GBP)" type="monotone" dataKey="price" stroke="#f97316" strokeWidth={2} dot />
                <Line name="EVM Cost Basis" type="monotone" dataKey="baseline" stroke="#10b981" strokeDasharray="5 5" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Custody & Allocation Protocols</h3>
            <div className="space-y-3 text-xs leading-relaxed">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-850 flex justify-between items-center">
                <span className="text-slate-400 font-semibold">Cold Storage Custodian</span>
                <span className="text-slate-200 font-bold">Fidelity Digital Assets</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-850 flex justify-between items-center">
                <span className="text-slate-400 font-semibold">Signature Multi-Sig Cap</span>
                <span className="text-slate-200 font-bold">3 of 5 Keys</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-850 flex justify-between items-center">
                <span className="text-slate-400 font-semibold">Rebalancing Cycle</span>
                <span className="text-slate-200 font-bold">Semi-Annual</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[10px] text-slate-400 mt-4">
            <span className="text-orange-400 font-semibold flex items-center gap-1.5 mb-1">
              <Cpu className="w-3.5 h-3.5" /> SEC / FCA Compliant
            </span>
            EVM corporate treasury digital asset reserves are fully registered and monitored via on-chain AML tools. Zero hot wallet storage is permitted.
          </div>
        </div>
      </div>
    </div>
  );
}
