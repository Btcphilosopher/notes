/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KPIMetrics, AppSettings, StressScenario, SimulationResult } from '../../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, ReferenceLine } from 'recharts';
import { INST_STRESS_SCENARIOS } from '../../data/mockRiskData';
import { runMonteCarlo } from '../../utils/riskCalculations';
import { Play, Sliders, TrendingUp, AlertTriangle, RefreshCw, Layers, ShieldCheck } from 'lucide-react';

interface ViewProps {
  metrics: KPIMetrics;
  settings: AppSettings;
  activeScenario: StressScenario | null;
  onSelectScenario: (scen: StressScenario | null) => void;
}

export function StressTestingView({ metrics, settings, activeScenario, onSelectScenario }: ViewProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  return (
    <div className="space-y-6" id="stress-testing-view">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Stress Testing & Risk Shock Scenarios</h2>
        <p className="text-xs text-slate-400">Apply macro-financial and digital asset shocks to model balance sheet resilience and solvency envelopes.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-2 h-[500px] overflow-y-auto">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 p-2 border-b border-slate-850">Macro Shocks Registry</h3>
          <button
            onClick={() => onSelectScenario(null)}
            className={`w-full text-left px-3 py-2 text-xs rounded transition-all flex justify-between items-center ${
              activeScenario === null
                ? 'bg-sky-950/40 border border-sky-800 text-sky-400 font-semibold'
                : 'bg-slate-950/40 text-slate-400 hover:bg-slate-900 border border-transparent'
            }`}
          >
            <span>Base Case (Standard)</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </button>

          {INST_STRESS_SCENARIOS.map((scen) => (
            <button
              key={scen.id}
              onClick={() => onSelectScenario(scen)}
              className={`w-full text-left p-3 text-xs rounded transition-all border ${
                activeScenario?.id === scen.id
                  ? 'bg-rose-950/50 border-rose-800 text-rose-300 font-semibold shadow'
                  : 'bg-slate-950/30 border-transparent text-slate-300 hover:bg-slate-900'
              }`}
            >
              <div className="flex justify-between items-center font-bold">
                <span className="truncate pr-1">{scen.name}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded border uppercase font-bold shrink-0 ${
                  scen.category === 'Macro' ? 'border-amber-800 text-amber-400 bg-amber-950/10' : 'border-rose-900 text-rose-400 bg-rose-950/20'
                }`}>
                  {scen.category}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 line-clamp-2 mt-1.5 leading-relaxed">{scen.description}</p>
            </button>
          ))}
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-amber-500 font-bold text-sm mb-3">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                Active Risk Vector: {activeScenario ? activeScenario.name : 'Base Case Baseline Parameters'}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                {activeScenario
                  ? activeScenario.description
                  : 'Currently operating under standard baseline macro parameters. Volatilities and sovereign rates are structured to default levels.'}
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-950 p-4 rounded border border-slate-850">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Equity Shift</span>
                  <div className={`text-sm font-bold font-mono mt-1 ${activeScenario && activeScenario.equityImpact < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                    {activeScenario ? `${(activeScenario.equityImpact * 100).toFixed(0)}%` : '0%'}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Gilt Yield Shift</span>
                  <div className={`text-sm font-bold font-mono mt-1 ${activeScenario && activeScenario.yieldShiftBps > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                    {activeScenario ? `${activeScenario.yieldShiftBps >= 0 ? '+' : ''}${activeScenario.yieldShiftBps} bps` : '0 bps'}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Bitcoin Shock</span>
                  <div className={`text-sm font-bold font-mono mt-1 ${activeScenario && activeScenario.bitcoinImpact < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {activeScenario ? `${activeScenario.bitcoinImpact >= 0 ? '+' : ''}${(activeScenario.bitcoinImpact * 100).toFixed(0)}%` : '0%'}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold">Overrun Factor</span>
                  <div className={`text-sm font-bold font-mono mt-1 ${activeScenario && activeScenario.constructionCostIncrease > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                    {activeScenario ? `+${(activeScenario.constructionCostIncrease * 100).toFixed(0)}%` : '0%'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
              <span className="text-xs text-slate-400 font-semibold">Projected AUM</span>
              <div className="text-xl font-bold font-mono text-slate-200 mt-1">{formatGBP(metrics.aum)}</div>
              <div className="text-[10px] text-slate-500 mt-1">Stressed assets value</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
              <span className="text-xs text-slate-400 font-semibold">Interest Coverage (ICR)</span>
              <div className={`text-xl font-bold font-mono mt-1 ${metrics.interestCoverageRatio < 1.5 ? 'text-rose-400' : 'text-slate-200'}`}>
                {metrics.interestCoverageRatio.toFixed(2)}x
              </div>
              <div className="text-[10px] text-slate-500 mt-1">Solvency debt ratio</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
              <span className="text-xs text-slate-400 font-semibold">Volatility Profile</span>
              <div className="text-xl font-bold font-mono text-slate-200 mt-1">{(metrics.volatility * 100).toFixed(2)}%</div>
              <div className="text-[10px] text-slate-500 mt-1">Expected portfolio annual standard dev.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function MonteCarloView({ metrics, settings }: { metrics: KPIMetrics; settings: AppSettings }) {
  const [numIterations, setNumIterations] = useState<number>(2000);
  const [horizonMonths, setHorizonMonths] = useState<number>(36);
  const [simulationData, setSimulationData] = useState<SimulationResult | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      // Run the client-side math simulation
      const res = runMonteCarlo(
        metrics.aum,
        metrics.expectedReturn,
        metrics.volatility,
        horizonMonths,
        numIterations,
        settings.inflationRate,
        settings.targetReturn
      );
      setSimulationData(res);
      setIsSimulating(false);
    }, 600);
  };

  // Run on mount once if not run yet
  React.useEffect(() => {
    handleRunSimulation();
  }, [metrics.aum, metrics.expectedReturn, metrics.volatility]);

  // Convert simulation outputs to Recharts line structure
  const chartLines = [];
  if (simulationData) {
    for (let step = 0; step < horizonMonths; step++) {
      chartLines.push({
        month: `M+${step + 1}`,
        p10: simulationData.percentiles.p10[step],
        p25: simulationData.percentiles.p25[step],
        p50: simulationData.percentiles.p50[step],
        p75: simulationData.percentiles.p75[step],
        p90: simulationData.percentiles.p90[step]
      });
    }
  }

  return (
    <div className="space-y-6" id="monte-carlo-simulation">
      <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Ex-Ante Monte Carlo Path Simulator</h2>
          <p className="text-xs text-slate-400">Run geometric brownian random walks over multi-year targets to forecast solvency probabilities.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400">Steps:</span>
            <select
              value={horizonMonths}
              onChange={(e) => setHorizonMonths(parseInt(e.target.value))}
              className="bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded px-2 py-1 font-semibold"
            >
              <option value={12}>12 Months</option>
              <option value={24}>24 Months</option>
              <option value={36}>36 Months</option>
              <option value={60}>60 Months</option>
            </select>
          </div>
          <button
            onClick={handleRunSimulation}
            disabled={isSimulating}
            className="bg-sky-900/60 text-sky-400 hover:bg-sky-850/80 px-4 py-1.5 rounded text-xs font-bold border border-sky-800 transition-colors flex items-center gap-1.5"
          >
            {isSimulating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            Run 10k simulations
          </button>
        </div>
      </div>

      {simulationData && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg lg:col-span-2">
            <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-sky-400" /> Capital Growth Fan Chart Projections (AUM Percentiles)
            </h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartLines} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="fanInner" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0.05}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={9} />
                  <YAxis stroke="#64748b" fontSize={9} tickFormatter={(val) => `£${(val / 1e9).toFixed(1)}B`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px' }}
                    itemStyle={{ fontSize: '11px' }}
                    formatter={(val: any) => [formatGBP(val), '']}
                  />
                  <ReferenceLine y={metrics.aum} stroke="#64748b" strokeDasharray="3 3" label={{ value: 'Start Capital', fill: '#94a3b8', fontSize: 9, position: 'top' }} />
                  <Area type="monotone" dataKey="p90" stroke="#0ea5e9" fill="url(#fanInner)" strokeWidth={1} />
                  <Area type="monotone" dataKey="p75" stroke="#38bdf8" fill="url(#fanInner)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="p50" stroke="#f59e0b" fill="none" strokeWidth={2.5} />
                  <Area type="monotone" dataKey="p25" stroke="#e11d48" fill="none" strokeWidth={1} />
                  <Area type="monotone" dataKey="p10" stroke="#be123c" fill="none" strokeWidth={1} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 justify-center text-[10px] text-slate-400 mt-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-[#f59e0b]" /> <span>P50 Median Path</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-[#0ea5e9]" /> <span>P75-P90 Growth</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 bg-[#be123c]" /> <span>P10 Downside</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-300 mb-4 flex items-center gap-1.5">
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-400" /> Solvency & Growth Metrics
              </h3>
              <div className="space-y-4 pt-2">
                <div className="bg-slate-950 p-3 rounded border border-slate-850">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Mean Term Capital</span>
                    <span className="text-slate-100 font-mono font-bold">{formatGBP(simulationData.meanEndValue)}</span>
                  </div>
                  <div className="text-[9px] text-slate-500 mt-1">Average portfolio ending scale</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-850">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Probability of Solvency Loss</span>
                    <span className={`font-mono font-bold ${simulationData.probabilityOfLoss > 0.15 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {(simulationData.probabilityOfLoss * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="text-[9px] text-slate-500 mt-1">Chance of capital falling below £{(metrics.aum / 1e9).toFixed(2)}B</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-850">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Probability of Target Met</span>
                    <span className="text-emerald-400 font-mono font-bold">{(simulationData.probabilityOfTarget * 100).toFixed(2)}%</span>
                  </div>
                  <div className="text-[9px] text-slate-500 mt-1">Chance of hitting {(settings.targetReturn * 100).toFixed(1)}% compound annual gain</div>
                </div>
              </div>
            </div>

            <div className="text-[9px] text-slate-500 leading-relaxed border-t border-slate-800 pt-4 mt-4">
              <strong>Simulator Basis:</strong> Parameters assume a standard geometric Brownian model with drift adjusted for the BoE target rate index and baseline inflation erosion.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function ScenarioAnalysisView({ metrics, activeScenario, onSelectScenario }: ViewProps) {
  const [customEquity, setCustomEquity] = useState<number>(-10);
  const [customGilt, setCustomGilt] = useState<number>(50);
  const [customBtc, setCustomBtc] = useState<number>(-20);

  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const handleApplyCustom = () => {
    // Generate a temporary Custom stress scenario
    const customScen: StressScenario = {
      id: 'scen-custom',
      name: 'Custom User Scenario',
      description: `User-defined macroeconomic vector with ${customEquity}% equity contraction, +${customGilt}bps sovereign shift, and ${customBtc}% digital assets shock.`,
      category: 'Market',
      equityImpact: customEquity / 100,
      bondImpact: -0.05,
      propertyImpact: -0.08,
      infraImpact: -0.04,
      bitcoinImpact: customBtc / 100,
      goldImpact: 0.10,
      yieldShiftBps: customGilt,
      fxShock: 0.05,
      constructionCostIncrease: 0.10,
      operationalCostIncrease: 0.05
    };
    onSelectScenario(customScen);
  };

  return (
    <div className="space-y-6" id="custom-scenario-builder">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-slate-100">Interactive Custom Scenario Builder</h2>
        <p className="text-xs text-slate-400">Deform assets allocations and yield shifts custom matrices to evaluate balance sheet impacts.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg space-y-5">
          <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-sky-400" /> Parameter Matrix Sliders
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-400 font-medium">Global Equities Shock</span>
                <span className="font-mono font-bold text-slate-200">{customEquity}%</span>
              </div>
              <input
                type="range"
                min="-60"
                max="20"
                value={customEquity}
                onChange={(e) => setCustomEquity(parseInt(e.target.value))}
                className="w-full accent-sky-500 bg-slate-950"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-400 font-medium">Sovereign Gilt Shift (bps)</span>
                <span className="font-mono font-bold text-slate-200">+{customGilt} bps</span>
              </div>
              <input
                type="range"
                min="-100"
                max="400"
                value={customGilt}
                onChange={(e) => setCustomGilt(parseInt(e.target.value))}
                className="w-full accent-sky-500 bg-slate-950"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-400 font-medium">Bitcoin Treasury Vector</span>
                <span className="font-mono font-bold text-slate-200">{customBtc}%</span>
              </div>
              <input
                type="range"
                min="-90"
                max="150"
                value={customBtc}
                onChange={(e) => setCustomBtc(parseInt(e.target.value))}
                className="w-full accent-sky-500 bg-slate-950"
              />
            </div>
          </div>

          <button
            onClick={handleApplyCustom}
            className="w-full bg-sky-900/60 text-sky-400 border border-sky-850 hover:bg-sky-850 px-4 py-2 rounded text-xs font-bold transition-all flex items-center justify-center gap-1.5"
          >
            Compute Custom Shock Vector
          </button>
        </div>

        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-4">Balance Sheet Impact Comparison</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Current Adjusted Capital (AUM)</span>
                <span className="text-slate-200 font-mono font-bold">{formatGBP(metrics.aum)}</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Liquidity Buffer (Cash)</span>
                <span className="text-slate-200 font-mono font-bold">{formatGBP(metrics.cashAvailable)}</span>
              </div>
              <div className="flex justify-between items-center text-xs border-b border-slate-850 pb-2">
                <span className="text-slate-400">Expected Portfolio Return</span>
                <span className="text-slate-200 font-mono font-bold">{(metrics.expectedReturn * 100).toFixed(2)}%</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Interest Solvency Coverage (ICR)</span>
                <span className={`font-mono font-bold ${metrics.interestCoverageRatio < 1.5 ? 'text-rose-400' : 'text-slate-200'}`}>
                  {metrics.interestCoverageRatio.toFixed(2)}x
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-850 text-[10px] text-slate-400 leading-relaxed mt-4">
            <strong>Simulation Instructions:</strong> Adjust parameters to test custom scenarios like a Sterling currency run or severe digital asset contraction. Hit "Compute" to propagate the shock indices across all views in the RTE dashboard.
          </div>
        </div>
      </div>
    </div>
  );
}
