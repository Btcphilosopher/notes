/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  Vault,
  Droplet,
  PieChart,
  TrendingUp,
  Handshake,
  Percent,
  Coins,
  Building2,
  Bitcoin,
  AlertTriangle,
  Dices,
  Sliders,
  RefreshCw,
  Bell,
  FileText,
  Settings,
  ShieldAlert,
  Database
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unresolvedAlertsCount: number;
}

export default function Sidebar({ activeTab, setActiveTab, unresolvedAlertsCount }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'treasury', label: 'Treasury', icon: Vault },
    { id: 'liquidity', label: 'Liquidity', icon: Droplet },
    { id: 'portfolio', label: 'Portfolio Risk', icon: PieChart },
    { id: 'market', label: 'Market Risk', icon: TrendingUp },
    { id: 'credit', label: 'Credit Risk', icon: Handshake },
    { id: 'interest', label: 'Interest Rate Risk', icon: Percent },
    { id: 'currency', label: 'Currency Risk', icon: Coins },
    { id: 'infra', label: 'Infrastructure', icon: Building2 },
    { id: 'btc', label: 'Bitcoin Treasury', icon: Bitcoin },
    { id: 'stress', label: 'Stress Testing', icon: AlertTriangle },
    { id: 'monte', label: 'Monte Carlo', icon: Dices },
    { id: 'scenarios', label: 'Scenario Analysis', icon: Sliders },
    { id: 'cashflow', label: 'Cash Flow', icon: RefreshCw },
    { id: 'alerts', label: 'Alerts', icon: Bell, badge: unresolvedAlertsCount },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'rshiny', label: 'R Shiny Code Hub', icon: Database },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <aside className="w-56 bg-[#0A192F] flex flex-col h-full shrink-0" id="app-sidebar">
      <div className="p-6 border-b border-white/10">
        <h1 className="text-xs font-bold tracking-tighter leading-none text-white uppercase">
          ELLAN VANNIN<br />
          <span className="text-[10px] opacity-60 font-light tracking-widest block mt-1">WEALTH MANAGEMENT</span>
        </h1>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 space-y-0.5">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-5 py-2.5 text-[11px] font-bold uppercase tracking-wider transition-all duration-150 ${
                isActive
                  ? 'bg-white/10 text-white border-l-3 border-[#C5A059] active-sidebar-item'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <IconComponent className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-white/50'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="bg-[#C5A059] text-[#0A192F] font-mono font-bold px-1.5 py-0.5 rounded text-[9px]">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-6 border-t border-white/10 text-left text-[10px] opacity-40 text-white">
        RTE v4.2.0-STABLE<br />
        © 2026 Institutional
      </div>
    </aside>
  );
}
