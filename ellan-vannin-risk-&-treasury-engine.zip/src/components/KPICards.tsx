/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { KPIMetrics, AppSettings } from '../types';
import { Shield, Activity, TrendingUp, RefreshCw, Layers, Award } from 'lucide-react';

interface KPICardsProps {
  metrics: KPIMetrics;
  settings: AppSettings;
}

export default function KPICards({ metrics, settings }: KPICardsProps) {
  const formatGBP = (num: number) => {
    if (num >= 1e9) return `£${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `£${(num / 1e6).toFixed(1)}M`;
    return `£${num.toLocaleString()}`;
  };

  const confidencePct = (settings.varConfidence * 100).toFixed(0);

  const cardList = [
    {
      title: 'Assets Under Management (AUM)',
      value: formatGBP(metrics.aum),
      desc: 'Sovereign-style aggregated assets',
      badge: 'Active Cap',
      badgeColor: 'text-sky-400 bg-sky-950/20 border border-sky-900/40'
    },
    {
      title: 'Cash Available',
      value: formatGBP(metrics.cashAvailable),
      desc: 'Highly liquid unencumbered cash',
      badge: 'Immediate',
      badgeColor: 'text-emerald-400 bg-emerald-950/25 border border-emerald-900/40'
    },
    {
      title: 'Liquidity coverage Ratio (LCR)',
      value: `${(metrics.lcr * 100).toFixed(1)}%`,
      desc: 'Basel III minimum target: 100.0%',
      badge: metrics.lcr >= 1.0 ? 'Compliant' : 'Breach',
      badgeColor: metrics.lcr >= 1.0 ? 'text-emerald-400 bg-emerald-950/20 border border-emerald-900/40' : 'text-rose-400 bg-rose-950/20 border border-rose-900/40'
    },
    {
      title: 'Daily Value-at-Risk (VaR)',
      value: formatGBP(metrics.varDaily),
      desc: `Parametric threshold at ${confidencePct}% confidence`,
      badge: `Ex-Ante`,
      badgeColor: 'text-amber-400 bg-amber-950/20 border border-amber-900/40'
    },
    {
      title: 'Expected Portfolio Return',
      value: `${(metrics.expectedReturn * 100).toFixed(2)}%`,
      desc: 'Weighted multi-asset forecast',
      badge: `Target: ${(settings.targetReturn * 100).toFixed(1)}%`,
      badgeColor: 'text-slate-400 bg-slate-900 border border-slate-800'
    },
    {
      title: 'Portfolio Volatility',
      value: `${(metrics.volatility * 100).toFixed(2)}%`,
      desc: 'Ex-ante annualized variance index',
      badge: 'Systematic',
      badgeColor: 'text-sky-400 bg-sky-950/20 border border-sky-900/40'
    },
    {
      title: 'Expected Shortfall (ES)',
      value: formatGBP(metrics.expectedShortfall),
      desc: 'Conditional tail risk projection',
      badge: 'Worst 1% tail',
      badgeColor: 'text-rose-400 bg-rose-950/25 border border-rose-900/40'
    },
    {
      title: 'Interest Coverage Ratio (ICR)',
      value: `${metrics.interestCoverageRatio.toFixed(2)}x`,
      desc: 'Projected EBITDA / debt service cost',
      badge: metrics.interestCoverageRatio >= 1.5 ? 'Solvent' : 'Stressed',
      badgeColor: metrics.interestCoverageRatio >= 1.5 ? 'text-emerald-400 bg-emerald-950/20' : 'text-rose-400 bg-rose-950/20'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 bg-white border-b border-black/10 divide-x divide-y lg:divide-y-0 divide-black/10" id="kpi-panel">
      {cardList.map((card, idx) => {
        // Classify metric types for custom status dot colours
        const isStressed = card.badge === 'Breach' || card.badge === 'Stressed';
        const isCaution = card.badge === 'Worst 1% tail' || card.badge === 'Ex-Ante' || card.badge === 'Stressed';
        const statusDotClass = isStressed 
          ? 'bg-red-600' 
          : isCaution 
          ? 'bg-amber-500' 
          : 'bg-green-600';

        return (
          <div key={idx} className="p-4 flex flex-col justify-between bg-white min-w-0" style={{ borderTop: idx >= 4 ? '1px solid rgba(20,20,20,0.1)' : 'none' }}>
            <div>
              <div className="text-[9px] uppercase tracking-widest font-bold text-neutral-500 truncate" title={card.title}>
                {card.title}
              </div>
              <div className="text-xl font-light font-mono text-[#141414] mt-1.5 truncate">
                {card.value}
              </div>
            </div>
            <div className="mt-1.5 flex items-center gap-1.5 overflow-hidden">
              <span className="text-[10px] font-bold tracking-tight truncate flex items-center gap-1 text-neutral-600">
                <span className={`w-1.5 h-1.5 rounded-full inline-block ${statusDotClass}`} />
                {card.badge}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
