/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssetType =
  | 'Equities'
  | 'Bonds'
  | 'Property'
  | 'Infrastructure'
  | 'Private Equity'
  | 'Bitcoin'
  | 'Gold'
  | 'Cash'
  | 'Alternatives';

export interface KPIMetrics {
  aum: number;
  cashAvailable: number;
  liquidityRatio: number; // Current Ratio / Quick Ratio
  netTreasuryPosition: number;
  expectedReturn: number;
  volatility: number;
  varDaily: number;
  expectedShortfall: number;
  debtOutstanding: number;
  interestCoverageRatio: number;
  riskRating: 'Low' | 'Moderate' | 'High';
  lcr: number; // Liquidity Coverage Ratio
  nsfr: number; // Net Stable Funding Ratio
}

export interface PortfolioAsset {
  type: AssetType;
  value: number;
  allocation: number; // percentage
  volatility: number; // annual
  expectedReturn: number; // annual
  beta: number;
}

export interface Counterparty {
  id: string;
  name: string;
  rating: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B';
  exposure: number;
  limit: number;
  pd: number; // Probability of Default
  lgd: number; // Loss Given Default
  expectedLoss: number;
}

export interface FXExposure {
  currency: 'GBP' | 'USD' | 'EUR' | 'CHF' | 'JPY' | 'CAD' | 'AUD' | 'BTC' | 'ETH';
  holdings: number;
  rate: number; // FX rate against GBP
  costBasis: number;
  valueGBP: number;
  gainLossGBP: number;
  hedgingRatio: number; // percentage hedged
  sensitivity: number; // value change per 10% GBP strengthening
}

export interface InfraProject {
  id: string;
  name: string;
  category: 'Railway' | 'Port' | 'Power Station' | 'Wind Farm' | 'Forestry' | 'Housing' | 'Data Centre' | 'Water' | 'Road';
  constructionRisk: number; // 1-100 scale
  politicalRisk: number;
  regulatoryRisk: number;
  operatingRisk: number;
  revenueRisk: number;
  demandRisk: number;
  baselineIRR: number; // e.g., 0.12 for 12%
  currentIRR: number;
  cost: number;
  revenue: number;
  score: number; // 1-100 overall health
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  category: 'Macro' | 'Market' | 'Idiosyncratic' | 'Crypto';
  equityImpact: number; // e.g. -0.20 for -20%
  bondImpact: number;
  propertyImpact: number;
  infraImpact: number;
  bitcoinImpact: number;
  goldImpact: number;
  yieldShiftBps: number; // basis points shift
  fxShock: number; // USD strength against GBP
  constructionCostIncrease: number; // % increase
  operationalCostIncrease: number;
}

export interface CashFlowItem {
  period: string; // "2026-08", etc.
  operating: number;
  investment: number;
  financing: number;
  net: number;
  cumulative: number;
}

export interface Alert {
  id: string;
  timestamp: string;
  category: 'Liquidity' | 'Debt' | 'Risk Limit' | 'Concentration' | 'Currency' | 'Operations' | 'Counterparty' | 'Market';
  message: string;
  severity: 'Low' | 'Moderate' | 'High';
  resolved: boolean;
}

export interface SimulationResult {
  percentiles: {
    p10: number[];
    p25: number[];
    p50: number[];
    p75: number[];
    p90: number[];
  };
  probabilityOfLoss: number;
  probabilityOfTarget: number; // target return met
  confidenceInterval: [number, number];
  meanEndValue: number;
}

export interface AppSettings {
  interestRateBase: number; // current Bank of England base rate
  targetReturn: number; // annual
  inflationRate: number; // current annual
  hedgingPolicyGBP: number; // target hedging ratio
  varConfidence: number; // e.g. 0.95 or 0.99
  activeTheme: 'light' | 'dark';
  simulateRealTimeFeeds: boolean;
  role: 'Risk Officer' | 'Treasurer' | 'Chief Investment Officer' | 'Administrator';
}
