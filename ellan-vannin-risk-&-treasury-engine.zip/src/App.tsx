/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import KPICards from './components/KPICards';

// Views
import {
  TreasuryView,
  LiquidityView,
  CashFlowView
} from './components/views/TreasuryAndLiquidityViews';

import {
  PortfolioRiskView,
  MarketRiskView,
  CreditRiskView,
  InterestRateRiskView,
  CurrencyRiskView,
  BitcoinTreasuryView
} from './components/views/RiskAndAnalyticalViews';

import {
  StressTestingView,
  MonteCarloView,
  ScenarioAnalysisView
} from './components/views/SimulationAndStressViews';

import {
  DashboardView,
  AlertsView,
  ReportsView,
  RShinyCodeHubView,
  SettingsView
} from './components/views/OperationsAndCoreViews';

import { InfrastructureView } from './components/views/InfrastructureView';

// Core Financial State & Calculations
import {
  INITIAL_SETTINGS,
  INITIAL_ASSETS,
  INITIAL_COUNTERPARTIES,
  INITIAL_FX_EXPOSURES,
  INITIAL_INFRA_PROJECTS,
  INITIAL_ALERTS
} from './data/mockRiskData';

import { calculateKPIs, generateCashFlowForecast } from './utils/riskCalculations';
import { AppSettings, StressScenario, Alert } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // State engines
  const [settings, setSettings] = useState<AppSettings>(INITIAL_SETTINGS);
  const [assets, setAssets] = useState(INITIAL_ASSETS);
  const [counterparties, setCounterparties] = useState(INITIAL_COUNTERPARTIES);
  const [fxExposures, setFxExposures] = useState(INITIAL_FX_EXPOSURES);
  const [infraProjects, setInfraProjects] = useState(INITIAL_INFRA_PROJECTS);
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);

  const [activeScenario, setActiveScenario] = useState<StressScenario | null>(null);

  // Compute metrics in real-time based on macro vectors
  const metrics = useMemo(() => {
    return calculateKPIs(
      assets,
      settings,
      activeScenario
    );
  }, [assets, settings, activeScenario]);

  // Compute cashflow projections dynamically
  const cashFlows = useMemo(() => {
    return generateCashFlowForecast(metrics.cashAvailable, metrics.expectedReturn, activeScenario);
  }, [metrics.cashAvailable, metrics.expectedReturn, activeScenario]);

  // Live currency & commodity spot-rate background simulation
  useEffect(() => {
    const timer = setInterval(() => {
      // Small simulated updates to treasury and volatile cash segments
      setAssets(prev =>
        prev.map(asset => {
          if (asset.type === 'Bitcoin') {
            const pct = (Math.random() - 0.495) * 0.005; // slightly upward bias
            return { ...asset, value: asset.value * (1 + pct) };
          }
          if (asset.type === 'Gold') {
            const pct = (Math.random() - 0.5) * 0.001;
            return { ...asset, value: asset.value * (1 + pct) };
          }
          if (asset.type === 'Equities') {
            const pct = (Math.random() - 0.49) * 0.0015;
            return { ...asset, value: asset.value * (1 + pct) };
          }
          return asset;
        })
      );
    }, 4500);

    return () => clearInterval(timer);
  }, []);

  // Event handlers
  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
  };

  const handleSelectScenario = (scen: StressScenario | null) => {
    setActiveScenario(scen);
  };

  const handleResolveAlert = (id: string) => {
    setAlerts(prev => prev.map(a => (a.id === id ? { ...a, resolved: true } : a)));
  };

  // Resolve alert count for badge indicator
  const unresolvedAlertsCount = alerts.filter(a => !a.resolved).length;

  const [lastUpdated, setLastUpdated] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-GB', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        hour12: false,
        timeZoneName: 'short' 
      });
      setLastUpdated(timeStr);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const renderActiveView = () => {
    const props = {
      metrics,
      settings,
      assets,
      counterparties,
      fxExposures,
      infraProjects,
      alerts,
      activeScenario,
      cashFlows,
      onUpdateSettings: handleUpdateSettings,
      onSelectScenario: handleSelectScenario,
      onResolveAlert: handleResolveAlert
    };

    switch (activeTab) {
      case 'dashboard':
        return <DashboardView {...props} />;
      case 'treasury':
        return <TreasuryView {...props} />;
      case 'liquidity':
        return <LiquidityView {...props} />;
      case 'portfolio':
        return <PortfolioRiskView {...props} />;
      case 'market':
        return <MarketRiskView {...props} />;
      case 'credit':
        return <CreditRiskView {...props} />;
      case 'interest':
        return <InterestRateRiskView {...props} />;
      case 'currency':
        return <CurrencyRiskView {...props} />;
      case 'infra':
        return <InfrastructureView {...props} />;
      case 'btc':
        return <BitcoinTreasuryView {...props} />;
      case 'stress':
        return <StressTestingView {...props} />;
      case 'monte':
        return <MonteCarloView {...props} />;
      case 'scenarios':
        return <ScenarioAnalysisView {...props} />;
      case 'cashflow':
        return <CashFlowView {...props} />;
      case 'alerts':
        return <AlertsView {...props} />;
      case 'reports':
        return <ReportsView {...props} />;
      case 'rshiny':
        return <RShinyCodeHubView />;
      case 'settings':
        return <SettingsView {...props} />;
      default:
        return <DashboardView {...props} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#E4E3E0] text-[#141414] font-sans antialiased overflow-hidden" id="rte-root">
      {/* Sidebar navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unresolvedAlertsCount={unresolvedAlertsCount}
      />

      {/* Main Viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Upper System Status Bar */}
        <header className="h-16 flex items-center justify-between px-8 bg-white border-b border-[#1414141a] shrink-0">
          <div className="flex items-center">
            <span className="text-[10px] uppercase tracking-widest font-bold text-neutral-500 mr-2">System Status:</span>
            <span className="text-xs font-bold text-green-700">OPERATIONAL</span>
            <span className="mx-4 text-gray-300">|</span>
            <span className="text-[10px] uppercase tracking-widest font-bold text-neutral-500 mr-2">Last Updated:</span>
            <span className="text-xs font-bold font-mono text-[#141414]">{lastUpdated || '14:22:04 UTC'}</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">User Profile</div>
              <div className="text-xs font-bold text-[#141414]">EXECUTIVE_COMMAND</div>
            </div>
            <div className="w-8 h-8 bg-neutral-200 border border-neutral-300 rounded flex items-center justify-center text-[10px] font-bold text-neutral-700 font-mono">
              EV
            </div>
          </div>
        </header>

        {/* Upper institutional KPI belt */}
        <div className="shrink-0">
          <KPICards metrics={metrics} settings={settings} />
        </div>

        {/* Primary analytical dashboard slot */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#E4E3E0]">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
