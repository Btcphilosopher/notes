/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy init of GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      // Return a dummy client or we will throw when generateContent is actually called
      console.warn('GEMINI_API_KEY is not set. AI commentary will run in simulated fallback mode.');
    }
    aiClient = new GoogleGenAI({
      apiKey: key || 'MOCK_KEY',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// REST API for external rate feeds (simulated central bank & market feeds)
app.get('/api/feeds/rates', (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    feeds: [
      { name: 'Bank of England Base Rate', rate: 0.0525, change: 0, status: 'Stable' },
      { name: 'US Federal Reserve Rate', rate: 0.0512, change: 0, status: 'Stable' },
      { name: 'European Central Bank Rate', rate: 0.0400, change: 0, status: 'Stable' },
      { name: 'GBP/USD Spot Rate', rate: 1.2850, change: +0.0012, status: 'Active' },
      { name: 'GBP/EUR Spot Rate', rate: 1.1820, change: -0.0004, status: 'Active' },
      { name: 'Bitcoin Spot Price (USD)', rate: 64200, change: +1120, status: 'Active' },
      { name: 'Gold Spot (USD/oz)', rate: 2385.40, change: +12.50, status: 'Active' }
    ]
  });
});

// REST API for Gemini-powered Senior Risk Officer Commentary
app.post('/api/gemini/commentary', async (req, res) => {
  try {
    const { metrics, activeScenario, sectionName, assets, counterparties } = req.body;

    const key = process.env.GEMINI_API_KEY;
    if (!key || key === 'MY_GEMINI_API_KEY' || key === 'MOCK_KEY') {
      // Return a high-quality local simulated commentary if no real API key is present
      return res.json({
        commentary: `## Executive Risk Commentary [SIMULATED MODE]
This report is generated in analytical sandbox mode because a GEMINI_API_KEY is not configured in the environment.

### 1. Portfolio Stability & Liquidity Overview
The portfolio Assets Under Management stand at **£${((metrics?.aum || 9.42e9) / 1e9).toFixed(2)} Billion** with available cash reserves of **£${((metrics?.cashAvailable || 870e6) / 1e6).toFixed(1)} Million**. The active stress tier is set to **${activeScenario?.name || 'Base Case Baseline'}**. 

### 2. Analytical Section Focus: ${sectionName || 'Treasury & Sovereign Risk'}
- **Value at Risk (VaR)**: The daily Value at Risk at the 99% confidence level stands at **£${((metrics?.varDaily || 2.4e8) / 1e6).toFixed(1)} Million** (${((metrics?.varDaily / (metrics?.aum || 9.42e9)) * 100).toFixed(2)}% of capital), which represents a standard trading margin. Under a historical drawdown envelope, expected shortfall stands at **£${((metrics?.expectedShortfall || 3.1e8) / 1e6).toFixed(1)} Million**.
- **Liquidity Coverage (LCR)**: Currently maintained at **${(metrics?.lcr || 1.85).toFixed(2)}x**, comfortably exceeding the Basel III regulatory threshold of 1.00x, securing a **${metrics?.riskRating || 'Low'}** overall risk designation.
- **Strategic Recommendation**: Maintain a 75% sterling currency hedge across US Treasury paper. Incremental Bitcoin holdings should remain anchored below 5.0% allocation to restrict extreme tail-risk contributions.`
      });
    }

    const ai = getAi();
    const systemPrompt = `You are the Senior Chief Risk Officer (CRO) and Treasury Director of Ellan Vannin Wealth Management (EVM), a sovereign-style sovereign wealth manager and institutional infrastructure investor. Write a highly professional, clinical, mathematically sound executive commentary and risk assessment. Style should match J.P. Morgan, MSCI Barra or the Bank of England's Financial Stability Reports. Avoid generic statements, exclamation marks, or empty marketing terms. Focus on quantitative rigor, Basel III indicators (LCR, NSFR), and stress-testing impacts.`;

    const userPrompt = `
Generate an executive commentary for the section: "${sectionName || 'Executive Summary'}".
Current active stress scenario is: "${activeScenario ? activeScenario.name : 'None (Base Case Standard Assumption)'}".
Description of active scenario: "${activeScenario ? activeScenario.description : 'Standard baseline market operating parameters.'}"

Current Portfolio Metrics:
- Assets Under Management (AUM): £${((metrics?.aum || 0) / 1e9).toFixed(3)} Billion
- Cash Available: £${((metrics?.cashAvailable || 0) / 1e6).toFixed(1)} Million
- Volatility: ${((metrics?.volatility || 0) * 100).toFixed(2)}%
- Expected Return: ${((metrics?.expectedReturn || 0) * 100).toFixed(2)}%
- Daily VaR (99% confidence): £${((metrics?.varDaily || 0) / 1e6).toFixed(1)} Million (${((metrics?.varDaily / (metrics?.aum || 1)) * 100).toFixed(2)}% of AUM)
- Expected Shortfall (ES): £${((metrics?.expectedShortfall || 0) / 1e6).toFixed(1)} Million
- Liquidity Coverage Ratio (LCR): ${(metrics?.lcr || 0).toFixed(2)}x (Regulatory limit: 1.00x)
- Net Stable Funding Ratio (NSFR): ${(metrics?.nsfr || 0).toFixed(2)}x
- Debt Outstanding: £${((metrics?.debtOutstanding || 0) / 1e9).toFixed(3)} Billion
- Interest Coverage Ratio (ICR): ${(metrics?.interestCoverageRatio || 0).toFixed(2)}x
- Rated Risk Profile: ${metrics?.riskRating}

Provide a 3-paragraph executive brief detailing:
1. An analytical overview of EVM's balance sheet under this scenario.
2. The specific risk factors of this segment (${sectionName}) including VaR, liquidity limits, and interest-coverage parameters.
3. Crucial defensive recommendations for the board of directors (e.g., hedging shifts, collateral changes, funding drawdowns, or capital deployment freezes).

Format using clean Markdown with clear headers. Output exactly the commentary, without any introductory conversational text.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2
      }
    });

    res.json({
      commentary: response.text || 'Error: Generation returned empty.'
    });
  } catch (error: any) {
    console.error('Gemini generate error:', error);
    res.status(500).json({ error: error.message || 'Internal server error calling Gemini API.' });
  }
});

// Serve static assets in production, otherwise mount Vite in development
async function bootstrap() {
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

bootstrap();
