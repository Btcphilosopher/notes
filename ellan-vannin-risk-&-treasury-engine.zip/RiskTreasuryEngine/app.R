# ==========================================
# Ellan Vannin Wealth Management
# Risk & Treasury Engine (RTE)
# Primary Entry Point: app.R
# ==========================================

library(shiny)
library(shinydashboard)
library(bslib)
library(plotly)
library(ggplot2)
library(DT)
library(reactable)
library(dplyr)
library(tidyr)
library(data.table)
library(PerformanceAnalytics)
library(tidyquant)
library(quantmod)
library(TTR)
library(forecast)
library(lubridate)
library(scales)
library(jsonlite)
library(httr2)

# Source configuration & independent modular engines
source("R/config.R")
source("R/dashboard.R")
source("R/treasury_engine.R")
source("R/risk_engine.R")
source("R/liquidity_engine.R")
source("R/market_risk.R")
source("R/credit_risk.R")
source("R/interest_rate_risk.R")
source("R/currency_risk.R")
source("R/stress_testing.R")
source("R/monte_carlo.R")
source("R/portfolio_engine.R")
source("R/cashflow_engine.R")
source("R/scenario_engine.R")
source("R/alert_engine.R")
source("R/report_generator.R")

# Define UI
ui <- dashboardPage(
  skin = "black",
  dashboardHeader(
    title = span(tagList(icon("shield-halved"), "Ellan Vannin RTE")),
    titleWidth = 300,
    tags$li(class = "dropdown",
            actionButton("toggle_theme", "Toggle Light/Dark", icon = icon("circle-half-stroke"), 
                         class = "btn-outline-light", style = "margin-top: 8px; margin-right: 15px;"))
  ),
  
  dashboardSidebar(
    width = 300,
    sidebarMenu(
      id = "sidebar",
      menuItem("Dashboard", tabName = "dashboard", icon = icon("gauge-high")),
      menuItem("Treasury", tabName = "treasury", icon = icon("vault")),
      menuItem("Liquidity", tabName = "liquidity", icon = icon("droplet")),
      menuItem("Portfolio Risk", tabName = "portfolio", icon = icon("chart-pie")),
      menuItem("Market Risk", tabName = "market", icon = icon("chart-line")),
      menuItem("Credit Risk", tabName = "credit", icon = icon("handshake")),
      menuItem("Interest Rate Risk", tabName = "interest", icon = icon("percent")),
      menuItem("Currency Risk", tabName = "currency", icon = icon("coins")),
      menuItem("Infrastructure", tabName = "infra", icon = icon("bridge")),
      menuItem("Bitcoin Treasury", tabName = "btc", icon = icon("bitcoin")),
      menuItem("Stress Testing", tabName = "stress", icon = icon("triangle-exclamation")),
      menuItem("Monte Carlo", tabName = "monte", icon = icon("dice")),
      menuItem("Scenario Analysis", tabName = "scenarios", icon = icon("sliders")),
      menuItem("Cash Flow", tabName = "cashflow", icon = icon("arrows-spin")),
      menuItem("Alerts", tabName = "alerts", icon = icon("bell")),
      menuItem("Reports", tabName = "reports", icon = icon("file-pdf")),
      menuItem("Settings", tabName = "settings", icon = icon("gears"))
    )
  ),
  
  dashboardBody(
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "style.css")
    ),
    tabItems(
      tabItem(tabName = "dashboard", dashboardViewUI("dashboard")),
      tabItem(tabName = "treasury", treasuryViewUI("treasury")),
      tabItem(tabName = "liquidity", liquidityViewUI("liquidity")),
      tabItem(tabName = "portfolio", portfolioViewUI("portfolio")),
      tabItem(tabName = "market", marketViewUI("market")),
      tabItem(tabName = "credit", creditViewUI("credit")),
      tabItem(tabName = "interest", interestViewUI("interest")),
      tabItem(tabName = "currency", currencyViewUI("currency")),
      tabItem(tabName = "infra", infraViewUI("infra")),
      tabItem(tabName = "btc", btcViewUI("btc")),
      tabItem(tabName = "stress", stressViewUI("stress")),
      tabItem(tabName = "monte", monteViewUI("monte")),
      tabItem(tabName = "scenarios", scenariosViewUI("scenarios")),
      tabItem(tabName = "cashflow", cashflowViewUI("cashflow")),
      tabItem(tabName = "alerts", alertsViewUI("alerts")),
      tabItem(tabName = "reports", reportsViewUI("reports")),
      tabItem(tabName = "settings", settingsViewUI("settings"))
    )
  )
)

# Define Server
server <- function(input, output, session) {
  # Initialize Reactive Values representing Sovereign Wealth State
  rv <- reactiveValues(
    settings = default_settings(),
    assets = default_assets(),
    counterparties = default_counterparties(),
    fx_exposures = default_fx(),
    infra_projects = default_infra(),
    alerts = default_alerts(),
    active_scenario = NULL
  )
  
  # Call independent module servers
  callModule(dashboardModule, "dashboard", rv)
  callModule(treasuryModule, "treasury", rv)
  callModule(liquidityModule, "liquidity", rv)
  callModule(portfolioModule, "portfolio", rv)
  callModule(marketModule, "market", rv)
  callModule(creditModule, "credit", rv)
  callModule(interestModule, "interest", rv)
  callModule(currencyModule, "currency", rv)
  callModule(infraModule, "infra", rv)
  callModule(btcModule, "btc", rv)
  callModule(stressModule, "stress", rv)
  callModule(monteModule, "monte", rv)
  callModule(scenariosModule, "scenarios", rv)
  callModule(cashflowModule, "cashflow", rv)
  callModule(alertsModule, "alerts", rv)
  callModule(reportsModule, "reports", rv)
  callModule(settingsModule, "settings", rv)
}

shinyApp(ui, server)
