# ==========================================
# Ellan Vannin Wealth Management
# Risk & Treasury Engine (RTE)
# Configuration & Constants: config.R
# ==========================================

default_settings <- function() {
  list(
    interestRateBase = 0.0525,
    targetReturn = 0.0750,
    inflationRate = 0.0280,
    varConfidence = 0.99,
    hedgingPolicyGBP = 0.75,
    theme = "dark"
  )
}

default_assets <- function() {
  data.frame(
    type = c('Equities', 'Bonds', 'Property', 'Infrastructure', 'Private Equity', 'Bitcoin', 'Gold', 'Cash', 'Alternatives'),
    value = c(1550000000, 2200000000, 850000000, 1850000000, 1200000000, 380000000, 420000000, 870000000, 80000000),
    volatility = c(0.18, 0.06, 0.12, 0.08, 0.24, 0.55, 0.14, 0.01, 0.16),
    expectedReturn = c(0.09, 0.045, 0.065, 0.115, 0.13, 0.35, 0.05, 0.0525, 0.08),
    beta = c(1.15, 0.15, 0.45, 0.30, 1.40, 1.85, -0.05, 0.00, 0.60),
    stringsAsFactors = FALSE
  )
}

default_counterparties <- function() {
  data.frame(
    id = paste0("cp-0", 1:8),
    name = c('Barclays Bank Plc', 'Lloyds Banking Group', 'J.P. Morgan Securities', 'Goldman Sachs International', 'HSBC Bank Plc', 'BNP Paribas S.A.', 'UBS AG Group', 'Citibank N.A. London'),
    rating = c('A', 'A', 'AA', 'AA', 'AA', 'A', 'A', 'A'),
    exposure = c(245000000, 180000000, 320000000, 290000000, 410000000, 150000000, 220000000, 135000000),
    limit = c(300000000, 250000000, 400000000, 350000000, 500000000, 200000000, 250000000, 200000000),
    pd = c(0.0035, 0.0028, 0.0008, 0.0012, 0.0006, 0.0032, 0.0025, 0.0018),
    lgd = c(0.40, 0.40, 0.35, 0.35, 0.40, 0.45, 0.40, 0.38),
    stringsAsFactors = FALSE
  )
}

default_fx <- function() {
  data.frame(
    currency = c('GBP', 'USD', 'EUR', 'CHF', 'JPY', 'CAD', 'AUD', 'BTC'),
    holdings = c(4850000000, 2850000000, 1100000000, 350000000, 55000000000, 250000000, 180000000, 7200),
    rate = c(1.0000, 1.2850, 1.1820, 1.1340, 198.50, 1.7630, 1.9420, 0.000021),
    costBasis = c(1.0000, 1.2420, 1.1550, 1.1120, 192.10, 1.7310, 1.8950, 38500),
    hedgingRatio = c(1.00, 0.80, 0.70, 0.60, 0.50, 0.40, 0.30, 0.00),
    stringsAsFactors = FALSE
  )
}

default_infra <- function() {
  data.frame(
    id = paste0("inf-0", 1:9),
    name = c('Snaefell Railway Modernisation & Extension', 'Douglas Deepwater Port Terminal & Quay Expansion', 'Glenfaba Biomass & Clean Natural Gas Peak Plants', 'Isle of Man Offshore Wind Farm Phase II (Ramsey)', 'Sulby Valley Managed Commercial Forestry & Carbon Sink', 'North Douglas Sustainable Eco-Housing Complex', 'Jurby Tier-IV Hyperscale Sustainable Data Centre', 'Castletown Seawater Desalination Plant & Distribution Grid', 'Snaefell Mountain Course Hybrid Safety Super-Highway'),
    category = c('Railway', 'Port', 'Power Station', 'Wind Farm', 'Forestry', 'Housing', 'Data Centre', 'Water', 'Road'),
    constructionRisk = c(15, 35, 42, 55, 10, 25, 30, 48, 20),
    politicalRisk = c(5, 12, 18, 8, 5, 15, 5, 10, 8),
    regulatoryRisk = c(10, 22, 35, 40, 15, 20, 12, 28, 15),
    operatingRisk = c(12, 15, 28, 32, 10, 18, 20, 25, 14),
    revenueRisk = c(18, 14, 25, 20, 22, 15, 18, 12, 35),
    demandRisk = c(15, 10, 12, 5, 25, 8, 15, 5, 40),
    baselineIRR = c(0.095, 0.112, 0.125, 0.142, 0.078, 0.105, 0.155, 0.088, 0.082),
    cost = c(180000000, 310000000, 240000000, 450000000, 95000000, 160000000, 280000000, 135000000, 100000000),
    stringsAsFactors = FALSE
  )
}

default_alerts <- function() {
  data.frame(
    id = paste0("al-0", 1:4),
    timestamp = c('2026-07-23 09:12:04', '2026-07-23 11:45:12', '2026-07-22 14:02:55', '2026-07-20 08:30:00'),
    category = c('Risk Limit', 'Currency', 'Operations', 'Counterparty'),
    message = c('Daily parametric VaR (99% confidence) reached 3.42%, approaching soft limit of 3.50%.', 'USD Net Exposure increased past £2.2B following options contract rollover.', 'Douglas Deepwater Port construction cost index rose by 4.2% due to steel import tariffs.', 'Barclays Bank Plc credit rating outlook revised to Negative by S&P; monitoring risk concentration.'),
    severity = c('Moderate', 'Low', 'Moderate', 'Low'),
    stringsAsFactors = FALSE
  )
}

# Correlation Matrix as a hardcoded R matrix
correlation_matrix <- function() {
  m <- matrix(
    c(
      1.00, 0.12, 0.38, 0.28, 0.78, 0.45, 0.05, 0.00, 0.35,
      0.12, 1.00, 0.05, 0.15, 0.08, -0.10, 0.22, 0.15, 0.10,
      0.38, 0.05, 1.00, 0.45, 0.42, 0.15, 0.12, 0.00, 0.25,
      0.28, 0.15, 0.45, 1.00, 0.32, 0.10, 0.18, 0.05, 0.20,
      0.78, 0.08, 0.42, 0.32, 1.00, 0.50, 0.02, 0.00, 0.40,
      0.45, -0.10, 0.15, 0.10, 0.50, 1.00, 0.15, -0.05, 0.22,
      0.05, 0.22, 0.12, 0.18, 0.02, 0.15, 1.00, 0.05, 0.18,
      0.00, 0.15, 0.00, 0.05, 0.00, -0.05, 0.05, 1.00, 0.00,
      0.35, 0.10, 0.25, 0.20, 0.40, 0.22, 0.18, 0.00, 1.00
    ),
    nrow = 9, ncol = 9, byrow = TRUE
  )
  rownames(m) <- c('Equities', 'Bonds', 'Property', 'Infrastructure', 'Private Equity', 'Bitcoin', 'Gold', 'Cash', 'Alternatives')
  colnames(m) <- rownames(m)
  return(m)
}
